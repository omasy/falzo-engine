<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://twitter.com/guruinfinite
 * @since             1.0.0
 * @package           Falzo
 *
 * @wordpress-plugin
 * Plugin Name:       falzo engine
 * Plugin URI:        https://github.com/omasy/falzo-engine
 * Description:       Falzo online real estate service provider, best services best offers with 24/7 customer service and follow up.
 * Version:           1.0.0
 * Author:            Chukwu Remijius
 * Author URI:        https://twitter.com/guruinfinite
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       falzo
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'PLUGIN_VERSION', '1.0.0' );

if (!defined('YO_PLUGIN_VER')) {
    define('YO_PLUGIN_VER', '1.0.0');
}
if (!defined('YO_PLUGIN_FILE')) {
    define('YO_PLUGIN_FILE', __FILE__);
}
if (!defined('YO_PLUGIN_NAME')) {
    $plugin_dir_name = dirname(__FILE__);
    $plugin_dir_name = str_replace('\\', '/', $plugin_dir_name);
    $plugin_dir_name = explode('/', $plugin_dir_name);
    $plugin_dir_name = end($plugin_dir_name);
    define('YO_PLUGIN_NAME', $plugin_dir_name);
}

if (!defined('YO_PLUGIN_DIR')) {
    $plugin_dir = plugin_dir_path(__FILE__);
    define('YO_PLUGIN_DIR', $plugin_dir);
}
if (!defined('YO_PLUGIN_URL')) {
    $plugin_url = plugins_url('/', __FILE__);
    define('YO_PLUGIN_URL', $plugin_url);
}

if (!defined('YO_PLUGIN_PREFIX')) {
    define('YO_PLUGIN_PREFIX', 'yo_');
}

if (!defined('YO_METABOX_PREFIX')) {
    define('YO_METABOX_PREFIX', 'falzo_engine_');
}

if (!defined('YO_OPTIONS_NAME')) {
    define('YO_OPTIONS_NAME', 'falzo_options');
}
if (!defined('YO_AJAX_URL')) {
    $ajax_url = admin_url('admin-ajax.php', 'relative');
    define('YO_AJAX_URL', $ajax_url);
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-falzo-activator.php
 */
function activate_falzo() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-falzo-activator.php';
	Falzo_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-falzo-deactivator.php
 */
function deactivate_falzo() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-falzo-deactivator.php';
	Falzo_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_falzo' );
register_deactivation_hook( __FILE__, 'deactivate_falzo' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-falzo.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_falzo() {

	$plugin = new Falzo();
	$plugin->run();

}
run_falzo();
