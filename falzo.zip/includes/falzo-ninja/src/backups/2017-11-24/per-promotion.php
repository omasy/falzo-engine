<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
global $current_user;
$current_user = wp_get_current_user();
$user_id = $current_user->ID;
$promotion_id = isset($_GET['promotion_id']) ? $_GET['promotion_id'] : get_user_meta( $user_id, YO_METABOX_PREFIX. 'promotion_id', true );
$user_promotion_id = get_the_author_meta(YO_METABOX_PREFIX . 'promotion_id', $user_id);

$promotion_title = get_the_title($promotion_id);
$duration = get_post_meta( $promotion_id, YO_METABOX_PREFIX. 'promotion_duration', true );
$amount = get_post_meta( $promotion_id, YO_METABOX_PREFIX. 'promotion_amount', true );
$position = get_post_meta( $promotion_id, YO_METABOX_PREFIX. 'promotion_position', true );
$filter = get_post_meta( $promotion_id, YO_METABOX_PREFIX. 'promotion_filter', true );
$promotion_date = strtotime(get_post_meta($promotion_id, YO_METABOX_PREFIX. 'promotion_activate_date', true));
$today = time();

$terms_conditions = ere_get_option('payment_terms_condition');
$allowed_html = array(
    'a' => array(
        'href' => array(),
        'title' => array(),
        'target'=>array()
    ),
    'strong' => array()
);
$enable_paypal = ere_get_option('enable_paypal', 1);
$enable_stripe = ere_get_option('enable_stripe', 1);
$enable_wire_transfer = ere_get_option('enable_wire_transfer', 1);
$enable_bank_deposit = yo_get_option('enable_bank_deposit', 1);
$select_packages_link = yo_get_permalink('patch');
?>
<div class="row">
    <div class="col-md-4 col-sm-6">
        <div class="ere-payment-for panel panel-default">
            <div
                class="ere-package-title panel-heading"><?php esc_html_e('Requested Promotion', 'falzo'); ?></div>
            <ul class="list-group">
                <li class="list-group-item">
                    <span
                        class="badge"><?php echo get_the_title($promotion_id); ?></span><?php esc_html_e('Promotion', 'falzo'); ?>
                </li>
                <li class="list-group-item">
            <span
                class="badge"><?php echo esc_attr($duration); ?></span><?php esc_html_e('Duration:', 'falzo'); ?>

                </li>
                <li class="list-group-item">
        <span class="badge"><?php echo esc_attr($position); ?></span><?php esc_html_e('Position:', 'falzo'); ?>


                </li>
                <li class="list-group-item">
            <span
                class="badge"> <?php echo esc_attr($filter); ?></span><?php esc_html_e('Filter:', 'falzo'); ?>

                </li>
                <li class="list-group-item">
            <span
                class="badge"><?php echo ere_get_format_money($amount); ?></span><?php esc_html_e('Total Price:', 'falzo'); ?>

                </li>
                <li class="list-group-item text-center">
                    <a class="btn btn-default"
                       href="<?php echo esc_url($select_packages_link); ?>"><?php esc_html_e('Change Package', 'falzo'); ?></a>
                </li>
            </ul>
        </div>
    </div>
    <div class="col-md-8 col-sm-6">
        <?php if($promotion_id == $user_promotion_id && intval($amount) > 1000 ):?>
            <div class="alert alert-warning" role="alert"><?php echo sprintf( __( 'You currently have "%s" package. The package hasn\'t expired yet, so you cannot buy it at this time. If you would like, you can buy another package.', 'essential-real-estate' ), $promotion_title); ?></div>
        <?php else:?>
        <?php if ($promotion_date <= $today): ?>
            <div class="ere-payment-method-wrap">
                <div class="ere-heading mg-bottom-40">
                    <h2 class="uppercase"><?php esc_html_e('Payment Method','essential-real-estate'); ?></h2>
                </div>
                <?php if ($enable_paypal != 0) : ?>
                    <div class="radio">
                        <label>
                            <input type="radio" class="payment-paypal" name="ere_payment_method" value="paypal"
                                   checked><i
                                class="fa fa-paypal"></i>
                            <?php esc_html_e('Pay With Paypal', 'essential-real-estate'); ?>
                        </label>
                    </div>
                <?php endif; ?>

                <?php if ($enable_stripe != 0): ?>
                    <div class="radio">
                        <label>
                            <input type="radio" class="payment-stripe" name="ere_payment_method" value="stripe">
                            <i class="fa fa-credit-card"></i> <?php esc_html_e('Pay with Credit Card', 'essential-real-estate'); ?>
                        </label>
                        <?php
                        $yo_payment = new YO_Payment();
                        $yo_payment->stripe_payment_promotion($patch_id, $amount); ?>
                    </div>
                <?php endif; ?>

                <?php if ($enable_wire_transfer != 0) : ?>
                    <div class="radio">
                        <label>
                            <input type="radio" name="ere_payment_method" value="wire_transfer">
                            <i class="fa fa-send-o"></i> <?php esc_html_e('Wire Transfer', 'essential-real-estate'); ?>
                        </label>
                    </div>
                <?php endif; ?>
                
                <?php if ($enable_bank_deposit != 0) : ?>
                    <div class="radio">
                        <label>
                            <input type="radio" name="ere_payment_method" value="bank_deposit">
                            <i class="fa fa-money"></i> <?php esc_html_e('Bank Deposit', 'essential-real-estate'); ?>
                        </label>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <input type="hidden" name="yo_promotion_id" value="<?php echo esc_attr($promotion_id); ?>">

        <p class="terms-conditions"><i class="fa fa-hand-o-right"></i> <?php echo sprintf(wp_kses(__('Please read <a target="_blank" href="%s"><strong>Terms & Conditions</strong></a> first', 'essential-real-estate'), $allowed_html), get_permalink($terms_conditions)); ?></p>
        <?php if (intval($patch_price) > 0): ?>
            <button id="yo_payment_promotion" type="submit"
                    class="btn btn-success btn-submit"> <?php esc_html_e('Pay Now', 'essential-real-estate'); ?> </button>
        <?php endif; ?>
        <?php endif;?>
    </div>
</div>
