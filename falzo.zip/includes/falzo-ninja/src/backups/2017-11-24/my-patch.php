<?php
/**
 * Created by G5Theme.
 * User: trungpq
 * Date: 15/12/2016
 * Time: 10:59 SA
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
global $current_user;
wp_get_current_user();
$user_id = $current_user->ID;

$patch_id = get_the_author_meta(YO_METABOX_PREFIX. 'patch_id', $user_id);
$patch_link = yo_get_permalink('patch');

if (!empty($patch_id)) :
    $patch_user = $current_user->user_login;
	$agencies = get_user_meta( $user_id, YO_METABOX_PREFIX. 'agency_ids', true );
	$patch_price = get_post_meta( $patch_id, YO_METABOX_PREFIX. 'patch_price', true );
	$patch_award = get_post_meta( $patch_id, YO_METABOX_PREFIX. 'award_rank', true );
	$patch_date = get_post_meta( $patch_id, YO_METABOX_PREFIX. 'patch_activate_date', true );
    ?>
    <ul class="list-group ere-my-package">
        <li class="list-group-item"><span
                class="badge"><?php echo esc_html($patch_user) ?></span><?php esc_html_e('Patch For: ', 'essential-real-estate') ?>
        </li>
        <li class="list-group-item"><span
                class="badge"><?php echo count($agencies); ?></span><?php esc_html_e('Total Agency: ', 'essential-real-estate') ?>
        </li>

        <li class="list-group-item"><span
                class="badge"><?php echo ere_get_format_money($patch_price) ?></span><?php esc_html_e('Patch Price: ', 'essential-real-estate') ?>
        </li>

        <li class="list-group-item"><span
                class="badge"><?php echo esc_html($patch_award.' ranks') ?></span><?php esc_html_e('Patch Award: ', 'essential-real-estate') ?>
        </li>

        <li class="list-group-item"><span
                class="badge"><?php echo esc_html($patch_date) ?></span><?php esc_html_e('Start Date: ', 'essential-real-estate') ?>
        </li>
        <li class="list-group-item">
            <a href="<?php echo esc_url($patch_link); ?>"
               class="btn btn-primary btn-block"><?php esc_html_e('Add new patch', 'essential-real-estate'); ?></a>
        </li>
    </ul>
<?php else: ?>
    <div class="panel-body">
    <p class="ere-message alert alert-success"
       role="alert"><?php esc_html_e('To get more traffic and sales you have to patch with an agency. Currently, you don\'t have a patch record. So, to add a new patch, please click the button below', 'essential-real-estate'); ?></p>
    <a href="<?php echo $patch_link; ?>"
       class="btn btn-primary btn-block"><?php esc_html_e('Patch with agency', 'essential-real-estate'); ?></a>
    </div>
<?php endif; ?>