<?php
/**
 * @var $cur_menu
 * @var $max_num_pages
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
global $current_user;
wp_get_current_user();
$user_login = $current_user->user_login;
$user_id = $current_user->ID;
$ere_property=new ERE_Property();
$total_properties = $ere_property->get_total_my_properties(array('publish', 'pending', 'expired','hidden'));
$ere_invoice=new ERE_Invoice();
$total_invoices = $ere_invoice->get_total_my_invoice();
$total_favorite=$ere_property->get_total_favorite();
// My own widget extension
$yo_agency = new YO_Agency();
$total_patch = $yo_agency->get_total_patch(array('publish', 'pending', 'expired', 'hidden'));
$yo_sponsored = new YO_Promotion();
$total_promotion = $yo_sponsored->get_total_promotion(array('publish', 'pending', 'expired', 'hidden'));
$ere_save_search= new ERE_Save_Search();
$total_save_search=$ere_save_search->get_total_save_search();
$allow_submit=yo_allow_submit();
?>
<div class="row">
    <div class="col-sm-6">
        <h4 class="ere-dashboard-title"><?php echo sprintf(__('Welcome: %s', 'essential-real-estate'),$user_login);?></h4>
    </div>
    <div class="col-sm-6 text-right">
        <?php if ($permalink = ere_get_permalink('submit_property')) :
            if($allow_submit):?>
            <a class="btn btn-default"
               href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('Add New Property', 'essential-real-estate'); ?></a>
        <?php endif; endif; ?>
    </div>
</div>
<ul class="nav nav-tabs ere-dashboard-tabs">
    <?php if ($permalink = ere_get_permalink('my_profile')) : ?>
        <li<?php if ($cur_menu == 'my_profile') echo ' class="active"' ?>>
            <a href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('My Profile', 'essential-real-estate'); ?></a>
        </li>
    <?php endif;
    if ($allow_submit) :
        if ($permalink = ere_get_permalink('my_properties')) : ?>
            <li<?php if ($cur_menu == 'my_properties') echo ' class="active"' ?>>
                <a href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('My Properties ', 'essential-real-estate');
                    echo '<span class="badge">' . $total_properties . '</span>' ?></a>
            </li>
        <?php endif;
        $paid_submission_type = ere_get_option( 'paid_submission_type','no');
        if($paid_submission_type!='no'):
            if ($permalink = ere_get_permalink('my_invoices')) :
                ?>
                <li<?php if ($cur_menu == 'my_invoices') echo ' class="active"' ?>>
                    <a href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('My Invoices ', 'essential-real-estate');
                        echo '<span class="badge">' . $total_invoices . '</span>' ?></a>
                </li>
            <?php endif;
        endif;
    endif;
    $enable_favorite = ere_get_option('enable_favorite_property', 1);
    if($enable_favorite==1):
        if ($permalink = ere_get_permalink('my_favorites')) : ?>
            <li<?php if ($cur_menu == 'my_favorites') echo ' class="active"' ?>>
                <a href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('My Favorites ', 'essential-real-estate');
                        echo '<span class="badge">' .$total_favorite . '</span>'; ?></a>
            </li>
        <?php endif;
    endif;
	$enable_saved_search = ere_get_option('enable_saved_search', 1);
    if($enable_saved_search==1):
        if ($permalink = ere_get_permalink('my_save_search')) : ?>
            <li<?php if ($cur_menu == 'my_save_search') echo ' class="active"' ?>>
                <a href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('My Saved Searches ', 'essential-real-estate');
                    echo '<span class="badge">' .$total_save_search . '</span>'; ?></a>
            </li>
        <?php endif;
    endif;
	$enable_patching = yo_get_option('enable_patching', 1);
    if($enable_patching==1):
        if ($permalink = yo_get_permalink('my_patches')) : ?>
            <li<?php if ($cur_menu == 'my_patches') echo ' class="active"' ?>>
                <a href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('My Patches ', 'essential-real-estate');
                        echo '<span class="badge">' .$total_patch . '</span>'; ?></a>
            </li>
        <?php endif;
    endif;
	$enable_sponsoring = yo_get_option('enable_sponsoring', 1);
    if($enable_sponsoring==1):
        if ($permalink = yo_get_permalink('my_promotion')) : ?>
            <li<?php if ($cur_menu == 'my_promotion') echo ' class="active"' ?>>
                <a href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('My Promotions ', 'essential-real-estate');
                        echo '<span class="badge">' .$total_promotion . '</span>'; ?></a>
            </li>
        <?php endif;
    endif; ?>
</ul>