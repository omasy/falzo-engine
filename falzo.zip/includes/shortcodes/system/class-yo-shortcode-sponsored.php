<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('YO_Shortcode_Sponsored')) {
	/**
	 * Class ERE_Shortcode_Account
	 */
	class YO_Shortcode_Sponsored
	{

		/**
		 * Constructor.
		 */
		public function __construct()
		{
			add_shortcode('yo_my_promotion', array($this, 'my_promotion_shortcode'));
			add_shortcode('yo_promote_property', array($this, 'promote_property_shortcode'));
			add_shortcode('yo_sponsor_packages', array($this, 'sponsor_packages_shortcode'));
		}

		/**
		 * Login shortcode
		 */
		public function my_promotion_shortcode($atts)
		{
			return yo_get_template_html('sponsored/my-promotion.php', array('atts' => $atts));
		}

		/**
		 * Register shortcode
		 */
		public function promote_property_shortcode($atts)
		{
			return yo_get_template_html('sponsored/promote-property.php', array('atts' => $atts));
		}

		/**
		 * Update profile shortcode
		 */
		public function sponsor_packages_shortcode()
		{
			return yo_get_template_html('sponsored/sponsor-packages.php');
		}

	}
}
new YO_Shortcode_Sponsored();