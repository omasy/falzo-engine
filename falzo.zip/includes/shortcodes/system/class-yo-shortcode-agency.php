<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('YO_Shortcode_Agency')) {
	/**
	 * Class ERE_Shortcode_Account
	 */
	class YO_Shortcode_Agency
	{

		/**
		 * Constructor.
		 */
		public function __construct()
		{
			add_shortcode('yo_agency_patch', array($this, 'agency_patch_shortcode'));
			add_shortcode('yo_my_patches', array($this, 'my_patches_shortcode'));
			add_shortcode('yo_upgraded', array($this, 'upgraded_shortcode'));
		}

		/**
		 * Login shortcode
		 */
		public function agency_patch_shortcode($atts)
		{
			return yo_get_template_html('agency/agency-patch.php', array('atts' => $atts));
		}

		/**
		 * Register shortcode
		 */
		public function my_patches_shortcode($atts)
		{
			return yo_get_template_html('agency/my-patches.php', array('atts' => $atts));
		}
		
		/**
		 * Register shortcode
		 */
		public function upgraded_shortcode($atts)
		{
			return yo_get_template_html('agency/upgraded.php', array('atts' => $atts));
		}

	}
}
new YO_Shortcode_Agency();