<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('YO_Shortcode_Referral')) {
	/**
	 * Class ERE_Shortcode_Account
	 */
	class YO_Shortcode_Referral
	{

		/**
		 * Constructor.
		 */
		public function __construct()
		{
			add_shortcode('yo_my_referral', array($this, 'my_referral_shortcode'));
		}

		/**
		 * Login shortcode
		 */
		public function my_referral_shortcode($atts)
		{
			return yo_get_template_html('referral/my-referral.php', array('atts' => $atts));
		}

	}
}
new YO_Shortcode_Referral();