<?php
/**
 * Created by G5Theme.
 * User: trungpq
 * Date: 08/11/2016
 * Time: 10:30 SA
 */
if (!defined('ABSPATH')) {
	exit;
}
if (!class_exists('YO_Shortcode')) {
	/**
	 * ERE_Shortcode_Agent class.
	 */
	class YO_Shortcode
	{

		/**
		 * Constructor.
		 */
		public function __construct()
		{
			$this->include_system_shortcode();
			$this->register_public_shortcode();
		}

		/**
		 * Include system shortcode
		 */
		public function include_system_shortcode()
		{
			require_once YO_PLUGIN_DIR . 'includes/shortcodes/system/class-yo-shortcode-agency.php';
			require_once YO_PLUGIN_DIR . 'includes/shortcodes/system/class-yo-shortcode-referral.php';
			require_once YO_PLUGIN_DIR . 'includes/shortcodes/system/class-yo-shortcode-sponsored.php';
		}

		/**
		 * Register shortcode
		 */
		public function register_public_shortcode()
		{
			add_shortcode('yo_top_agents', array($this, 'top_agents_shortcode'));
			add_shortcode('yo_property_slider', array($this, 'property_slider_shortcode'));
			add_shortcode('yo_featured_property', array($this, 'featured_property_shortcode'));
			add_shortcode('yo_sponsored_property', array($this, 'sponsored_property_shortcode'));
			add_shortcode('yo_for_rent', array($this, 'for_rent_shortcode'));
			add_shortcode('yo_for_sale', array($this, 'for_sale_shortcode'));
			add_shortcode('yo_promotion', array($this, 'promotion_shortcode'));
			add_shortcode('yo_recommended', array($this, 'recommended_shortcode'));
			add_shortcode('yo_related_agency', array($this, 'related_agency_shortcode'));
			add_shortcode('yo_patch_buttons', array($this, 'patch_buttons_shortcode'));
			add_shortcode('yo_promote_buttons', array($this, 'promote_buttons_shortcode'));
		}

		/**
		 * Property Gallery
		 * @param $atts
		 *
		 * @return string
		 */
		public function top_agents_shortcode($atts)
		{
			return yo_get_template_html('shortcodes/top-agents/top-agents.php', array('atts' => $atts));
		}

		/**
		 * Property Carousel with Left Navigation
		 * @param $atts
		 *
		 * @return string
		 */
		public function property_slider_shortcode($atts)
		{
			return yo_get_template_html('shortcodes/property/property-slider/property-slider.php', array('atts' => $atts));
		}

		/**
		 * Property Slider
		 * @param $atts
		 *
		 * @return string
		 */
		public function featured_property_shortcode($atts) {
			return yo_get_template_html('shortcodes/property/featured-property/featured-property.php', array('atts' => $atts));
		}
		
		/**
		 * Property Slider
		 * @param $atts
		 *
		 * @return string
		 */
		public function sponsored_property_shortcode($atts) {
			return yo_get_template_html('shortcodes/property/sponsor/sponsor.php', array('atts' => $atts));
		}
		
		/**
		 * Property Search
		 * @param $atts
		 *
		 * @return string
		 */
		public function for_rent_shortcode($atts) {
			return yo_get_template_html('shortcodes/property/for-rent/for-rent.php', array('atts' => $atts));
		}

		/**
		 * Property Search Map
		 * @param $atts
		 * @return string
		 */
		public function for_sale_shortcode($atts) {
			return yo_get_template_html('shortcodes/property/for-sale/for-sale.php', array('atts' => $atts));
		}
		/**
		 * Property Full Search
		 * @param $atts
		 * @return string
		 */
		public function promotion_shortcode($atts) {
			return yo_get_template_html('widgets/promotion/item-slider/promotion.php', array('atts' => $atts, 'onshort' => 1));
		}
		/**
		 * Mini Search
		 * @param $atts
		 * @return string
		 */
		public function recommended_shortcode($atts) {
			return yo_get_template_html('widgets/patches/recommended.php', array('atts' => $atts, 'onshort' => 1));
		}

		/**
		 * Property Featured
		 * @param $atts
		 *
		 * @return string
		 */
		public function related_agency_shortcode($atts)
		{
			return yo_get_template_html('widgets/patches/related-agency.php', array('atts' => $atts, 'onshort' => 1));
		}

		/**
		 * Property type
		 * @param $atts
		 *
		 * @return string
		 */
		public function patch_buttons_shortcode($atts)
		{
			return yo_get_template_html('widgets/buttons/patch-buttons.php', array('atts' => $atts));
		}

		/**
		 * Property shortcode
		 * @param $atts
		 *
		 * @return string
		 */
		public function promote_buttons_shortcode($atts)
		{
			return yo_get_template_html('widgets/buttons/promote-buttons.php', array('atts' => $atts));
		}

	}
}
new YO_Shortcode();

