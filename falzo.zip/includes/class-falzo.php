<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://twitter.com/guruinfinite
 * @since      1.0.0
 *
 * @package    Falzo
 * @subpackage Falzo/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Falzo
 * @subpackage Falzo/includes
 * @author     Chukwu Remijius <gettrafficworld@yahoo.com>
 */
class Falzo {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Falzo_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'PLUGIN_VERSION' ) ) {
			$this->version = PLUGIN_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'falzo';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Falzo_Loader. Orchestrates the hooks of the plugin.
	 * - Falzo_i18n. Defines internationalization functionality.
	 * - Falzo_Admin. Defines all hooks for the admin area.
	 * - Falzo_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-falzo-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-falzo-i18n.php';
		
		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/falzo-core-functions.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-falzo-admin.php';
		
		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-falzo-agency-admin.php';
		
		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-falzo-referral-admin.php';
		
		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-falzo-sponsored-admin.php';
		
		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-falzo-setup-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-falzo-public.php';
		
		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/widgets/class-yo-register-widget.php';
		
		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/shortcodes/class-yo-shortcodes.php';
		
		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/falzo-ninja/bin/yo_patcher/class-yo-patcher.php';

		$this->loader = new Falzo_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Falzo_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Falzo_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Falzo_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

		// Add menu item
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'add_plugin_admin_menu' );
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'plugin_admin_add_page' ); // My code
		
		// Add the option setup hooks
		// $this->loader->add_action( 'admin_init', $plugin_admin, 'falzo_settings_init' );
		$this->loader->add_action( 'admin_init', $plugin_admin, 'falzo_option_creator' );
		$this->loader->add_action( 'admin_init', $plugin_admin, 'falzo_custom_post_type' );
		
		// Here we hook the ninja class
		// $ninja = new YO_Patcher();
		// $this->loader->add_action( 'admin_init', $ninja, 'wizard' );
		
		// Here we hook up the widget
		$register_widgets = new YO_Register_Widgets();
        $this->loader->add_action('widgets_init', $register_widgets, 'register_widgets');
		
		// Here we set ranked options
		// Falzo Ranking Hooks
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/partials/ranking/yo_ranking.php';
		$ranked = new YO_Ranking();
		$this->loader->add_action( 'admin_init', $ranked, 'top_ranked' );
		
		// Add plugin setup
		$admin_setup=new Falzo_Setup_Admin();
		
		$this->loader->add_action( 'admin_menu', $admin_setup, 'admin_menu' );
		$this->loader->add_action( 'admin_menu', $admin_setup, 'sponsored_menu' );
		$this->loader->add_action( 'admin_menu', $admin_setup, 'agency_menu' );
		$this->loader->add_action( 'admin_menu', $admin_setup, 'referral_menu' );
		
		// Agent Post Type
        $agent_admin = new YO_Agency_Admin();
        $this->loader->add_action('restrict_manage_posts', $agent_admin, 'filter_restrict_manage_patch');
        $this->loader->add_filter('parse_query', $agent_admin, 'patch_filter');
        $this->loader->add_action('admin_init', $agent_admin, 'approve_patch');
		
		// Sponsored Post Type
        $sponsored_admin = new YO_Sponsored_Admin();
        $this->loader->add_action('restrict_manage_posts', $sponsored_admin, 'filter_restrict_manage_promotion');
        $this->loader->add_filter('parse_query', $sponsored_admin, 'promotion_filter');
        $this->loader->add_action('admin_init', $sponsored_admin, 'approve_promotion');
		
		// Referral Post Type
        $referral_admin = new YO_Referral_Admin();
        $this->loader->add_action('restrict_manage_posts', $referral_admin, 'filter_restrict_manage_referral');
        $this->loader->add_filter('parse_query', $referral_admin, 'referral_filter');
        $this->loader->add_action('admin_init', $referral_admin, 'approve_referral');
		
		// Add Settings link to the plugin
		$plugin_basename = plugin_basename( plugin_dir_path( __DIR__ ) . $this->plugin_name . '.php' );
		$this->loader->add_filter( 'plugin_action_links_' . $plugin_basename, $plugin_admin, 'add_action_links' );

		// SETTING FILTERS AND CONTROLS
		if (is_admin()) {
        	global $pagenow;
		
			// agent custom columns
            if ($pagenow == 'edit.php' && isset($_GET['post_type']) && esc_attr($_GET['post_type']) == 'falzo_patch') {
                 $this->loader->add_filter('manage_edit-falzo_patch_columns', $agent_admin, 'register_custom_column_titles');
                 $this->loader->add_action('manage_posts_custom_column', $agent_admin, 'display_custom_column');
                 $this->loader->add_filter('post_row_actions', $agent_admin, 'modify_list_row_actions',10,2);
             }
			 
			// agent custom columns
            if ($pagenow == 'edit.php' && isset($_GET['post_type']) && esc_attr($_GET['post_type']) == 'falzo_promotion') {
                 $this->loader->add_filter('manage_edit-falzo_promotion_columns', $sponsored_admin, 'register_custom_column_titles');
                 $this->loader->add_action('manage_posts_custom_column', $sponsored_admin, 'display_custom_column');
                 $this->loader->add_filter('post_row_actions', $sponsored_admin, 'modify_list_row_actions',10,2);
             }
			 
			 // agent custom columns
            if ($pagenow == 'edit.php' && isset($_GET['post_type']) && esc_attr($_GET['post_type']) == 'falzo_referral') {
                 $this->loader->add_filter('manage_edit-falzo_referral_columns', $referral_admin, 'register_custom_column_titles');
                 $this->loader->add_action('manage_posts_custom_column', $referral_admin, 'display_custom_column');
                 $this->loader->add_filter('post_row_actions', $referral_admin, 'modify_list_row_actions',10,2);
             }		
		}

	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Falzo_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
		
		// Wordpress Ajax Hooking
		// Falzo Payment Extension
		$payment_ext = new YO_Payment_ext();
        $this->loader->add_action('wp_ajax_ere_bank_deposit_per_package_ajax', $payment_ext, 'bank_deposit_per_package_ajax');
		$this->loader->add_action('wp_ajax_nopriv_ere_bank_deposit_per_package_ajax', $payment_ext, 'bank_deposit_per_package_ajax');
		
        $this->loader->add_action('wp_ajax_ere_bank_deposit_per_listing_ajax', $payment_ext, 'bank_deposit_per_listing_ajax');
        $this->loader->add_action('wp_ajax_nopriv_ere_bank_deposit_per_listing_ajax', $payment_ext, 'bank_deposit_per_listing_ajax');
		
		// Falzo Payments
		$payments = new YO_Payment();
        $this->loader->add_action('wp_ajax_yo_paypal_payment_patch_ajax', $payments, 'paypal_payment_patch_ajax');
        $this->loader->add_action('wp_ajax_nopriv_yo_paypal_payment_patch_ajax', $payments, 'paypal_payment_patch_ajax');

        $this->loader->add_action('wp_ajax_yo_paypal_payment_promotion_ajax', $payments, 'paypal_payment_promotion_ajax');
        $this->loader->add_action('wp_ajax_nopriv_yo_paypal_payment_promotion_ajax', $payments, 'paypal_payment_promotion_ajax');
		
		$this->loader->add_action('wp_ajax_yo_wire_transfer_patch_ajax', $payments, 'wire_transfer_patch_ajax');
        $this->loader->add_action('wp_ajax_nopriv_yo_wire_transfer_patch_ajax', $payments, 'wire_transfer_patch_ajax');
		
		$this->loader->add_action('wp_ajax_yo_wire_transfer_promotion_ajax', $payments, 'wire_transfer_promotion_ajax');
        $this->loader->add_action('wp_ajax_nopriv_yo_wire_transfer_promotion_ajax', $payments, 'wire_transfer_promotion_ajax');
		
		$this->loader->add_action('wp_ajax_yo_bank_deposit_patch_ajax', $payments, 'bank_deposit_patch_ajax');
        $this->loader->add_action('wp_ajax_nopriv_yo_bank_deposit_patch_ajax', $payments, 'bank_deposit_patch_ajax');
		
		$this->loader->add_action('wp_ajax_yo_bank_deposit_promotion_ajax', $payments, 'bank_deposit_promotion_ajax');
        $this->loader->add_action('wp_ajax_nopriv_yo_bank_deposit_promotion_ajax', $payments, 'bank_deposit_promotion_ajax');
		
		// Falzo Sponsored Hooks
		$promotion = new YO_Promotion();
		$this->loader->add_action('wp_ajax_yo_promote_ajax', $promotion, 'promote_ajax');
        $this->loader->add_action('wp_ajax_nopriv_yo_promote_ajax', $promotion, 'promote_ajax');
		
		$this->loader->add_action('wp_ajax_yo_add_promotion', $promotion, 'add_promotion');
        $this->loader->add_action('wp_ajax_nopriv_yo_add_promotion', $promotion, 'add_promotion');
		
		$this->loader->add_action('init', $promotion, 'promotion_monitor');
		
		// Falzo Agency Hooks
		$agency = new YO_Agency();
		$this->loader->add_action('wp_ajax_yo_patch', $agency, 'patch');
        $this->loader->add_action('wp_ajax_nopriv_yo_patch', $agency, 'patch');
		
		$this->loader->add_action('wp_ajax_yo_upgrade_agent_ajax', $agency, 'upgrade_agent');
        $this->loader->add_action('wp_ajax_nopriv_yo_upgrade_agent_ajax', $agency, 'upgrade_agent');
		
		$this->loader->add_action('wp_ajax_yo_alert_stop_ajax', $agency, 'stop_alert');
        $this->loader->add_action('wp_ajax_nopriv_yo_alert_stop_ajax', $agency, 'stop_alert');
		
		$this->loader->add_action('yo_demand', $agency, 'agency_demand');
		$this->loader->add_action('init', $agency, 'message_alert');
		
		// Falzo Referral Hooks
		$referral = new YO_Referral();
		$this->loader->add_action('wp_ajax_yo_referral_request_ajax', $referral, 'referral_request');
        $this->loader->add_action('wp_ajax_nopriv_yo_referral_request_ajax', $referral, 'referral_request');
		
		// Falzo Ranking Hooks
		$ranking = new YO_Ranking();
		$this->loader->add_action('init', $ranking, 'set_rank');
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Falzo_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
