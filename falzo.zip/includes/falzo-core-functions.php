<?php
/**
 * Core functions
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get Option
 */
if (!function_exists('yo_get_option')) {
    function yo_get_option($key, $default = '')
    {
        $option = get_option(YO_OPTIONS_NAME);
        return (isset($option[$key])) ? $option[$key] : $default;
    }
}



/**
 * Get Option
 */
if (!function_exists('is_dir_empty')) {
    function is_dir_empty($dir){
		// We are returning true of false
		// path struct must be: "/tmp/*"
		return (count(glob($dir."*")) === 0) ? true : false;
		// end of function
	}
}


/**
 * Get Time conversion
 */
if (!function_exists('yo_time_conversion')) {
    function yo_time_conversion($time, $default='')
	{
		// We assume time is in hours
		$return_days = '';
		if(!empty($time)){
			$days = intval($time) / 24;
			// We switch to select
			switch($days){
				case 7:
				$return_days = '1 week';
				break;
				case 30:
				$return_days = '1 month';
				break;
				case 60:
				$return_days = '2 months';
				break;
				case 90:
				$return_days = '3 months';
				break;
				case 360:
				$return_days = '1 year';
				break;
				case 720:
				$return_days = '2 years';
			}
		}
		else{
			$return_days = $default;
		}
		// Now lets return our conversion
		return $return_days;
	}
}
 

/**
 * Getting the root directory of plugin
 */
if(!function_exists('yo_plugin_dir')) {
	function yo_plugin_dir($site_url = null)
	{
		// HERE WE REALLY CONSTRUCT THE FUNCTIONALITY TO GET THE PLUGIN URL AT ANY POINT IN THE
		// WORDPRESS FOLDER
		// Checking is urlpath is setted
		if($site_url!=null){
			$url = $site_url;
		}
		else{
			// Get Url String
			$url = curPageURL();
		}
		// NOW LETS GET THE PATH TREE
		$tree = addPathTree($url);
		
		// LETS RETURN TREE
		return $tree;
	}
}


// FUNCTION TO ADD PATH TREE TO FILES
function addPathTree($url){
	// Lets split url
	$spliitedURL=explode("/", $url);
	// Lets count url array
	if(is_array($spliitedURL)){
		$counturl=count($spliitedURL)-1;
	// Lets check ur count
	// Switch select
	switch($counturl){
		case 1:
		// Lets assign appropraite tree
		$tree="";
		break;
		case 2:
		// Lets assign appropraite tree
		$tree="";
		break;
		case 3:
		// Lets assign appropraite tree
		$tree="";
		break;
		case 4:
		// Lets assign appropraite tree
		$tree="";
		break;
		case 5:
		// Lets assign appropraite tree
		$tree="../";
		break;
		case 6:
		// Lets assign appropraite tree
		$tree="../../";
		break;
		case 7:
		// Lets assign appropraite tree
		$tree="../../../";
		break;
		case 8:
		// Lets assign appropraite tree
		$tree="../../../../";
		break;
		case 9:
		// Lets assign appropraite tree
		$tree="../../../../../";
		break;
		case 10:
		// Lets assign appropraite tree
		$tree="../../../../../../";
		default:
		$tree="";
	}
	// End switch
	}
	// End if

// Returner
return $tree;
// End of method
}


/************* URL PROCESSOR FUNCTION *************************/
function curPageURL(){
	$pageUrl='http';
if(isset($_SERVER["HTTPS"])){
if($_SERVER["HTTPS"]=="on"){
	$pageUrl.="s";
}
}
$pageUrl.="://";
if($_SERVER["SERVER_PORT"]!="80"){
	$pageUrl.=$_SERVER["SERVER_NAME"].":".$_SERVER["REQUEST_URI"];
}
else{
	$pageUrl.=$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
}
return $pageUrl;
}



/************* FUNCTION TO VALIDATE FORM FIELDS ********************/
if (!function_exists('yo_validate')) {
	function yo_validate($input) {
    // All checkboxes inputs        
    $valid = array();

    //Cleanup
    
	// WE DO AUTO LOOP TO CHECK FORM
	// Getting the array index name
	if(is_array($input)){
		// Now lets loop the inputs to check its values
		foreach($input as $key=>$value){
			// NOW LETS CHECK THE VALUES
			$valid[$key] = (isset($input[$key]) && !empty($input[$key])) ? 1 : 0;
		} // End of loop
	} // End of array check

    return $valid;
 }
}



/************* THE CHECK VALIDATION FUNCTION *********************************/
 
if(!function_exists('yo_check_validation')){ 
 	function yo_check_validation($valid_array){
	// Lets set the true value arrays
	$trueValue=0;
	$valid=0;
	$validCount=0;
	// Now lets loop to check
	if(is_array($valid_array)){
		// Lets set the count
		$validCount=count($valid_array);
		// Now lets loop form data
		foreach( $valid_array as $key=>$value){
			if($value==true){
				$valid++;
			}
		} // End of loop
		
		// Now lets check the validation
		if($valid==$validCount){
			$trueValue=1;
		}
		
	} // End oc array check
	
	// Now lets return
	return $trueValue;
 }
}
 
 
 
 
/************* THE CHECK VALIDATION FUNCTION *********************************/
if(!function_exists('yo_clean_inputs')){
	function yo_clean_inputs($inputs){
	$allowed_html = array();
	// NOW LETS START PROCESSING THE METHOD
	if(is_array($inputs)){
		// Now lets loop input fields
		foreach($inputs as $key=>$value){
			$inputs[$key]=trim(sanitize_text_field(wp_kses($value, $allowed_html)));
		} // End of loop
	} // End of array check
	
	return $inputs;
}
}
 
 

/**
 * Check user as agent
 */
if (!function_exists('yo_is_agent')) {
    function yo_is_agent()
    {
        global $current_user;
        wp_get_current_user();
        $user_id = $current_user->ID;
        $agent_id = get_the_author_meta(YO_METABOX_PREFIX . 'author_agent_id', $user_id);
        if (!empty($agent_id) && (get_post_type($agent_id) == 'agent')) {
            return true;
        }
        return false;
    }
} 



/**
 * Get page id
 */
if (!function_exists('yo_get_page_id')) {
    function yo_get_page_id($page)
    {
        $page_id = yo_get_option('yo_' . $page . '_page_id');
        if ($page_id) {
            return absint(function_exists('pll_get_post') ? pll_get_post($page_id) : $page_id);
        } else {
            return 0;
        }
    }
}


/**
 * Get permalink
 */
if (!function_exists('yo_get_permalink')) {
    function yo_get_permalink($page)
    {
        if ($page_id = yo_get_page_id($page)) {
            return get_permalink($page_id);
        } else {
            return false;
        }
    }
}
 


/**
 * Send email
 */
if (!function_exists('yo_send_email')) {
    function yo_send_email($email, $email_type, $request='agency', $args = array())
    {
		$option= yo_get_option("messaging");
		$email_option= $option["email"][$email_type];
        $message = $email_option[$request]["message"];
        $subject = $email_option[$request]["subject"];

        if (function_exists('icl_translate')) {
            $message = icl_translate('essential-real-estate', 'yo_email_' . $message, $message);
            $subject = icl_translate('essential-real-estate', 'yo_email_subject_' . $subject, $subject);
        }
        $args ['website_url'] = get_option('siteurl');
        $args ['website_name'] = get_option('blogname');
        $args ['user_email'] = $email;
        $user = get_user_by('email', $email);
        $args ['username'] = $user->user_login;

        foreach ($args as $key => $val) {
            $subject = str_replace('%' . $key, $val, $subject);
            $message = str_replace('%' . $key, $val, $message);
        }
        $headers = apply_filters( "yo_contact_mail_header", array('Content-Type: text/html; charset=UTF-8'));
        @wp_mail(
            $email,
            $subject,
            $message,
            $headers
        );
    }
}

/**
  * ALLOW PROMOTION SUBMIT
  **/

if (!function_exists('yo_allow_submit')){
    function yo_allow_submit(){
        $enable_submit_promotion_via_frontend = yo_get_option('enable_submit_promotion_via_frontend', 1);
        $user_can_submit = yo_get_option('user_can_submit', 1);
        $is_agent = yo_is_agent();

        $allow_submit=true;
        if($enable_submit_promotion_via_frontend!=1)
        {
            $allow_submit=false;
        }
        else{
            if(!$is_agent && $user_can_submit!=1)
            {
                $allow_submit=false;
            }
        }
        return $allow_submit;
    }
}

/********************* GET ROWS, spnsored, agent, referral, user, patches, property, agency, packages, userpackage, visit, rank, etc. **************************/
/**
 * Get array key value
 */
 
 if(!function_exists('yo_key_value')){
	function yo_key_value($key_name, $array){
		if(is_array($array)){
			foreach($array as $key=>$value){
				if($key_name==$key){
					return $value;
				}
			} // End of loop
		} // End of array check
	}
}
 

/******************* FALZO GET TEMPLATE FUNCTIONALITY ****************************/
/**
 * Get template part (for templates like the shop-loop).
 *
 * ERE_TEMPLATE_DEBUG_MODE will prevent overrides in themes from taking priority.
 *
 * @access public
 * @param mixed $slug
 * @param string $name (default: '')
 */
if (!function_exists('yo_get_template_part')) {
    function yo_get_template_part($slug, $name = '')
    {
        $template = '';
        if ($name) {
            $template = locate_template(array("{$slug}-{$name}.php", ERE()->template_path() . "{$slug}-{$name}.php"));
        }

        // Get default slug-name.php
        if (!$template && $name && file_exists(YO_PLUGIN_DIR . "/public/templates/{$slug}-{$name}.php")) {
            $template = YO_PLUGIN_DIR . "/public/templates/{$slug}-{$name}.php";
        }

        if (!$template) {
            $template = locate_template(array("{$slug}.php", ERE()->template_path() . "{$slug}.php"));
        }

        // Allow 3rd party plugins to filter template file from their plugin.
        $template = apply_filters('yo_get_template_part', $template, $slug, $name);

        if ($template) {
            load_template($template, false);
        }
    }
}
/**
 * Get other templates (e.g. product attributes) passing attributes and including the file.
 *
 * @access public
 * @param string $template_name
 * @param array $args (default: array())
 * @param string $template_path (default: '')
 * @param string $default_path (default: '')
 */
if (!function_exists('yo_get_template')) {
    function yo_get_template($template_name, $args = array(), $template_path = '', $default_path = '')
    {
        if (!empty($args) && is_array($args)) {
            extract($args);
        }

        $located = yo_locate_template($template_name, $template_path, $default_path);

        if (!file_exists($located)) {
            _doing_it_wrong(__FUNCTION__, sprintf('<code>%s</code> does not exist.', $located), '2.1');
            return;
        }

        // Allow 3rd party plugin filter template file from their plugin.
        $located = apply_filters('yo_get_template', $located, $template_name, $args, $template_path, $default_path);

        do_action('ere_before_template_part', $template_name, $template_path, $located, $args);

        include($located);

        do_action('ere_after_template_part', $template_name, $template_path, $located, $args);
    }
}
/**
 * Like ere_get_template, but returns the HTML instead of outputting.
 * @see ere_get_template
 * @since 2.5.0
 * @param string $template_name
 */
if (!function_exists('yo_get_template_html')) {
    function yo_get_template_html($template_name, $args = array(), $template_path = '', $default_path = '')
    {
        ob_start();
        yo_get_template($template_name, $args, $template_path, $default_path);
        return ob_get_clean();
    }
}
/**
 * Locate a template and return the path for inclusion.
 *
 * This is the load order:
 *
 *        yourtheme        /    $template_path    /    $template_name
 *        yourtheme        /    $template_name
 *        $default_path    /    $template_name
 *
 * @access public
 * @param string $template_name
 * @param string $template_path (default: '')
 * @param string $default_path (default: '')
 * @return string
 */
if (!function_exists('yo_locate_template')) {
    function yo_locate_template($template_name, $template_path = '', $default_path = '')
    {
        if (!$template_path) {
            $template_path = ERE()->template_path();
        }

        if (!$default_path) {
            $default_path = YO_PLUGIN_DIR . '/public/templates/';
        }

        // Look within passed path within the theme - this is priority.
        $template = locate_template(
            array(
                trailingslashit($template_path) . $template_name,
                $template_name
            )
        );

        // Get default template/
        if (!$template) {
            $template = $default_path . $template_name;
        }

        // Return what we found.
        return apply_filters('yo_locate_template', $template, $template_name, $template_path);
    }
}
 ?>