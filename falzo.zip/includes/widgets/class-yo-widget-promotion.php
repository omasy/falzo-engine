<?php

if (!defined('ABSPATH')) {
	exit;
}
if (!class_exists('YO_Widget_Promoted_Properties')) {

	class YO_Widget_Promoted_Properties extends ERE_Widget
	{
		/**
		 * Constructor.
		 */
		public function __construct()
		{
			$this->widget_cssclass = 'ere_widget ere_widget_recent_properties ere-property';
			$this->widget_description = esc_html__("Display the Promoted Properties.", 'essential-real-estate');
			$this->widget_id = 'yo_widget_promoted_properties';
			$this->widget_name = esc_html__('YO Promoted Properties', 'essential-real-estate');
			$this->settings = array(
				'title' => array(
					'type' => 'text',
					'std' => esc_html__('Promoted Properties', 'essential-real-estate'),
					'label' => esc_html__('Title', 'essential-real-estate')
				),
				'number' => array(
					'type' => 'number',
					'std' => '20',
					'label' => esc_html__('Number of Properties', 'essential-real-estate')
				),
				'link' => array(
					'type' => 'text',
					'label' => esc_html__('View More Link', 'essential-real-estate')
				),
			);

			parent::__construct();
		}
		/**
		 * Output widget
		 * @param array $args
		 * @param array $instance
		 */
		public function widget($args, $instance)
		{
			$this->widget_start($args, $instance);

			echo ere_get_template_html('widgets/promotion/item-slider/promotion.php', array('args' => $args, 'instance' => $instance));

			$this->widget_end($args);
		}
	}
}