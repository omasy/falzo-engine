<?php
/**
 * WooCommerce Widget Functions
 *
 * Widget related functions and widget registration.
 *
 * @author 		WooThemes
 * @category 	Core
 * @package 	WooCommerce/Functions
 * @version     2.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('YO_Register_Widgets')) {
	class YO_Register_Widgets
	{
		/**
		 * Construct
		 */
		public function __construct()
		{
			require_once ERE_PLUGIN_DIR . 'includes/abstracts/abstract-ere-widget.php';
			require_once ERE_PLUGIN_DIR . 'includes/abstracts/abstract-ere-widget-acf.php';
			require_once YO_PLUGIN_DIR . 'includes/widgets/class-yo-widget-patch-buttons.php';
			require_once YO_PLUGIN_DIR . 'includes/widgets/class-yo-widget-promote-buttons.php';
			require_once YO_PLUGIN_DIR . 'includes/widgets/class-yo-widget-promotion.php';
			require_once YO_PLUGIN_DIR . 'includes/widgets/class-yo-widget-recommended.php';
			require_once YO_PLUGIN_DIR . 'includes/widgets/class-yo-widget-related-agency.php';
		}

		/**
		 * Register Widgets.
		 */
		public function register_widgets()
		{
			register_widget('YO_Widget_Related_Agency');
			register_widget('YO_Widget_Recommended');
			register_widget('YO_Widget_Promoted_Properties');
			register_widget('YO_Widget_Promote_Property');
			register_widget('YO_Widget_Agency_Patch');
		}
	}
}