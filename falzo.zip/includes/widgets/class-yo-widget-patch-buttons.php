<?php

if (!defined('ABSPATH')) {
	exit;
}
if (!class_exists('YO_Widget_Agency_Patch')) {

	class YO_Widget_Agency_Patch extends ERE_Widget
	{
		/**
		 * Constructor.
		 */
		public function __construct()
		{
			$this->widget_cssclass = '';
			$this->widget_description = esc_html__("Display the Patch Button.", 'essential-real-estate');
			$this->widget_id = 'yo_widget_agency_patch';
			$this->widget_name = esc_html__('YO Agency Patch', 'essential-real-estate');
			$this->settings = array(
				'title' => array(
					'type' => 'text',
					'std' => esc_html__('Agency Patch', 'essential-real-estate'),
					'label' => esc_html__('Title', 'essential-real-estate')
				)
			);

			parent::__construct();
		}
		/**
		 * Output widget
		 * @param array $args
		 * @param array $instance
		 */
		public function widget($args, $instance)
		{
			$this->widget_start($args, $instance);

			echo ere_get_template_html('widgets/buttons/patch-buttons.php', array('args' => $args, 'instance' => $instance));

			$this->widget_end($args);
		}
	}
}