<?php

/**
 * Fired during plugin activation
 *
 * @link       https://twitter.com/guruinfinite
 * @since      1.0.0
 *
 * @package    Falzo
 * @subpackage Falzo/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Falzo
 * @subpackage Falzo/includes
 * @author     Chukwu Remijius <gettrafficworld@yahoo.com>
 */
class Falzo_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
