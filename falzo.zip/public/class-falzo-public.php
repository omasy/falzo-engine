<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://twitter.com/guruinfinite
 * @since      1.0.0
 *
 * @package    Falzo
 * @subpackage Falzo/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Falzo
 * @subpackage Falzo/public
 * @author     Chukwu Remijius <gettrafficworld@yahoo.com>
 */
class Falzo_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		
		// Lets include the partials file
		require_once YO_PLUGIN_DIR . 'public/partials/falzo-public-display.php';

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Falzo_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Falzo_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/falzo-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Falzo_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Falzo_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/falzo-public.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( YO_PLUGIN_PREFIX.'promote', YO_PLUGIN_URL . 'public/js/sponsor/promote.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( YO_PLUGIN_PREFIX.'add_promotion', YO_PLUGIN_URL . 'public/js/sponsor/add_promotion.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( YO_PLUGIN_PREFIX.'add_agency', YO_PLUGIN_URL . 'public/js/agency/add_agency.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( YO_PLUGIN_PREFIX.'patch', YO_PLUGIN_URL . 'public/js/agency/patch.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( YO_PLUGIN_PREFIX.'patch_message', YO_PLUGIN_URL . 'public/js/agency/patch_message.js', array( 'jquery' ), $this->version, true );
		wp_enqueue_script( YO_PLUGIN_PREFIX.'get_link', YO_PLUGIN_URL . 'public/js/referral/referral_link.js', array( 'jquery' ), $this->version, true );
		
		// Enqueue Localize scripts
		// Patch wp_localize_script
		$patch_data = array(
                'ajax_url' => YO_AJAX_URL,
                'processing_text' => esc_html__('Processing, Please wait...', 'essential-real-estate')
            );
            wp_localize_script(YO_PLUGIN_PREFIX . 'patch', 'yo_patch_vars', $patch_data);
			
		// Patch wp_localize_script
		$alert_data = array(
                'ajax_url' => YO_AJAX_URL,
                'processing_text' => esc_html__('Reading message, Please wait...', 'essential-real-estate')
            );
            wp_localize_script(YO_PLUGIN_PREFIX . 'patch_message', 'yo_alert_vars', $alert_data);
			
		// Patch wp_localize_script
		$promotion_data = array(
                'ajax_url' => YO_AJAX_URL,
                'processing_text' => esc_html__('Processing, Please wait...', 'essential-real-estate')
            );
            wp_localize_script(YO_PLUGIN_PREFIX . 'promote', 'yo_promotion_vars', $promotion_data);
			
		// Patch wp_localize_script
		$add_promotion_data = array(
                'ajax_url' => YO_AJAX_URL,
                'processing_text' => esc_html__('Adding item, Please wait...', 'essential-real-estate')
            );
            wp_localize_script(YO_PLUGIN_PREFIX . 'add_promotion', 'yo_add_promotion_vars', $add_promotion_data);
			
		// Referral wp_localize_script
		$get_link_data = array(
                'ajax_url' => YO_AJAX_URL,
                'processing_text' => esc_html__('Generating link, Please wait...', 'essential-real-estate')
            );
            wp_localize_script(YO_PLUGIN_PREFIX . 'get_link', 'yo_referral_vars', $get_link_data);
			
		

	}

}
