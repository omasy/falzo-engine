<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://twitter.com/guruinfinite
 * @since      1.0.0
 *
 * @package    Falzo
 * @subpackage Falzo/public/partials
 */
 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
//account
require_once YO_PLUGIN_DIR . 'public/partials/agency/yo_agency.php';
require_once YO_PLUGIN_DIR . 'public/partials/ranking/yo_ranking.php';
require_once YO_PLUGIN_DIR . 'public/partials/referral/yo_referral.php';
//payment
require_once YO_PLUGIN_DIR . 'public/partials/payment/class-yo-extend-payment.php';
require_once YO_PLUGIN_DIR . 'public/partials/payment/class-yo-payment.php';
require_once YO_PLUGIN_DIR . 'public/partials/payment/yo-payment-logger.php';
//sponsored
require_once YO_PLUGIN_DIR . 'public/partials/sponsored/yo_promotion.php';
require_once YO_PLUGIN_DIR . 'public/partials/sponsored/yo_advertise.php';
//upload
require_once YO_PLUGIN_DIR . 'public/partials/falzo_upload_class.php';
