<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('YO_Imager')) {
    /**
     * The public-facing functionality of the plugin
     * Class ERE_Public
     */
    class YO_Imager
	{
		/**
         * Upload profile avatar
         */
        public function image_upload($file)
        {
			// LETS GET DATA FROM EXECUTOR
            $submitted_file = $file;
            $uploaded_image = wp_handle_upload($submitted_file, array('test_form' => false));

            if (isset($uploaded_image['file'])) {
                $file_name = basename($submitted_file['name']);
                $file_type = wp_check_filetype($uploaded_image['file']);
                $attachment_details = array(
                    'guid' => $uploaded_image['url'],
                    'post_mime_type' => $file_type['type'],
                    'post_title' => preg_replace('/\.[^.]+$/', '', basename($file_name)),
                    'post_content' => '',
                    'post_status' => 'inherit'
                );

                $attach_id = wp_insert_attachment($attachment_details, $uploaded_image['file']);
                $attach_data = wp_generate_attachment_metadata($attach_id, $uploaded_image['file']);
                wp_update_attachment_metadata($attach_id, $attach_data);

                $thumbnail_url = wp_get_attachment_thumb_url($attach_id);

                $ajax_response = array(
                    'success' => true,
                    'url' => $thumbnail_url,
                    'attachment_id' => $attach_id
                );

                return $ajax_response;

            } else {
                $ajax_response = array('success' => false, 'reason' => 'Image upload failed!');
                return $ajax_response;
            }
        }
		
		// END OF CLASS
	}
}
?>