<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('YO_Agency')) {
    /**
     * The public-facing functionality of the plugin
     * Class ERE_Public
     */
    class YO_Agency
	{
		/**
         * referral_ajax
         */
		 public function patch($new_agency=array()){
			 // HERE WE START PROCESSING THE USER PATCH REQUEST
			 // Checking user login and role
			 if ( is_user_logged_in()) {
				// LETS PROMOTE AGENT ITEM
				global $current_user;
             	wp_get_current_user();
				$user_id = $current_user->ID;
				$username=$current_user->user_login;
				//GRAB ALL OPTIONS
				$options = yo_get_option("agency");
				$patch_option=$options["patching"];
				// LETS GET THE FORM POST
				$Clean_Inputs=yo_clean_inputs($_POST);
				$agency_id=$Clean_Inputs["agency_id"];
				$author_agent_id=get_the_author_meta( 'real_estate_author_agent_id', $user_id);
				// $agency_id=get_user_meta($user_id, ERE_METABOX_PREFIX . 'author_agent_id', true);
				$patch_price=$patch_option["price"];
				$award_rank=$patch_option["rank"];
				$patch_array=array();
				$patched=array();
				// LETS SET THE PATCHED AGENCY ARRAY IF ITS DOES NOT EXIST
				$patched_agency=get_user_meta( $user_id, YO_METABOX_PREFIX. 'agency_ids', true );
				if(!empty($patched_agency)){
					// We update the patch agency array
					$patched_agency[]=$agency_id;
					$patched=$patched_agency;
				}
				else{
					// We create a new patch agency array
					$patch_array[]=$agency_id;
					$patched=$patch_array;	
				}
				
				// NOW LETS POST ADVERT INTO THE WORDPRESS DATABASE AND META
				$new_agency['post_type'] = 'falzo_patch';
				$new_agency['post_author'] = $user_id;
				$new_agency['post_title']=ucfirst($username)." Patching Program";
				$new_agency['post_content']=ucfirst($username)." Patching Program and Agency: ".$agency_id;;
				$new_agency['post_status'] = 'pending';
			
				// Now lets insert post to the database
				$patch_id = wp_insert_post( $new_agency, true );
				if ( $patch_id > 0 ) {
					// NOW LETS SET THE META DATAS
					// Activation date format
					$time = time();
            		$date = date('Y-m-d H:i:s', $time);
					// Now lets create meta data and attach it to post
					update_post_meta( $patch_id, YO_METABOX_PREFIX. 'agent_id', $author_agent_id );
					update_post_meta( $patch_id, YO_METABOX_PREFIX. 'patch_price', $patch_price );
					update_post_meta( $patch_id, YO_METABOX_PREFIX. 'award_rank', $award_rank );
					update_post_meta( $patch_id, YO_METABOX_PREFIX. 'patch_activate_date', $date );
					update_post_meta( $patch_id, YO_METABOX_PREFIX . 'user_id', $user_id);
					update_post_meta( $patch_id, YO_METABOX_PREFIX . 'payment_status', '');
					update_user_meta( $user_id, YO_METABOX_PREFIX. 'patch_id', $patch_id );
					update_user_meta( $user_id, YO_METABOX_PREFIX. 'agency_ids', $patched );
					update_user_meta( $user_id, YO_METABOX_PREFIX. 'benefit', 0 );
					
					// HERE WE SET AGENT POST TERM TO AGENCY TAXONOMY
					// LETS US ADD AGENT TO THE NEW CREATED TERM
					$tag = array( $agency_id ); // Correct. This is the term id for agency
					wp_set_post_terms( $author_agent_id, $tag, 'agency' );
					
					// HERE WE RANK THE AGENT USER FOR PATCHING
					$this->patch_ranking($user_id);
					// HERE WE MESSAGE AGENT FOR PATCHING
					$this->patch_message($agency_id, $author_agent_id);
					
					// LETS RETURN THE PAYMENT PAGE yo_get_permalink("my_patches")
					$return_page = ere_get_permalink('payment');
					$return_link = add_query_arg(array('patch_id' => $patch_id, 'falzo_request' => 'patch_payment'), $return_page);
					// We return link
					print $return_link;
					wp_die();
				}
			 }
		 }
		 
		 /**
         * referral_ajax
         */
		 public function upgrade_agent(){
			 // HERE WE CONSTRUCT AGENT UPGRADE INTO AGENCY
			 // This requires rank to work, so it will be made after rank system has been made
			 if ( is_user_logged_in()) {
				// LETS PROMOTE AGENT ITEM
				global $current_user;
             	wp_get_current_user();
				$user_id = $current_user->ID;
				//GRAB ALL OPTIONS
			 	$options = yo_get_option("agency");
			 	$ranking_option = $options["ranking"];
			 	$super_rank = $ranking_option["super"];
				// Lets break the super rank option
				$supers=explode("-", $super_rank);
				$rank=intval($supers[0]);
				// Lets get the user rank data
			 	$user_rank = intval(get_user_meta( $user_id, YO_METABOX_PREFIX. 'user_rank', true ));
				$agent_id = intval(get_user_meta($user_id, ERE_METABOX_PREFIX . 'author_agent_id', true));
				if(!empty($user_rank)){
					// NOW LETS CHECK RANK TO CONTINUE PROCESSING
					if(intval($user_rank)>=$rank){
						// HERE WILL BE PENDING TILL I UNDERSTAND HOW TO CREATE AND GET AGENCY DATAS
						// Lets get form datas
						if(isset($_POST["term"])){
							$term_data = yo_clean_inputs($_POST["term"]);
							$logo_file = $_FILES['logo'];
							// Now lets check the fields of the term data
							// Initiating the validator
							$validator=yo_validate($term_data);
							// Now lets check validation
							if(yo_check_validation($validator)==true){
								$terms = wp_insert_term(
    								$term_data["name"],   // the term 
    								'agency', // the taxonomy
    									array(
        									'description' => $term_data["description"],
        									'slug'        => $term_data["slug"],
    									)
									);
								
								// NOW LETS GET THE TERM ID AND ADD
								$term_id = $terms['term_id'];
								$taxonomy_id = $terms["term_taxonomy_id"];
								
								update_user_meta( $user_id, YO_METABOX_PREFIX. 'my_agency_term_id', $term_id );
								update_user_meta( $user_id, YO_METABOX_PREFIX. 'my_agency_taxonomy_id', $taxonomy_id );
								
								// LETS US ADD AGENT TO THE NEW CREATED TERM
								$tag = array( $term_id ); // Correct. This will add the tag with the id 5.
								wp_set_post_terms( $agent_id, $tag, 'agency' );
								
								// LETS UPLOAD IMAGE
								$file_uploader = new YO_Imager();
								$response = $file_uploader->image_upload($logo_file);
								if(is_array($response)){
									if($response['success'] == true){
										foreach($response as $key=>$value){
											if($key == "attachment_id"){
												$agent_logo_id = $value;
												$agent_logo = wp_get_attachment_url($agent_logo_id);
											}
										} // end of loop
									}
									else{
										$agent_logo = 'http://themes.g5plus.net/beyot/wp-content/plugins/essential-real-estate/public/assets/images/profile-avatar.png';
									}
								}
								
								// NOW LETS SET OTHER VARIABLES
								$agent_description = $current_user->description;
								$agent_email = $current_user->user_email;
                    			$agent_website_url = $current_user->user_url;
                    			$agent_mobile_number = get_the_author_meta(ERE_METABOX_PREFIX . 'author_mobile_number', $user_id);
                    			$agent_fax_number = get_the_author_meta(ERE_METABOX_PREFIX . 'author_fax_number', $user_id);
                    			$agent_company = get_the_author_meta(ERE_METABOX_PREFIX . 'author_company', $user_id);
                    			$agent_licenses = get_the_author_meta(ERE_METABOX_PREFIX . 'author_licenses', $user_id);
                    			$agent_office_number = get_the_author_meta(ERE_METABOX_PREFIX . 'author_office_number', $user_id);
                    			$agent_office_address = get_the_author_meta(ERE_METABOX_PREFIX . 'author_office_address', $user_id);
                    			$agent_facebook_url = get_the_author_meta(ERE_METABOX_PREFIX . 'author_facebook_url', $user_id);
                    			$agent_twitter_url = get_the_author_meta(ERE_METABOX_PREFIX . 'author_twitter_url', $user_id);
                    			$agent_linkedin_url = get_the_author_meta(ERE_METABOX_PREFIX . 'author_linkedin_url', $user_id);
                    			$agent_pinterest_url = get_the_author_meta(ERE_METABOX_PREFIX . 'author_pinterest_url', $user_id);
                    			$agent_instagram_url = get_the_author_meta(ERE_METABOX_PREFIX . 'author_instagram_url', $user_id);
                    			$agent_googleplus_url = get_the_author_meta(ERE_METABOX_PREFIX . 'author_googleplus_url', $user_id);
                    			$agent_youtube_url = get_the_author_meta(ERE_METABOX_PREFIX . 'author_youtube_url', $user_id);
                    			$agent_vimeo_url = get_the_author_meta(ERE_METABOX_PREFIX . 'author_vimeo_url', $user_id);
                    			$agent_skype = get_the_author_meta(ERE_METABOX_PREFIX . 'author_skype', $user_id);
                    			$agent_position = get_the_author_meta(ERE_METABOX_PREFIX . 'author_position', $user_id);
                    			$author_picture_id = get_the_author_meta(ERE_METABOX_PREFIX . 'author_picture_id', $user_id);
								
								// NOW LETS SET THE AGENT AGENCY TERM META
								add_term_meta( $term_id, 'agency_des', $agent_description );
								add_term_meta( $term_id, 'agency_address', $agent_office_address );
								add_term_meta( $term_id, 'agency_map_address', $agent_position );

								add_term_meta( $term_id, 'agency_email', $agent_email );
								add_term_meta( $term_id, 'agency_mobile_number', $agent_mobile_number );
								add_term_meta( $term_id, 'agency_fax_number', $agent_fax_number );

								add_term_meta( $term_id, 'agency_licenses', $agent_licenses );

								add_term_meta( $term_id, 'agency_office_number', $agent_office_number );
								add_term_meta( $term_id, 'agency_website_url', $agent_website_url );
								add_term_meta( $term_id, 'agency_vimeo_url', $agent_vimeo_url );
								add_term_meta( $term_id, 'agency_facebook_url', $agent_facebook_url );
								add_term_meta( $term_id, 'agency_twitter_url', $agent_twitter_url );
								add_term_meta( $term_id, 'agency_googleplus_url', $agent_googleplus_url );
								add_term_meta( $term_id, 'agency_linkedin_url', $agent_linkedin_url );
								add_term_meta( $term_id, 'agency_pinterest_url', $agent_pinterest_url );
								add_term_meta( $term_id, 'agency_instagram_url', $agent_instagram_url );
								add_term_meta( $term_id, 'agency_skype', $agent_skype );
								add_term_meta( $term_id, 'agency_youtube_url', $agent_youtube_url );
								add_term_meta( $term_id, 'agency_logo', $agent_logos);
								
								// LETS RETURN THE PAYMENT PAGE
								$return_page=yo_get_permalink("upgraded");
								$return_link = add_query_arg(array('term_id' => $term_id), $return_page);
								
								// NOW LET SET THE RETURN PAGE
								$ajax_response = array(
                    			'success' => true,
								'message' => 'Agency created successfully!',
                    			'url' => $return_link
               					 );
								 // Lets echo the json data
								echo json_encode($ajax_response);
                				wp_die();
								 
							}
						}
					}
				} // End of user rank check
			 }
			 // End of method
		 }
		 
		 /**
         * referral_ajax
         */
		 public function agency_demand(){
			 // HERE WE CONSTRUCT THE AGENCY DEMAND PROCESS
			 // This requires rank to work, so it will be made after rank system has been made
			 if ( is_user_logged_in()) {
				// LETS PROMOTE AGENT ITEM
				global $current_user;
             	wp_get_current_user();
				$user_id = $current_user->ID;
				// Lets set the json array
				$json_response = array();
				// Now lets check
				if($this->agent_check($user_id) == true){
					// We call the template file for the modal
					echo yo_get_template_html('global/agency-modal.php',array('type'=>'modal'));
    				return;
				}
			 }
			 
		 }
		 
		 /**
         * promotion extend
         */
		 public function get_total_patch($post_status){
			// HERE WE CONSTRUCT THE PROMOTION FETCHER
			$args       = array(
				'post_type'   => 'falzo_patch',
				'post_status' => $post_status,
				'author'      => get_current_user_id(),
			);
			$patches = new WP_Query( $args );
			wp_reset_postdata();
			return $patches->found_posts;
			
			// End of method
		 }
		 
		 /**
         * referral_ajax
         */
		 public function agent_check($user_id){
			// HERE WE CONSTRUCT THE AGENT CHECK FOR AGENCY
			// GRAB ALL OPTIONS
			$options = yo_get_option("agency");
			$ranking_option = $options["ranking"];
			$super_rank = $ranking_option["super"];
			// Lets break the super rank option
			$supers=explode("-", $super_rank);
			$rank=intval($supers[0]);
			// Here we check if user has agency
			// Getting the agencies	
			$agency_id=get_user_meta( $user_id, YO_METABOX_PREFIX. 'my_agency_term_id', true );
			$rank_user=get_user_meta( $user_id, YO_METABOX_PREFIX. 'user_rank', true );
			// NOW LETS RETURN AFTER CHECING IF AGENT HAS AGENCY
			if(!empty($rank_user)){
				$rank_user = intval($rank_user);
			}
			else{
				$rank_user = 0;
			}
			
			// LETS CHECK THE RANK AND SEE IF USER IS UP TO SUPER AGET
			if($rank_user >= $rank){
				// NOW LETS START CHECKING THE RANK
				if(!empty($agency_id) && intval($agency_id)>0){
					return true;
				}
				else{
					return false;
				}
			}
			else{
				// We still return false
				return false;
			}
			// End of method
		 }
		 
		 /**
         * referral_ajax
         */
		 private function patch_ranking($user_id){
			 // HERE WE CONSTRUCT RANKING THE AGENT THAT WAS PATCHED
			 // This will be built when the ranking system is made
			 //GRAB ALL OPTIONS
			 $options = yo_get_option("agency");
			 $patch_option = $options["patching"];
			 $rank = intval($patch_option["rank"]);
			 $new_rank = 0;
			 // Lets get the user rank data
			 $user_rank = get_user_meta( $user_id, YO_METABOX_PREFIX. 'patch_rank', true );
			 // We check if user rank is empty or not
			 if(!empty($user_rank)){
				// Now lets add up
				$user_rank=intval($user_rank);
				$new_rank=$user_rank + $rank;
			 }
			 else{
				 // Lets set user rank
				 $new_rank = $rank;
			 }
			 
			 // NOW LETS STORE THE NEW RANK
			 update_user_meta( $user_id, YO_METABOX_PREFIX. 'patch_rank', $new_rank );
			 
		 }
		 
		 /**
         * referral_ajax
         */
		 public function patch_benefit($package_price){
			 // HERE WE CONSTRUCT THE PATCH BENEFIT FUNCTIONALITY
			 // ONLY HAPPENS ON PACKAGE RENEWAL
			 $trueValue = 0;
			 // More to write here to deduct the benefit percentage from user substription
			 if ( is_user_logged_in()) {
				// LETS PROMOTE AGENT ITEM
				global $current_user;
             	wp_get_current_user();
				$user_id = $current_user->ID;
				$options = yo_get_option("agency");
				$patch_option=$options["patching"];
				$benefit_option=$patch_option["benefit"];
				$rate=$benefit_option["rate"];
				$approval=$benefit_option["approval"];
				$benefit=intval(get_user_meta( $user_id, YO_METABOX_PREFIX. 'benefit', true));
				
				// LETS CALCULATE PERCENTAGE OF THE BENEFIT FROM PACKAGE PRICE
				$rate_cal=(intval($package_price)/100)*intval($rate);
				$package_remain=$package_price-$rate_cal;
				$benefit_pay=1;
				// Lets check if user has credit before
				$credit = get_user_meta( $user_id, YO_METABOX_PREFIX. 'patch_credit', true );
				$pay = get_user_meta( $user_id, YO_METABOX_PREFIX. 'benefit_pay', true );
				if(!empty($credit)){
					// We increment credit instead
					$rate_cal=$rate_cal + $credit;
				}
				
				if(!empty($pay)){
					// We increment number of pay
					$benefit_pay=$pay + $benefit_pay;
				}
				
				// Now lets check the approval
				if($approval=="yes"){
					// Now lets set the meta that we can use to credit the agency
					// On user renewing the package
					update_user_meta( $user_id, YO_METABOX_PREFIX. 'patch_credit', $rate_cal );
					update_user_meta( $user_id, YO_METABOX_PREFIX. 'benefit_pay', $benefit_pay );
					update_user_meta( $user_id, YO_METABOX_PREFIX. 'benefit_cycle', "package_renewal" );
					update_user_meta( $user_id, YO_METABOX_PREFIX. 'benefit', 1 );	
					update_user_meta( $user_id, YO_METABOX_PREFIX . 'after_benefit_remain', $package_remain );
					// NOW LETS RETURN THE PACKAGE REMAINING
					return $trueValue = 1;
					// End of method
				}
			}
		 }
		 
		 /**
         * referral_ajax
         */
		 private function patch_message($agency_id, $agent_id){
			 // LETS START PROCESSING THE PATCH MESSAGING
			 global $current_user;
             wp_get_current_user();
			 $user_id = $current_user->ID;
			 // LETS GET OPTIONS
			 $option= yo_get_option("messaging");
			 $message_option= $option["message"]['agency'];
			 $messages=array();
			 // SETTING USER MESSAGING OPTIONS
			 $username=$current_user->user_login;
			 $email=$current_user->user_email;
			 $email_type="user_mail";
			 $request="agency";
			 yo_send_email($email, $email_type, $request);
			 
			 // SETTING ADMIN MESSAGING OPTIONS
			 $args = array(
             'agent_name' => $full_name,
             'agent_url' => get_permalink($agent_id)
              );
              $admin_email = get_bloginfo('admin_email');
              yo_send_email($admin_email, 'admin_mail', 'agency', $args);
			  
			  // SANITIZING AND REPLACING NAMES
			  $args=array();
			  $args ['website_url'] = get_option('siteurl');
        	  $args ['website_name'] = get_option('blogname');
        	  $args ['user_email'] = $email;
        	  $args ['username'] = $username;

        	  foreach($args as $key => $val){
            		$title = str_replace('%' . $key, $val, $message_option["title"]);
            		$content = str_replace('%' . $key, $val, $message_option["content"]);
        	  }
			  
			  /************* NOW LETS MESSAGE AGENCY TO NOTIFY THEM OF THE PATCH **************/
			  $new_agency['post_type'] = 'falzo_message';
			  $new_agency['post_author'] = $user_id;
			  $new_agency['post_title']= $title;
			  $new_agency['post_content']= $content;
		      $new_agency['post_status'] = 'publish';
			  // Now lets insert post to the database
			  $message_id = wp_insert_post( $new_referral, true );
			  if ( $message_id > 0 ) {
				// Activation date format
				$time = time();
            	$date = date('Y-m-d H:i:s', $time);
				// Lets add to user meta
				update_post_meta( $message_id, YO_METABOX_PREFIX. 'agency_id', $agency_id );
				update_post_meta( $message_id, YO_METABOX_PREFIX. 'agent_id', $agent_id );
				update_post_meta( $message_id, YO_METABOX_PREFIX. 'message_status', "unread" );
				update_post_meta( $message_id, YO_METABOX_PREFIX. 'message_date', $date );
				
				// We have to make sure we keep record of users messages
				$messages = update_user_meta( $user_id, YO_METABOX_PREFIX. 'user_messages' );
				if(!empty($messages)){
					$messages[] = $message_id;	
				}
				else{
					$messages[] = $message_id;
				}
				
				// NOW LETS ADD USER MESSAGES ID
				update_user_meta( $user_id, YO_METABOX_PREFIX. 'user_messages', $messages );  
			  }  
		 }
		 
		 /**
         * referral_ajax
         */
		 public function message_alert(){
			 // LETS CONSTRUCT THE MESSAGE ALERTING
			 if ( is_user_logged_in()) {
				// LETS PROMOTE AGENT ITEM
				global $current_user;
             	wp_get_current_user();
				$user_id = $current_user->ID;
				// FIRST WE MAKE SURE THIS HAPPENS FOR USER THAT HAS PATCHES
				if($this->agency_check() == true){
					// NOW LETS GET THE MESSAGE ID
					$message_details = array();
					// HERE WE LOG MESSAGE DETAILS TO JSON
					// Setting the argument
			 		$args = array(
			 		'post_type' => 'falzo_message',
			 		'post_status' => 'publish',
					'author' => $user_id,
					'meta_query' => array(
						array(
						'key' => YO_METABOX_PREFIX. 'message_status',
						'value' => 'unread',
								),
							)
						);
			 	 	// Lets get the post
			 	 	$posts = get_posts( $args );
				 	if($posts->found_posts){
						// Now we loop to get indivual post
						foreach($posts as $post){
							// We make sure we found post
							setup_postdata( $posts );
							$title = the_title();
							$content = the_content();
							$date = get_post_meta( $message_id, YO_METABOX_PREFIX. 'message_date', true );
							// Lets add to our array details
							$message_details[]=array('title' => $title, 'content' => $content, 'date' => $date);
						} // End of loop
						
						// Reset wordpress post data
						wp_reset_postdata();
						// Lets echo the json data
						echo '<div class="modal modal-login fade" id="yo_alert_modal" tabindex="-1" role="dialog">';
						echo '<div class="modal-dialog" role="document">';
						echo '<div class="modal-content">';
						echo '<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                    aria-hidden="true">&times;</span></button>';
						echo '<div class="tab-content ">';
						echo '<div class="tab-pane active" id="login">';
						echo '<div class="ere-login-wrap">';
						echo '<div id="ere_messages_login" class="ere_messages message"><h2>'.$message_details['title'].'</h2><p>'.$message_details['content'].'</p>'.$message_details['date'].'</div>';
						
						echo '<div class="row"><div class="col-sm-6"> <h4 class="ere-dashboard-title">Click Ok to stop this popup from displaying</h4></div><div class="col-sm-6 text-right"><a id="yo-reader" class="btn btn-default" data-message_id="'.$post->ID.'" href="#">OK</a>
    </div></div>';
						
						echo '</div>';
						echo '</div>';
						echo '</div>';
						echo '</div>';
						echo '</div>';
						echo '</div>';
						
						// Lets get beyot template
						ere_get_template('global/tmpl-template.php');
				 	}
				}
			 }
		 }
		 
		 /**
         * referral_ajax
         */
		 public function stop_alert(){
			 // LETS CONSTRUCT THE MESSAGE ALERTING
			 $trueValue = -1;
			 if(isset($_POST["message_id"])){
			 	$message_id = $_POST["message_id"];
				// Lets update the status field
			 	update_post_meta( $message_id, YO_METABOX_PREFIX. 'message_status', "read" );
				
				$trueValue = 1;
			 }
			 
			 print $trueValue;
			 wp_die();
		 }
		 
		 /**
         * referral_ajax
         */
		 public function agency_check(){
			// HERE WE CONSTRUCT THE AGENCY CHECKING
			// Here we check if user has agency 
			// LETS PROMOTE AGENT ITEM
			global $current_user;
            wp_get_current_user();
			$user_id = $current_user->ID;
			// Getting the agencies	
			$agencies=get_user_meta( $user_id, YO_METABOX_PREFIX. 'agency_ids', true );
			// NOW LETS RETURN AFTER CHECING IF AGENT HAS AGENCY
			if(!empty($agencies)){
				return true;
			}
			else{
				return false;
			}
			// End of method
		 }

	// END OF CLASS
	}
}
?>