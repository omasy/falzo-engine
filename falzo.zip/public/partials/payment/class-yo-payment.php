<?php
if (!defined('ABSPATH')) {
    exit;
}
if (!class_exists('YO_Payment')) {
    /**
     * Class ERE_Payment
     */
    class YO_Payment
    {
        protected $yo_logger;

        /**
         * Construct
         */
        public function __construct()
        {
			// Setting the logger variables
			$this->yo_logger = new YO_Logger();
        }

        /**
         * Payment package by stripe
         * @param $package_id
         */
        public function stripe_payment_patch($patch_id)
        {
            require_once(ERE_PLUGIN_DIR . 'public/partials/payment/stripe-php/init.php');
            $stripe_secret_key = ere_get_option('stripe_secret_key');
            $stripe_publishable_key = ere_get_option('stripe_publishable_key');

            $current_user = wp_get_current_user();

            $user_id = $current_user->ID;
            $user_email = get_the_author_meta('user_email', $user_id);

            $stripe = array(
                "secret_key" => $stripe_secret_key,
                "publishable_key" => $stripe_publishable_key
            );

            \Stripe\Stripe::setApiKey($stripe['secret_key']);
            $patch_price = get_post_meta( $patch_id, YO_METABOX_PREFIX. 'patch_price', true );
            $patch_name = get_the_title($patch_id);

            $currency_code = ere_get_option('currency_code', 'USD'); // Here i am changing the currency code to naira
            // $patch_price = $patch_price * 100;
            $payment_completed_link = ere_get_permalink('payment_completed');
            $stripe_processor_link = add_query_arg(array('payment_method' => 2, 'falzo_request' => 2), $payment_completed_link);
            print '<form action="' . $stripe_processor_link . '" method="post" id="ere_stripe_per_package">
            <div class="ere_stripe_per_package ere_payment_stripe" id="' . sanitize_title($patch_name) . '">
                <script src="https://checkout.stripe.com/checkout.js" id="stripe_script"
                class="stripe-button"
                data-key="' . $stripe_publishable_key . '"
                data-amount="' . $patch_price . '"
                data-email="' . $user_email . '"
                data-currency="' . $currency_code . '"
                data-zip-code="true"
                data-billing-address="true"
                data-label="' . __('Pay with Credit Card', 'essential-real-estate') . '"
                data-description="' . $patch_name . ' ' . __('Patching Payment', 'falzo') . '">
                </script>
            </div>
            <input type="hidden" id="package_id" name="patch_id" value="' . $patch_id . '">
            <input type="hidden" name="user_id" value="' . $user_id . '">
			<input type="hidden" name="payment" value="patch_payment">
            <input type="hidden" id="payment_money" name="payment_money" value="' . $patch_price . '">
            </form>';
        }

        /**
         * Payment per listing by stripe
         * @param $property_id
         * @param $price_submission
         */
        public function stripe_payment_promotion($promotion_id, $promotion_amount)
        {
            require_once(ERE_PLUGIN_DIR . 'public/partials/payment/stripe-php/init.php');
            $stripe_secret_key = ere_get_option('stripe_secret_key');
            $stripe_publishable_key = ere_get_option('stripe_publishable_key');

            $stripe = array(
                "secret_key" => $stripe_secret_key,
                "publishable_key" => $stripe_publishable_key
            );
            \Stripe\Stripe::setApiKey($stripe['secret_key']);
            $currency_code = ere_get_option('currency_code', 'USD'); // Here i changed currency to naira
            $current_user = wp_get_current_user();
            $user_id = $current_user->ID;
            $user_email = $current_user->user_email;
            $price_submission = $promotion_amount;
            // $price_submission = $price_featured_submission * 100;

            $payment_completed_link = ere_get_permalink('payment_completed');
            $stripe_processor_link = add_query_arg(array('payment_method' => 2, 'falzo_request' => 2), $payment_completed_link);
            print '<form action="' . $stripe_processor_link . '" method="post" id="ere_stripe_per_listing">
            <div class="ere_stripe_per_listing ere_payment_stripe">
                <script src="https://checkout.stripe.com/checkout.js"
                class="stripe-button"
                data-key="' . $stripe_publishable_key . '"
                data-amount="' . $price_submission . '"
                data-email="' . $user_email . '"
                data-zip-code="true"
                data-currency="' . $currency_code . '"
                data-label="' . esc_html__('Promoting Property', 'essential-real-estate') . '"
                data-description="' . esc_html__('Promoting Property', 'essential-real-estate') . '">
                </script>
            </div>
            <input type="hidden" id="property_id" name="promotion_id" value="' . $promotion_id . '">
            <input type="hidden" name="user_id" value="' . $user_id . '">
			<input type="hidden" name="payment" value="promotion_payment">
            <input type="hidden" id="payment_money" name="payment_money" value="' . $price_submission . '">
             </form>';
        }

        /**
         * Get paypal access token
         * @param $url
         * @param $postArgs
         * @return mixed
         */
        private function get_paypal_access_token($url, $postArgs)
        {
            $client_id = ere_get_option('paypal_client_id');
            $secret_key = ere_get_option('paypal_client_secret_key');

            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_USERPWD, $client_id . ":" . $secret_key);
            curl_setopt($curl, CURLOPT_HEADER, false);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $postArgs);
            $response = curl_exec($curl);
            if (empty($response)) {
                die(curl_error($curl));
                curl_close($curl);
            } else {
                $info = curl_getinfo($curl);
                curl_close($curl);
                if ($info['http_code'] != 200 && $info['http_code'] != 201) {
                    echo "Received error: " . $info['http_code'] . "\n";
                    echo "Raw response:" . $response . "\n";
                    die();
                }
            }
            $response = json_decode($response);
            return $response->access_token;
        }

        /**
         * Execute paypal request
         * @param $url
         * @param $jsonData
         * @param $access_token
         * @return array|mixed|object
         */
        private function execute_paypal_request($url, $jsonData, $access_token)
        {
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_HEADER, false);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Authorization: Bearer ' . $access_token,
                'Accept: application/json',
                'Content-Type: application/json'
            ));

            curl_setopt($curl, CURLOPT_POSTFIELDS, $jsonData);
            $response = curl_exec($curl);
            if (empty($response)) {
                die(curl_error($curl));
                curl_close($curl);
            } else {
                $info = curl_getinfo($curl);
                curl_close($curl);
                if ($info['http_code'] != 200 && $info['http_code'] != 201) {
                    echo "Received error: " . $info['http_code'] . "\n";
                    echo "Raw response:" . $response . "\n";
                    die();
                }
            }
            $jsonResponse = json_decode($response, TRUE);
            return $jsonResponse;
        }

        /**
         * Payment per listing by Paypal
         */
        public function paypal_payment_patch_ajax()
        {
            check_ajax_referer('ere_payment_ajax_nonce', 'ere_security_payment');
            global $current_user;
            $patch_id = $_POST['patch_id'];
            $patch_id = intval($patch_id);

            $payment_for = $_POST['payment_for'];
            $payment_for = intval($payment_for);
			
            $price_per_submission = get_post_meta( $patch_id, YO_METABOX_PREFIX. 'patch_price', $patch_price );
            $currency = ere_get_option('currency_code', 'USD'); // Here i changed currency code to naira

            $blogInfo = esc_url(home_url());

            wp_get_current_user();
            $user_id = $current_user->ID;
            $post = get_post($property_id);

            if ($post->post_author != $user_id) {
                wp_die('No Permission');
            }

            $is_paypal_live = ere_get_option('paypal_api');
            $host = 'https://api.sandbox.paypal.com';
            $price_per_submission = floatval($price_per_submission);
            $price_featured_submission = floatval($price_featured_submission);
            $submission_curency = esc_html($currency);
            $payment_description = esc_html__('Patch payment on ', 'falzo') . $blogInfo;
            $total_price = $price_per_submission;
            // Here i erased price logic for featured check
            if ($is_paypal_live == 'live') {
                $host = 'https://api.paypal.com';
            }

            $url = $host . '/v1/oauth2/token';
            $postArgs = 'grant_type=client_credentials';

            $access_token = $this->get_paypal_access_token($url, $postArgs);
            $url = $host . '/v1/payments/payment';
            $cancel_link = yo_get_permalink('patch');
            $payment_completed_link = ere_get_permalink('payment_completed');
            $return_link = add_query_arg(array('payment_method' => 1, 'falzo_request' => 1), $payment_completed_link);
            $payment = array(
                'intent' => 'sale',
                "redirect_urls" => array(
                    "return_url" => $return_link,
                    "cancel_url" => $cancel_link
                ),
                'payer' => array("payment_method" => "paypal"),
            );

            $payment['transactions'][0] = array(
                'amount' => array(
                    'total' => $total_price,
                    'currency' => $submission_curency,
                    'details' => array(
                        'subtotal' => $total_price,
                        'tax' => '0.00',
                        'shipping' => '0.00'
                    )
                ),
                'description' => $payment_description
            );
           $payment['transactions'][0]['item_list']['items'][] = array(
                    'quantity' => '1',
                    'name' => esc_html__('Patch Payment', 'falzo'),
                    'price' => $total_price,
                    'currency' => $submission_curency,
                    'sku' => 'Paid Patching',
             );
            $jsonEncode = json_encode($payment);
            $json_response = $this->execute_paypal_request($url, $jsonEncode, $access_token);
            $payment_approval_url = $payment_execute_url = '';
            foreach ($json_response['links'] as $link) {
                if ($link['rel'] == 'execute') {
                    $payment_execute_url = $link['href'];
                } else if ($link['rel'] == 'approval_url') {
                    $payment_approval_url = $link['href'];
                }
            }
            $output['payment_execute_url'] = $payment_execute_url;
            $output['access_token'] = $access_token;
            $output['patch_id'] = $patch_id;
			$output['payment'] = "patch_payment";
            update_user_meta($user_id, ERE_METABOX_PREFIX . 'paypal_transfer', $output);
            print $payment_approval_url;
            wp_die();
        }

        /**
         * Payment per package by Paypal
         */
        public function paypal_payment_promotion_ajax()
        {
            check_ajax_referer('ere_payment_ajax_nonce', 'ere_security_payment');
            global $current_user;
            wp_get_current_user();
            $user_id = $current_user->ID;

            $blogInfo = esc_url(home_url());

            $promotion_id = $_POST['promotion_id'];
            $promotion_id = intval($promotion_id);
            $promotion_price = get_post_meta( $promotion_id, YO_METABOX_PREFIX. 'promotion_amount', $amount );
            $promotion_name = get_the_title($promotion_id);

            if (empty($promotion_price) && empty($promotion_id)) {
                exit();
            }
            $currency = ere_get_option('currency_code', 'USD'); // Here we are getting currency as naira
            $payment_description = $promotion_name . ' ' . esc_html__('Promotion payment on ', 'falzo') . $blogInfo;
            $is_paypal_live = ere_get_option('paypal_api');
            $host = 'https://api.sandbox.paypal.com';
            if ($is_paypal_live == 'live') {
                $host = 'https://api.paypal.com';
            }
            $url = $host . '/v1/oauth2/token';
            $postArgs = 'grant_type=client_credentials';
            $access_token = $this->get_paypal_access_token($url, $postArgs);
            $url = $host . '/v1/payments/payment';
            $payment_completed_link = ere_get_permalink('payment_completed');
            $return_url = add_query_arg(array('payment_method' => 1, 'falzo_request' => 1), $payment_completed_link);
            $dash_profile_link = yo_get_permalink('my_promotion');

            $payment = array(
                'intent' => 'sale',
                "redirect_urls" => array(
                    "return_url" => $return_url,
                    "cancel_url" => $dash_profile_link
                ),
                'payer' => array("payment_method" => "paypal"),
            );


            $payment['transactions'][0] = array(
                'amount' => array(
                    'total' => $promotion_price,
                    'currency' => $currency,
                    'details' => array(
                        'subtotal' => $promotion_price,
                        'tax' => '0.00',
                        'shipping' => '0.00'
                    )
                ),
                'description' => $payment_description
            );

            $payment['transactions'][0]['item_list']['items'][] = array(
                'quantity' => '1',
                'name' => esc_html__('Payment Package', 'essential-real-estate'),
                'price' => $promotion_price,
                'currency' => $currency,
                'sku' => $promotion_name . ' ' . esc_html__('Payment Promotion', 'essential-real-estate'),
            );

            $jsonEncode = json_encode($payment);
            $json_response = $this->execute_paypal_request($url, $jsonEncode, $access_token);
            $payment_approval_url = $payment_execute_url = '';
            foreach ($json_response['links'] as $link) {
                if ($link['rel'] == 'execute') {
                    $payment_execute_url = $link['href'];
                } else if ($link['rel'] == 'approval_url') {
                    $payment_approval_url = $link['href'];
                }
            }
            $output['payment_execute_url'] = $payment_execute_url;
            $output['access_token'] = $access_token;
            $output['promotion_id'] = $promotion_id;
			$output['payment'] = "promotion_payment";
            update_user_meta($user_id, ERE_METABOX_PREFIX . 'paypal_transfer', $output);

            print $payment_approval_url;
            wp_die();
        }

        /**
         * Payment per package by wire transfer
         */
        public function wire_transfer_patch_ajax()
        {
            check_ajax_referer('ere_payment_ajax_nonce', 'ere_security_payment');
            global $current_user;
            $current_user = wp_get_current_user();

            if (!is_user_logged_in()) {
                exit('No Login');
            }
            $user_id = $current_user->ID;
            $user_email = $current_user->user_email;
            $admin_email = get_bloginfo('admin_email');
            $patch_id = $_POST['patch_id'];
            $patch_id = intval($patch_id);
            $total_price = get_post_meta( $patch_id, YO_METABOX_PREFIX. 'patch_price', $patch_price );
            $total_price = ere_get_format_money($total_price);
            $payment_method = 'Wire_Transfer';
            // insert invoice
            $invoice_id = $this->yo_logger->insert_invoice('patch_payment', $patch_id, $user_id, 0, $payment_method, 0);
            $args = array(
                'invoice_no' => $invoice_id,
                'total_price' => $total_price
            );
            /*
             * Send email
             * */
            yo_send_email($user_email, 'user_mail', 'mail_new_wire_transfer_patch', $args);
            yo_send_email($admin_email, 'admin_mail', 'admin_mail_new_wire_transfer_patch', $args);
            $payment_completed_link = ere_get_permalink('payment_completed');
            $return_link = add_query_arg(array('payment_method' => 3, 'order_id' => $invoice_id), $payment_completed_link);
            print $return_link;
            wp_die();
        }

        /**
         * Payment per listing by wire transfer
         */
        public function wire_transfer_promotion_ajax()
        {
            check_ajax_referer('ere_payment_ajax_nonce', 'ere_security_payment');
            $current_user = wp_get_current_user();
            if (!is_user_logged_in()) {
                exit('No Login');
            }
            $user_id = $current_user->ID;
            $user_email = $current_user->user_email;
            $admin_email = get_bloginfo('admin_email');
            $promotion_id = $_POST['promotion_id'];
            $promotion_id = intval($promotion_id);

            $payment_method = 'Wire_Transfer';
			// insert invoice
            $invoice_id = $this->yo_logger->insert_invoice('promotion_payment', $promotion_id, $user_id, 0, $payment_method, 0);
            $args = array(
                'Promotion_title' => get_the_title($promotion_id),
                'Promotion_id' => $promotion_id,
                'invoice_no' => $invoice_id,
             );
            //xem l?i mail
			yo_send_email($user_email, 'user_mail', 'mail_new_wire_transfer_promotion', $args);
            yo_send_email($admin_email, 'admin_mail', 'admin_mail_new_wire_transfer_promotion', $args);
            $payment_completed_link = ere_get_permalink('payment_completed');
            $return_link = add_query_arg(array('payment_method' => 3, 'order_id' => $invoice_id), $payment_completed_link);
            print $return_link;
            wp_die();
        }
		
        /**
         * Payment per package by wire transfer
         */
        public function bank_deposit_patch_ajax()
        {
            check_ajax_referer('ere_payment_ajax_nonce', 'ere_security_payment');
            global $current_user;
            $current_user = wp_get_current_user();

            if (!is_user_logged_in()) {
                exit('No Login');
            }
            $user_id = $current_user->ID;
            $user_email = $current_user->user_email;
            $admin_email = get_bloginfo('admin_email');
            $patch_id = $_POST['patch_id'];
            $patch_id = intval($patch_id);
            $total_price = get_post_meta( $patch_id, YO_METABOX_PREFIX. 'patch_price', $patch_price );
            $total_price = ere_get_format_money($total_price);
            $payment_method = 'Bank_Deposit';
            // insert invoice
            $invoice_id = $this->yo_logger->insert_invoice('patch_payment', $patch_id, $user_id, 0, $payment_method, 0);
            $args = array(
                'invoice_no' => $invoice_id,
                'total_price' => $total_price
            );
            /*
             * Send email
             * */
            yo_send_email($user_email, 'user_mail', 'mail_new_bank_deposit_patch', $args);
            yo_send_email($admin_email, 'admin_mail', 'admin_mail_new_bank_deposit_patch', $args);
            $payment_completed_link = ere_get_permalink('payment_completed');
            $return_link = add_query_arg(array('payment_method' => 4, 'order_id' => $invoice_id), $payment_completed_link);
            print $return_link;
            wp_die();
        }
		
		
		/**
         * Payment per listing by wire transfer
         */
		public function bank_deposit_promotion_ajax()
        {
            check_ajax_referer('ere_payment_ajax_nonce', 'ere_security_payment');
            $current_user = wp_get_current_user();
            if (!is_user_logged_in()) {
                exit('No Login');
            }
            $user_id = $current_user->ID;
            $user_email = $current_user->user_email;
            $admin_email = get_bloginfo('admin_email');
            $promotion_id = $_POST['promotion_id'];
            $promotion_id = intval($promotion_id);

            $payment_for = $_POST['payment_for'];
            $payment_for = intval($payment_for);
            $payment_method = 'Bank_Deposit';
            $invoice_id = $this->yo_logger->insert_invoice('promotion_payment', $promotion_id, $user_id, 1, $payment_method, 0);
            $args = array(
               'promotion_title' => get_the_title($promotion_id),
               'promotion_id' => $promotion_id,
               'invoice_no' => $invoice_id,
             );
            //xem l?i mail
			yo_send_email($user_email, 'user_mail', 'mail_new_bank_deposit_promotion', $args);
            yo_send_email($admin_email, 'admin_mail', 'admin_mail_new_bank_deposit_promotion', $args);
			
            $payment_completed_link = ere_get_permalink('payment_completed');
            $return_link = add_query_arg(array('payment_method' => 4, 'order_id' => $invoice_id), $payment_completed_link);
            print $return_link;
            wp_die();
        }
		
		
        /**
         * stripe_payment_completed
         */
        public function stripe_payment_completed()
        {
            require_once(ERE_PLUGIN_DIR . 'public/partials/payment/stripe-php/init.php');
            $allowed_html = array();
            $current_user = wp_get_current_user();
            $user_id = $current_user->ID;
            $user_email = $current_user->user_email;
            $admin_email = get_bloginfo('admin_email');
            $currency_code = ere_get_option('currency_code', 'USD'); // Setting currency to Naira
            $payment_method = 'Stripe';
            $stripe_secret_key = ere_get_option('stripe_secret_key');
            $stripe_publishable_key = ere_get_option('stripe_publishable_key');
            $stripe = array(
                "secret_key" => $stripe_secret_key,
                "publishable_key" => $stripe_publishable_key
            );
            \Stripe\Stripe::setApiKey($stripe['secret_key']);
            $stripeEmail = '';
            if (is_email($_POST['stripeEmail'])) {
                $stripeEmail = wp_kses(esc_html($_POST['stripeEmail']), $allowed_html);
            } else {
                wp_die('None Mail');
            }
			
			if(isset($_POST['payment'])){
				$paid_submission_type = $_POST['payment'];
			}
			
            if (isset($_POST['user_id']) && !is_numeric($_POST['user_id'])) {
                die();
            }

            if (isset($_POST['patch_id']) && !is_numeric($_POST['patch_id'])) {
                die();
            }

            if (isset($_POST['promotion_id']) && !is_numeric($_POST['promotion_id'])) {
                die();
            }

            if (isset($_POST['payment_money']) && !is_numeric($_POST['payment_money'])) {
                die();
            }
			
            $payment_for = 0;
            $paymentId = 0;
			
            try {
                $token = wp_kses($_POST['stripeToken'], $allowed_html);
                $payment_money = $_POST['payment_money'];
                $payment_money = intval($payment_money);
                $customer = \Stripe\Customer::create(array(
                    "email" => $stripeEmail,
                    "source" => $token
                ));
                $charge = \Stripe\Charge::create(array(
                    "amount" => $payment_money,
                    'customer' => $customer->id,
                    "currency" => $currency_code,
                ));
                $payerId = $customer->id;
                if (isset($charge->id) && (!empty($charge->id))) {
                    $paymentId = $charge->id;
                }
                $payment_Status = '';
                if (isset($charge->status) && (!empty($charge->status))) {
                    $payment_Status = $charge->status;
                }

                if ($payment_Status == "succeeded") {
                    if ($paid_submission_type == 'patch_payment') {
						//GRAB ALL OPTIONS
						$options = yo_get_option("agency");
						$patch_option=$options["patching"];
						$patch_price=$patch_option["price"];
                        $price_per_listing_with_featured = intval($price_per_listing) + intval($price_featured_listing);
                        //Payment Stripe listing
                        $patch_id = $_POST['patch_id'];
                        $patch_id = intval($patch_id);
                        // Here we check money
                        if ($payment_money != intval($patch_price)) {
                              	wp_die('No joke');
                                return;
                        }
						
                        $invoice_id = $this->yo_logger->insert_invoice('patch_payment', $patch_id, $user_id, 1, $payment_method, 1, $paymentId, $payerId);

                        update_post_meta( $patch_id, YO_METABOX_PREFIX . 'payment_status', 'paid');
                        $auto_publish = ere_get_option('auto_publish', 1);

                         if ($auto_publish == 1) {
                              	$post = array(
                                    'ID' => $patch_id,
                                    'post_status' => 'publish',
                                    'post_date' => current_time('mysql'),
                                    'post_date_gmt' => current_time('mysql'),
                                );
                                wp_update_post($post);
                          } else {
                                $post = array(
                                    'ID' => $patch_id,
                                    'post_status' => 'pending',
                                    'post_date' => current_time('mysql'),
                                    'post_date_gmt' => current_time('mysql'),
                                );
                                wp_update_post($post);
                            }

                            $args = array(
                                'patch_title' => get_the_title($patch_id),
                                'patch_id' => $patch_id,
                                'invoice_no' => $invoice_id,
                            );
							
							yo_send_email($user_email, 'user_mail', 'mail_new_stripe_patch', $args);
            				yo_send_email($admin_email, 'admin_mail', 'admin_mail_new_stripe_patch', $args);
							// End of the patch payment success logging
                    } else if ($paid_submission_type == 'promotion_payment') {
                        //Payment Stripe package
                        $promotion_id = $_POST['promotion_id'];
                        $promotion_id = intval($promotion_id);
                        $promotion_price = get_post_meta( $promotion_id, YO_METABOX_PREFIX. 'promotion_amount', true );
                        if ($payment_money != intval($promotion_price)) {
                            wp_die('No joke');
                            return;
                        }
                        // $this->ere_package->insert_user_package($user_id, $promotion_id);
                        $invoice_id = $this->yo_logger->insert_invoice('promotion_payment', $promotion_id, $user_id, 0, $payment_method, 1, $paymentId, $payerId);
						$auto_publish = ere_get_option('auto_publish', 1);
						update_post_meta($promotion_id, YO_METABOX_PREFIX . 'payment_status', 'paid');
                         if ($auto_publish == 1) {
                              	$post = array(
                                    'ID' => $promotion_id,
                                    'post_status' => 'publish',
                                    'post_date' => current_time('mysql'),
                                    'post_date_gmt' => current_time('mysql'),
                                );
                                wp_update_post($post);
                          } else {
                                $post = array(
                                    'ID' => $promotion_id,
                                    'post_status' => 'pending',
                                    'post_date' => current_time('mysql'),
                                    'post_date_gmt' => current_time('mysql'),
                                );
                                wp_update_post($post);
                            }

                            $args = array(
                                'promotion_title' => get_the_title($promotion_id),
                                'promotion_id' => $promotion_id,
                                'invoice_no' => $invoice_id,
                            );
                        
						// LETS SEND MAIL
						yo_send_email($user_email, 'user_mail', 'mail_new_stripe_promotion', $args);
            			yo_send_email($admin_email, 'admin_mail', 'admin_mail_new_stripe_promotion', $args);
                    }
                } else {
                    $message = esc_html__('Transaction failed', 'essential-real-estate');
                    if ($paid_submission_type == 'patch_payment') {
                        //Payment Stripe listing
                        $patch_id = $_POST['patch_id'];
                        $patch_id = intval($patch_id);
                        $this->yo_logger->insert_trans_log('patch_payment', $patch_id, $user_id, 3, $payment_method, 0, $paymentId, $payerId,0, $message);
						
                    } else if ($paid_submission_type == 'promotion_payment') {
                        //Payment Stripe package
                        $promotion_id = $_POST['promotion_id'];
                        $promotion_id = intval($promotion_id);
                        $this->yo_logger->insert_trans_log('promotion_payment', $promotion_id, $user_id, 0, $payment_method, 0, $paymentId, $payerId,0, $message);
                    }

                    $error = '<div class="alert alert-danger" role="alert">' . sprintf(__('<strong>Error!</strong> Transaction failed', 'essential-real-estate')) . '</div>';
                    print $error;
                }
            } catch (Exception $e) {
                $error = '<div class="alert alert-danger" role="alert"><strong>Error!</strong> ' . $e->getMessage() . '</div>';
                print $error;
            }
        }

        /**
         * paypal_payment_completed
         */
        public function paypal_payment_completed()
        {
            global $current_user;
            wp_get_current_user();
            $user_id = $current_user->ID;
            $user_email = $current_user->user_email;
            $admin_email = get_bloginfo('admin_email');
            $allowed_html = array();
            $payment_method = 'Paypal';
            // $paid_submission_type = ere_get_option('paid_submission_type', 'no');
            try {
                if (isset($_GET['token']) && isset($_GET['PayerID'])) {
                    $payerId = wp_kses($_GET['PayerID'], $allowed_html);
                    $paymentId = wp_kses($_GET['paymentId'], $allowed_html);
                    $transfered_data = get_user_meta($user_id, ERE_METABOX_PREFIX . 'paypal_transfer', true);
                    if(empty($transfered_data))
                    {
                        return;
                    }
                    $payment_execute_url = $transfered_data['payment_execute_url'];
                    $token = $transfered_data['access_token'];
					$paid_submission_type = $transfered_data['payment'];

                    $payment_execute = array(
                        'payer_id' => $payerId
                    );
                    $json = json_encode($payment_execute);
                    $json_response = $this->execute_paypal_request($payment_execute_url, $json, $token);
                    delete_user_meta($user_id, ERE_METABOX_PREFIX . 'paypal_transfer');
                    if ($json_response['state'] == 'approved') {
                        if ($paid_submission_type == 'patch_payment') {
                            $patch_id = $transfered_data['patch_id'];
                            // Here we log the payment invoice
                        	$invoice_id = $this->yo_logger->insert_invoice('patch_payment', $patch_id, $user_id, 1, $payment_method, 1, $paymentId, $payerId);

                            update_post_meta( $patch_id, YO_METABOX_PREFIX . 'payment_status', 'paid');
                            $paid_submission_status = ere_get_option('paid_submission_type', 'no');
                            $auto_publish = ere_get_option('auto_publish', 1);
                            if ($auto_publish == 1 && $paid_submission_status == 'per_listing') {
                                 $post = array(
                                     'ID' => $patch_id,
                                     'post_status' => 'publish',
                                     'post_date' => current_time('mysql'),
                                     'post_date_gmt' => current_time('mysql'),
                                  );
                                 wp_update_post($post);
                            } else {
                                $post = array(
                                 	'ID' => $patch_id,
                                    'post_status' => 'pending',
                                    'post_date' => current_time('mysql'),
                                    'post_date_gmt' => current_time('mysql'),
                                 );
                                wp_update_post($post);
                             }
                            $args = array(
                                 'patch_title' => get_the_title($patch_id),
                                 'patch_id' => $patch_id,
                                 'invoice_no' => $invoice_id,
                              );

						   yo_send_email($user_email, 'user_mail', 'mail_new_paypal_patch', $args);
            			   yo_send_email($admin_email, 'admin_mail', 'admin_mail_new_paypal_patch', $args);
								
                        } else if ($paid_submission_type == 'promotion_payment') {
                            $promotion_id = $transfered_data['promotion_id'];
                            // Here we log the payment invoice
                        	$invoice_id = $this->yo_logger->insert_invoice('promotion_payment', $promotion_id, $user_id, 1, $payment_method, 1, $paymentId, $payerId);

                            update_post_meta( $patch_id, YO_METABOX_PREFIX . 'payment_status', 'paid');
                            $paid_submission_status = ere_get_option('paid_submission_type', 'no');
                            $auto_publish = ere_get_option('auto_publish', 1);
                            if ($auto_publish == 1 && $paid_submission_status == 'per_listing') {
                                 $post = array(
                                     'ID' => $promotion_id,
                                     'post_status' => 'publish',
                                     'post_date' => current_time('mysql'),
                                     'post_date_gmt' => current_time('mysql'),
                                  );
                                 wp_update_post($post);
                            } else {
                                $post = array(
                                 	'ID' => $promotion_id,
                                    'post_status' => 'pending',
                                    'post_date' => current_time('mysql'),
                                    'post_date_gmt' => current_time('mysql'),
                                 );
                                wp_update_post($post);
                             }
                            $args = array(
                                 'promotion_title' => get_the_title($promotion_id),
                                 'promotion_id' => $promotion_id,
                                 'invoice_no' => $invoice_id,
                              );

                           yo_send_email($user_email, 'user_mail', 'mail_new_paypal_promotion', $args);
            			   yo_send_email($admin_email, 'admin_mail', 'admin_mail_new_paypal_promotion', $args);
                        }
                    } else {
                        $message = esc_html__('Transaction failed', 'essential-real-estate');
                        if ($paid_submission_type == 'patch_payment') {
                            $patch_id = $transfered_data['patch_id'];
                            $this->yo_logger->insert_trans_log('patch_payment', $patch_id, $user_id, 0, $payment_method, 0, $paymentId, $payerId,0, $message);
							
                        } else if ($paid_submission_type == 'promotion_payment') {
                            $promotion_id = $transfered_data['promotion_id'];
                            $this->yo_logger->insert_trans_log('promotion_payment', $promotion_id, $user_id, 0, $payment_method, 0, $paymentId, $payerId,0, $message);
                        }
                        $error = '<div class="alert alert-danger" role="alert">' . sprintf(__('<strong>Error!</strong> Transaction failed', 'essential-real-estate')) . '</div>';
                        print $error;
                    }
                }
            } catch (Exception $e) {
                $error = '<div class="alert alert-danger" role="alert"><strong>Error!</strong> ' . $e->getMessage() . '</div>';
                print $error;
            }
        }
    }
}