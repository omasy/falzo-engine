<?php
if (!defined('ABSPATH')) {
    exit;
}
if (!class_exists('YO_Logger')) {
    /**
     * Class ERE_Invoice
     */
    class YO_Logger
    {
		/**
         * Insert invoice
         * @param $payment_type
         * @param $item_id
         * @param $user_id
         * @param $payment_for
         * @param $payment_method
         * @param int $paid
         * @param string $payment_id
         * @param string $payer_id
         * @return int|WP_Error
         */
        public function insert_invoice( $payment_type, $item_id, $user_id,$payment_for, $payment_method,$paid=0,$payment_id='',$payer_id='' ) {
			//GRAB ALL OPTIONS
			$options = yo_get_option("agency");
			$patch_option = $options["patching"];
            $price_for_patch = $patch_option["price"];
            $price_for_patch = floatval( $price_per_submission );

            $price_for_promotion = get_post_meta( $item_id, YO_METABOX_PREFIX. 'promotion_amount', true );
            $price_for_promotion = floatval( $price_featured_submission );
            $total_money=0;
            // We make logic to select total money for patching or promotion
			if($payment_type == "patch_payment"){
				// HERE WE PROCESS PATCH TOTAL MONEY
				$total_money = $price_for_patch;
				
			}
			elseif($payment_type == "promotion_payment"){
				// HERE WE PROCESS PROMOTION TOTAL MONEY
				$total_money = $price_for_promotion;
			}
			
            $time = time();
            $invoice_date = date('Y-m-d H:i:s', $time);

            $ere_meta = array();
            $ere_meta['invoice_item_id'] = $item_id;
            $ere_meta['invoice_item_price'] = $total_money;
            $ere_meta['invoice_purchase_date'] = $invoice_date;
            $ere_meta['invoice_user_id'] = $user_id;
            $ere_meta['invoice_payment_type'] = $payment_type;
            $ere_meta['invoice_payment_method'] = $payment_method;
            $ere_meta['trans_payment_id'] = $payment_id;
            $ere_meta['trans_payer_id'] = $payer_id;
            $args = array(
                'post_title'	=> 'Invoice',
                'post_status'	=> 'publish',
                'post_type'     => 'invoice'
            );
            $invoice_id =  wp_insert_post( $args );
            update_post_meta( $invoice_id, ERE_METABOX_PREFIX. 'invoice_user_id', $user_id );
            update_post_meta( $invoice_id, ERE_METABOX_PREFIX. 'invoice_item_id', $item_id );
            update_post_meta( $invoice_id, ERE_METABOX_PREFIX. 'invoice_price', $total_money );
            update_post_meta( $invoice_id, ERE_METABOX_PREFIX. 'invoice_date', $invoice_date );
            update_post_meta( $invoice_id, ERE_METABOX_PREFIX. 'invoice_payment_type', $payment_type );
            update_post_meta( $invoice_id, ERE_METABOX_PREFIX. 'invoice_payment_method', $payment_method );
            update_post_meta( $invoice_id, ERE_METABOX_PREFIX. 'invoice_payment_status', $paid);

            update_post_meta( $invoice_id, ERE_METABOX_PREFIX. 'trans_payment_id', $payment_id);
            update_post_meta( $invoice_id, ERE_METABOX_PREFIX. 'trans_payer_id', $payer_id);

            update_post_meta( $invoice_id, ERE_METABOX_PREFIX. 'invoice_meta', $ere_meta );
            $update_post = array(
                'ID'         => $invoice_id,
                'post_title' => 'Invoice '.$invoice_id,
            );
            wp_update_post( $update_post );

            $ere_trans_log=new ERE_Trans_Log();
            $ere_trans_log->insert_trans_log($payment_type, $item_id, $user_id,$payment_for, $payment_method,$paid,$payment_id,$payer_id);

            return $invoice_id;
			
			// End of method
        }
		
		
		/**
         * Insert log
         * @param $payment_type
         * @param $item_id
         * @param $user_id
         * @param $payment_for
         * @param $payment_method
         * @param int $paid
         * @param string $payment_id
         * @param string $payer_id
         * @return int|WP_Error
         */
        public function insert_trans_log( $payment_type, $item_id, $user_id,$payment_for, $payment_method,$paid=0,$payment_id='',$payer_id='',$status=1,$message='' ) {

            //GRAB ALL OPTIONS
			$options = yo_get_option("agency");
			$patch_option = $options["patching"];
            $price_for_patch = $patch_option["price"];
            $price_for_patch = floatval( $price_per_submission );

            $price_for_promotion = get_post_meta( $item_id, YO_METABOX_PREFIX. 'promotion_amount', true );
            $price_for_promotion = floatval( $price_featured_submission );
            $total_money=0;
            // We make logic to select total money for patching or promotion
			if($payment_type == "patch_payment"){
				// HERE WE PROCESS PATCH TOTAL MONEY
				$total_money = $price_for_patch;
				
			}
			elseif($payment_type == "promotion_payment"){
				// HERE WE PROCESS PROMOTION TOTAL MONEY
				$total_money = $price_for_promotion;
			}
			
            $time = time();
            $trans_log_date = date('Y-m-d H:i:s', $time);

            $ere_meta = array();
            $ere_meta['trans_log_item_id'] = $item_id;
            $ere_meta['trans_log_item_price'] = $total_money;
            $ere_meta['trans_log_purchase_date'] = $trans_log_date;
            $ere_meta['trans_log_user_id'] = $user_id;
            $ere_meta['trans_log_payment_type'] = $payment_type;
            $ere_meta['trans_log_payment_method'] = $payment_method;
            $ere_meta['trans_payment_id'] = $payment_id;
            $ere_meta['trans_payer_id'] = $payer_id;
            $ere_meta['trans_log_message'] = $message;
            $args = array(
                'post_title'	=> 'Log',
                'post_status'	=> 'publish',
                'post_type'     => 'trans_log'
            );
            $trans_log_id =  wp_insert_post( $args );
            update_post_meta( $trans_log_id, ERE_METABOX_PREFIX. 'trans_log_user_id', $user_id );
            update_post_meta( $trans_log_id, ERE_METABOX_PREFIX. 'trans_log_item_id', $item_id );
            update_post_meta( $trans_log_id, ERE_METABOX_PREFIX. 'trans_log_price', $total_money );
            update_post_meta( $trans_log_id, ERE_METABOX_PREFIX. 'trans_log_date', $trans_log_date );
            update_post_meta( $trans_log_id, ERE_METABOX_PREFIX. 'trans_log_payment_type', $payment_type );
            update_post_meta( $trans_log_id, ERE_METABOX_PREFIX. 'trans_log_payment_method', $payment_method );
            update_post_meta( $trans_log_id, ERE_METABOX_PREFIX. 'trans_log_payment_status', $paid);
            update_post_meta( $trans_log_id, ERE_METABOX_PREFIX. 'trans_payment_id', $payment_id);
            update_post_meta( $trans_log_id, ERE_METABOX_PREFIX. 'trans_payer_id', $payer_id);
            update_post_meta( $trans_log_id, ERE_METABOX_PREFIX. 'trans_log_status', $status);
            update_post_meta( $trans_log_id, ERE_METABOX_PREFIX. 'trans_log_message', $message);
            update_post_meta( $trans_log_id, ERE_METABOX_PREFIX. 'trans_log_meta', $ere_meta );

            $update_post = array(
                'ID'         => $trans_log_id,
                'post_title' => 'Log '.$trans_log_id,
            );
            wp_update_post( $update_post );
            return $trans_log_id;
			
			// End of method
        }
		
		
		/**
         * get_invoice_meta
         * @param $post_id
         * @param bool|false $field
         * @return array|bool|mixed
         */
        public function get_invoice_meta($post_id, $field = false)
        {
            $defaults = array(
                'invoice_item_id' => '',
                'invoice_item_price' => '',
                'invoice_purchase_date' => '',
                'invoice_user_id' => '',
                'invoice_payment_type' => '',
                'invoice_payment_method' => '',
                'trans_payment_id' => '',
                'trans_payer_id' => '',
            );
            $meta = get_post_meta($post_id, ERE_METABOX_PREFIX . 'invoice_meta', true);
            $meta = wp_parse_args((array)$meta, $defaults);

            if ($field) {
                if (isset($meta[$field])) {
                    return $meta[$field];
                } else {
                    return false;
                }
            }
            return $meta;
        }
		
		
	
		/**
         * @param $payment_type
         * @return string
         */
        public static function get_invoice_payment_type($payment_type){
            switch ($payment_type) {
                case 'Package':
                    return esc_html__('Package','essential-real-estate');
                    break;
                case 'Listing':
                    return esc_html__('Listing','essential-real-estate');
                    break;
                case 'Upgrade_To_Featured':
                    return esc_html__('Upgrade to Featured','essential-real-estate');
                    break;
                case 'Listing_With_Featured':
                    return esc_html__('Listing with Featured','essential-real-estate');
                    break;
				case 'patch_payment':
                    return esc_html__('Agency Patching','essential-real-estate');
                    break;
				case 'promotion_payment':
                    return esc_html__('Property Promotion','essential-real-estate');
                    break;
                default:
                    return '';
            }
        }
		
		
		/**
         * @param $payment_method
         * @return string
         */
        public static function get_invoice_payment_method($payment_method){
            switch ($payment_method) {
                case 'Paypal':
                    return esc_html__('Paypal','essential-real-estate');
                    break;
                case 'Stripe':
                    return esc_html__('Stripe','essential-real-estate');
                    break;
                case 'Wire_Transfer':
                    return esc_html__('Wire Transfer','essential-real-estate');
                    break;
                case 'Free_Package':
                    return esc_html__('Free Package','essential-real-estate');
                    break;
				case 'Bank_Deposit':
                    return esc_html__('Bank Deposit','essential-real-estate');
                    break;
                default:
                    return '';
            }
        }
		
		
		/**
         * get_trans_log_meta
         * @param $post_id
         * @param bool|false $field
         * @return array|bool|mixed
         */
        public function get_trans_log_meta($post_id, $field = false)
        {
            $defaults = array(
                'trans_log_item_id' => '',
                'trans_log_item_price' => '',
                'trans_log_purchase_date' => '',
                'trans_log_user_id' => '',
                'trans_log_payment_type' => '',
                'trans_log_payment_method' => '',
                'trans_payment_id' => '',
                'trans_payer_id' => '',
            );
            $meta = get_post_meta($post_id, ERE_METABOX_PREFIX . 'trans_log_meta', true);
            $meta = wp_parse_args((array)$meta, $defaults);

            if ($field) {
                if (isset($meta[$field])) {
                    return $meta[$field];
                } else {
                    return false;
                }
            }
            return $meta;
        }
	
	// END OF CLASS	
	}
}
?>