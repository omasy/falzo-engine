<?php
if (!defined('ABSPATH')) {
    exit;
}
if (!class_exists('YO_Payment_ext')) {
    /**
     * Class ERE_Payment
     */
    class YO_Payment_ext
    {
        protected $ere_invoice;
        protected $ere_trans_log;

        /**
         * Construct
         */
        public function __construct()
        {
            $this->ere_invoice = new ERE_Invoice();
            $this->ere_trans_log = new ERE_Trans_Log();
        }
		
		/*************************** HERE WE ADD EXTRA PAYMENT SOLUTIONS TO EXTEND BEYOT FUNCTIONALITY *************************/
		/**
         * Payment per package by wire transfer
         */
        public function bank_deposit_per_package_ajax()
        {
            check_ajax_referer('ere_payment_ajax_nonce', 'ere_security_payment');
            global $current_user;
            $current_user = wp_get_current_user();

            if (!is_user_logged_in()) {
                exit('No Login');
            }
            $user_id = $current_user->ID;
            $user_email = $current_user->user_email;
            $admin_email = get_bloginfo('admin_email');
            $package_id = $_POST['package_id'];
            $package_id = intval($package_id);
            $total_price = get_post_meta($package_id, ERE_METABOX_PREFIX . 'package_price', true);
            $total_price = ere_get_format_money($total_price);
            $payment_method = 'Bank_Deposit';
            // insert invoice
            $invoice_id = $this->ere_invoice->insert_invoice('Package', $package_id, $user_id, 0, $payment_method, 0);
            $args = array(
                'invoice_no' => $invoice_id,
                'total_price' => $total_price
            );
            /*
             * Send email
             * */
            ere_send_email($user_email, 'mail_new_wire_transfer', $args);
            ere_send_email($admin_email, 'admin_mail_new_wire_transfer', $args);
            $payment_completed_link = ere_get_permalink('payment_completed');
            $return_link = add_query_arg(array('payment_method' => 4, 'order_id' => $invoice_id), $payment_completed_link);
            print $return_link;
            wp_die();
        }
		
		
		/**
         * Payment per listing by wire transfer
         */
		public function bank_deposit_per_listing_ajax()
        {
            check_ajax_referer('ere_payment_ajax_nonce', 'ere_security_payment');
            $current_user = wp_get_current_user();
            if (!is_user_logged_in()) {
                exit('No Login');
            }
            $user_id = $current_user->ID;
            $user_email = $current_user->user_email;
            $admin_email = get_bloginfo('admin_email');
            $property_id = $_POST['property_id'];
            $property_id = intval($property_id);

            $payment_for = $_POST['payment_for'];
            $payment_for = intval($payment_for);
            $payment_method = 'Bank_Deposit';
            if ($payment_for == 3) {
                $invoice_id = $this->ere_invoice->insert_invoice('Upgrade_To_Featured', $property_id, $user_id, 3, $payment_method, 0);
                $args = array(
                    'listing_title' => get_the_title($property_id),
                    'listing_id' => $property_id,
                    'invoice_no' => $invoice_id,
                );
                ere_send_email($user_email, 'mail_featured_submission_listing', $args);
                ere_send_email($admin_email, 'admin_mail_featured_submission_listing', $args);
            } else {
                if ($payment_for == 2) {
                    $invoice_id = $this->ere_invoice->insert_invoice('Listing_With_Featured', $property_id, $user_id, 2, $payment_method, 0);
                } else {
                    $invoice_id = $this->ere_invoice->insert_invoice('Listing', $property_id, $user_id, 1, $payment_method, 0);
                }
                $args = array(
                    'listing_title' => get_the_title($property_id),
                    'listing_id' => $property_id,
                    'invoice_no' => $invoice_id,
                );
                //xem l?i mail
                ere_send_email($user_email, 'mail_paid_submission_listing', $args);
                ere_send_email($admin_email, 'admin_mail_paid_submission_listing', $args);
            }
            $payment_completed_link = ere_get_permalink('payment_completed');
            $return_link = add_query_arg(array('payment_method' => 3, 'order_id' => $invoice_id), $payment_completed_link);
            print $return_link;
            wp_die();
        }
		
	}
}
?>