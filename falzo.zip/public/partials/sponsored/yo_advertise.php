<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('YO_Advertise')) {
    /**
     * The public-facing functionality of the plugin
     * Class ERE_Public
     */
    class YO_Advertise
	{
		/**
         * referral_ajax
         */
		 public function submit_advert(){
			 // LETS START PROCESSING THE ADVERT SUBMISSION PROCESS
			 // Checking user login and role
			 if ( is_user_logged_in()) {
				// LETS PROMOTE AGENT ITEM
				global $current_user;
             	wp_get_current_user();
				$user_id = $current_user->ID;
				// LETS GET THE FORM POST
				$Clean_Inputs=yo_clean_inputs($_POST);
				
				
			 }
			 // End of method
		 }
		 
		 /**
         * referral_ajax
         */
		 public function upload_advert_banner($advert_id){
			 
		 }
		 
		 /**
         * referral_ajax
         */
		 public function delete_advert(){
			 
		 }
		 
		 /**
         * referral_ajax
         */
		 public function monitor_advert(){
			 
		 }
		 
	}
}
?>