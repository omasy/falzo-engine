<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('YO_Promotion')) {
    /**
     * The public-facing functionality of the plugin
     * Class ERE_Public
     */
    class YO_Promotion
	{
		/**
         * promote
         */
		 public function promote_ajax($new_promotion=array()){
			 // $property_ids=$advert_specification=$advert_type=$duration=$amount=$position=$filter="";
			 // Now lets start processing
			 // Checking user login and role
			 if ( is_user_logged_in()) {
				// LETS PROMOTE AGENT ITEM
				global $current_user;
             	wp_get_current_user();
				$user_id = $current_user->ID;
				$Clean_Inputs=yo_clean_inputs($_POST);
				//GRAB ALL OPTIONS
				$options_sponsor = yo_get_option("sponsored");
				// Check if user already visited this page
				$property_ids = array();
				// Check cookie for list of visited posts
				if (isset($_COOKIE['yobek_promote_log'])) {
					// We expect list of comma separated post ids in the cookie
					$property_ids = $_COOKIE['yobek_promote_log'];
					
					// Lets get other promotion data
					$advert_specification=$Clean_Inputs["promotion_specification"];
					if(!empty($advert_specification)){
						// Lets get rest of of sponsor data	
						$duration=$options_sponsor["promotion"]["specification"][$advert_specification]["duration"];
						$amount=$options_sponsor["promotion"]["specification"][$advert_specification]["amount"];
						$position=$options_sponsor["position"];
						$filter=$options_sponsor["filter"];
			
						// NOW LETS POST ADVERT INTO THE WORDPRESS DATABASE AND META
						$new_promotion['post_type'] = 'falzo_promotion';
						$new_promotion['post_author'] = $user_id;
						$new_promotion['post_title']=$advert_specification;
						$new_promotion['post_content']=$advert_specification.' - duration: '.$duration.' and amount: '.$amount;
						$new_promotion['post_status'] = 'pending';
			
						// Now lets insert post to the database
						$promotion_id = wp_insert_post( $new_promotion, true );
						if ( $promotion_id > 0 ) {
							// Lets set post metas for promotion
							// Lets calculate promotion amount
							$properties = explode(',', $property_ids);
							if(is_array($properties)){
								$count_property=count($properties);
								// Lets set amount
								$amount=intval($amount)*$count_property;
							}
							
							// Here we try to get or add promotion ids of user
							$promote_array=array();
							$promoted=array();
							// LETS SET THE PATCHED AGENCY ARRAY IF ITS DOES NOT EXIST
							$promote_ids=get_user_meta( $user_id, YO_METABOX_PREFIX. 'promotion_ids', true );
							if(!empty($promote_ids)){
								// We update the patch agency array
								$promote_ids[]=$promotion_id;
								$promoted=$promote_ids;
							}
							else{
								// We create a new patch agency array
								$promote_array[]=$promotion_id;
								$promoted=$promote_array;	
							}
						
							// Activation date format
							$time = time();
            				$date = date('Y-m-d H:i:s', $time);
						
							// Now lets create meta data and attach it to post
							update_post_meta( $promotion_id, YO_METABOX_PREFIX. 'property_ids', $property_ids );
							update_post_meta( $promotion_id, YO_METABOX_PREFIX. 'promotion_duration', $duration );
							update_post_meta( $promotion_id, YO_METABOX_PREFIX. 'promotion_amount', $amount );
							update_post_meta( $promotion_id, YO_METABOX_PREFIX. 'promotion_position', $position );
							update_post_meta( $promotion_id, YO_METABOX_PREFIX. 'promotion_filter', $filter );
							update_post_meta( $promotion_id, YO_METABOX_PREFIX. 'promotion_specification', $advert_specification );
							update_post_meta( $promotion_id, YO_METABOX_PREFIX. 'promotion_items', $property_ids );
							update_post_meta($promotion_id, YO_METABOX_PREFIX. 'promotion_activate_date', $date);
							update_post_meta($promotion_id, YO_METABOX_PREFIX. 'user_id', $user_id);
							update_post_meta($promotion_id, YO_METABOX_PREFIX. 'promotion_extend', '');
							update_post_meta($promotion_id, YO_METABOX_PREFIX . 'payment_status', '');
							// update_post_meta($promotion_id, YO_PLUGIN_PREFIX. 'promotion_expire', "");
							update_user_meta($user_id, YO_METABOX_PREFIX . 'promotion_ids', $promoted);
							// do_action( 'wp_insert_post', 'wp_insert_post' );
							// Lets set promotion option
							// Updating the filter
							$options = get_option("falzo_options");
							if($options["promotion_available"] == 0){
								$options["promotion_available"] = 1;
							}
							// NOW LETS PROCEED TO UPDATIONG THE MODIFIED OPTIONS
							update_option("falzo_options", $options);
							// Lets unset the cookies
							// set the expiration date to one hour ago
							setcookie("yobek_promote_log", "", time() - 3600, '/', '.yobek.com');	
							// LETS RETURN THE PAYMENT PAGE
							$return_page = ere_get_permalink('payment');
							$return_link = add_query_arg(array('promotion_id' => $promotion_id, 'falzo_request' => 'promotion_payment'), $return_page);
							// We return link
							print $return_link;
							wp_die();
						}
					}
					else{
						// HERE WE PRINT ERROR NUMBER
						print -1;
					}
			 	}
				else{
					// HERE WE PRINT ERROR NUMBER
					print -1;	
				}
			 }
			// End of method
		 }
		 
		 /**
         * promotion expires date
         */
		 public function promotion_expires_date($promotion_id){
			// NOW LETS PROCESS EXPIRING DATE
			$expired_time=$this->promotion_expires_time($promotion_id); 
			// Now lets get expiring date
            $expired_date = date_i18n(get_option('date_format'), $expired_time);
			return $expired_date;
		 }
		 
		 /**
         * promotion expires time
         */
		 public function promotion_expires_time($promotion_id){
			// Lets calculate expiring time
			// Now lets get the expiring date
			$promotion_activated_date=strtotime(get_post_meta($promotion_id, YO_METABOX_PREFIX. 'promotion_activate_date',  true));
			$promotion_duration=get_post_meta($promotion_id, YO_METABOX_PREFIX. 'promotion_duration', true);
			$seconds = 0;
			$minutes=0;
			// Now lets start converting to second
			$minutes=intval($promotion_duration)*60;
			$seconds=$minutes*60;
			// Now lets set the expiring time
			$expired_time = $promotion_activated_date + $seconds;
			
			// Now lets get expiring time
			return $expired_date;
			
			// End of method
		 }
		 
		 /**
         * promotion extend
         */
		 public function get_total_promotion($post_status){
			// HERE WE CONSTRUCT THE PROMOTION FETCHER
			$args       = array(
				'post_type'   => 'falzo_promotion',
				'post_status' => $post_status,
				'author'      => get_current_user_id(),
			);
			$promotions = new WP_Query( $args );
			wp_reset_postdata();
			return $promotions->found_posts;
			
			// End of method
		 }
		 
		 /**
         * promotion extend
         */
		 public function promotion_extend($promotion_id){
			 // WE PROCESS THE PROMOTION EXTENDING
			 // Lets get the expiring date
			 $expired_date=$this->promotion_expires_time($promotion_id);
			 $today = time();
			 
			 // Now lets check
			 if($today > $expired_date){
				 // Setting extending time
			 	$extend_time=48*60*60;
				$extended=$expired_date + $extend_time;
				// LETS SET POST TO EXPIRED
				$my_post = array(
				'ID' => $promotion_id,
				'post_status' => 'expired',
				);
				
				$post_id = wp_update_post($my_post);
				if(is_wp_error($post_id)){
					wp_die();
				}
				else{
				// Now lets log to the promotion field
				update_post_meta($promotion_id, YO_METABOX_PREFIX. 'promotion_extend', $extended);
				}
			 }
		 }
		 
		 /**
         * promotion deletion
         */
		 public function delete_promotion($promotion_id){
			// LETS PROCESS THE PROMOTION DELETION
			global $post_type;   
    		if($post_type !== 'falzo_promotion'){
				 return;
			}

    		global $wpdb;

    		$args = array(
        	'post_type'         => 'attachment',
        	'post_status'       => 'any',
        	'posts_per_page'    => -1,
        	'post_parent'       => $promotion_id
    		);
    		$attachments = new WP_Query($args);
    		$attachment_ids = array();
    		if($attachments->have_posts()){ 
				while($attachments->have_posts()){
			 		$attachments->the_post();
            		$attachment_ids[] = get_the_id();
				}
		 	}
			
    	  	wp_reset_postdata();

    		if(!empty($attachment_ids)) {
        	$delete_attachments_query = $wpdb->prepare('DELETE FROM %1$s WHERE %1$s.ID IN (%2$s)', $wpdb->posts, join(',', $attachment_ids));
        	$returnValue=$wpdb->query($delete_attachments_query);
			
			return $returnValue;
			}
		
			// End of method
		 }
		 
		 /**
         * promotion monitor
		 * This method will handle the expiration of promotion, delete promotion, and extend promotion when needed
         */
		 public function promotion_monitor(){
			// NOW LETS START PROCESSING THE PROMOTION MONITOR METHOD
			// Checking user login and role
			 if ( is_user_logged_in()) {
				// LETS PROMOTE AGENT ITEM
				global $current_user;
             	wp_get_current_user();
				$user_id = $current_user->ID;
				$today = time();
				$delete=0;
				
				// Now lets check the user promotion id
				$promotion_ids=get_user_meta($user_id, YO_METABOX_PREFIX . 'promotion_ids', true);
				// Now lets check
				if(!empty($promotion_ids)){
					foreach($promotion_ids as $promotion_id){
						$promotion_extend=get_post_meta($promotion_id, YO_METABOX_PREFIX. 'promotion_extend', true);
						if($promotion_id > 0){
							// Lets get the promotion extend field
							if(empty($promotion_extend)){
								// Promotion extend is no setted
								// Now lets check expire
								$expired_time=$this->promotion_expires_time($promotion_id);
								if($today > $expired_time){
									// Here packages has expired, lets extend
									$this->promotion_extend($promotion_id);
							
									// Lets return
									return $delete;
								}
							}
							else{
								// Promotion extend is setted
								$new_expired_time=intval($promotion_extend);
								if($today > $new_expired_time){
									// We call the promotion delete to delete data
									$delete=$this->delete_promotion($promotion_id);
							
									// Lets return
									return $delete;	
								}
							}
						} // end of promotion id check
			 		} // end of loop
				}
			 }
			 
			 // End of method
		 }
		 
		 /**
         * promotion expires date
         */
		 public function add_promotion(){
			// LETS START CONSTRUCTING THE ADD PROMOTION SESSION CREATOR
			$true_value = 0;
			if(isset($_POST["property_id"])){
				$property_id = $_POST["property_id"];
				// Here we set cookie if it does not exist
				// or we edit cookie if it does exist
				if(!isset($_COOKIE['yobek_promote_log'])) {
					// Cookie does not exist
    				setcookie('yobek_promote_log', $property_id, time()+3600, '/', '.yobek.com');
					$true_value++;
				}
				else{
					// Cookie does exist
					// We are now updating the cookie
					$property_ids = $_COOKIE['yobek_promote_log'].','.$property_id;
					setcookie('yobek_promote_log', $property_ids, time()+3600, '/', '.yobek.com');
					$true_value++;
				}
			}
			print $true_value;
			wp_die();
			// End of method 
		 }
		 
	// END OF CLASS
	}
}
?>