<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('YO_Ranking')) {
    /**
     * The public-facing functionality of the plugin
     * Class ERE_Public
     */
    class YO_Ranking
	{
		/**
         * referral_ajax
         */
		 public function set_rank(){
			 // HERE WE SET THE USER RANK SUM UP
			 if ( is_user_logged_in()) {
			 	global $current_user;
             	wp_get_current_user();
			 	$user_id = $current_user->ID;
			 	// LETS GET ALL RATE PARTS
			 	$viewed_properties=$this->get_views();
			 	$referral_rate=intval(get_user_meta( $user_id, YO_METABOX_PREFIX. 'referral_rate', true ));
				$patch_rank = intval(get_user_meta( $user_id, YO_METABOX_PREFIX. 'patch_rank', true ));
			 	// $rank = intval(get_user_meta( $user_id, YO_METABOX_PREFIX. 'user_rank', true ));
			 	$user_rank=0;
			 	// Lets check rank
			 	if(empty($patch_rank)){
				 	$patch_rank=0;
			 	}
			 
			 	// Now lets work ranking calculation
			 	$add_rate = $viewed_properties + $referral_rate;
			 	$divide_rate = $add_rate / 2;
			 	// Now lets set rank and add up
			 	$user_rank = $divide_rate + $patch_rank;
			 	// NOW LETS STORE THE NEW RANK
			 	update_user_meta( $user_id, YO_METABOX_PREFIX. 'user_rank', $user_rank );
			 }
		 }
		 
		 /**
         * referral_ajax
         */
		 public function get_rank($user_id){
			 // HERE WE CONSTRUCT USER RANK RETRIEVAL
			 // LETS GET THE RANK META
			 $rank = get_user_meta( $user_id, YO_METABOX_PREFIX. 'user_rank', true );
			 if( empty($rank)){
				 $rank=0;
			 }
			 
			 // Lets return rank
			 return $rank;
		 }
		 
		 /**
         * referral_ajax
         */
		 public function get_views(){
			 // NOW LETS GET PROPERTY VIEWS AS WE USE IN RANKING
			 $total_view_count=0;
			 // Setting the argument
			 $args = array(
			 'post_type' => 'property',
			 'post_status' => 'publish',
			 );
			 // Lets get the post
			 $posts = get_posts( $args );
			 // Now we loop to get each post view count and add up
			 foreach($posts as $post){
				 // NOW LETS GET THE POSTS ID AND GET THE VIEWS
				 $views = get_post_meta($post->ID, 'real_estate_property_views_count', true);
				 $total_view_count=$total_view_count + intval($views);
			 } // End of loop
			 
			 // NOW LETS RETURN OUR TOTAL PROPERTY VIEWS
			 return $total_view_count;
			 // End of method
		 }
		 
		 /**
         * referral_ajax
         */
		 public function top_ranked(){
			 // HERE WE UPDATE THE OPTION FOR THE TOP RANKED USERS
			 $blogusers = get_users();
			 // Array of WP_User objects.
			 foreach($blogusers as $user){
				 $rank = get_user_meta( $user->ID, YO_METABOX_PREFIX. 'user_rank', true );
				 if($rank >= 100 && $rank< 6000){
					// Now lets reset the option
					$config = get_option(YO_OPTIONS_NAME);
                	$config["has_top_ranked"] = 1;
                	update_option(YO_OPTIONS_NAME, $config); 
					break;
				 }
				 elseif($rank >= 6000){ 
					// Now lets reset the option
					$config = get_option(YO_OPTIONS_NAME);
                	$config["has_super_ranked"] = 1;
                	update_option(YO_OPTIONS_NAME, $config); 
					break; 
				 }
			 } // end of loop
			// End of method
		 }
		 
		 
	}
}
?>