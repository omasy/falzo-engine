<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('YO_Referral')) {
    /**
     * The public-facing functionality of the plugin
     * Class ERE_Public
     */
    class YO_Referral
	{
		/**
         * referral_ajax
         */
		 public function referral($new_referral=array()){
			// LETS START PROCESSING USER REFERRAL CREATION
			if ( is_user_logged_in()) {
				// LETS PROMOTE AGENT ITEM
				global $current_user;
             	wp_get_current_user();
				$user_id = $current_user->ID;
				// Lets set referral options
				get_currentuserinfo();
				$referral_key=uniqid();
				$referral_name=$current_user->user_login;
				$referral_email=$current_user->user_email;
				
				// NOW LETS POST ADVERT INTO THE WORDPRESS DATABASE AND META
				$new_referral['post_type'] = 'falzo_referral';
				$new_referral['post_author'] = $user_id;
				$new_referral['post_title']=ucfirst($referral_name)." Referral Program";
				$new_referral['post_content']=ucfirst($referral_name)." Referral Program and Email:".$referral_email;
				$new_referral['post_status'] = 'publish';
			
				// Now lets insert post to the database
				$referral_id = wp_insert_post( $new_referral, true );
				if ( $referral_id > 0 ) {
					// Lets set post metas for referral
					// Activation date format
					$time = time();
            		$date = date('Y-m-d H:i:s', $time);
					// Now lets create meta data and attach it to post
					update_post_meta( $referral_id, YO_METABOX_PREFIX. 'referral_key', $referral_key );
					update_post_meta( $referral_id, YO_METABOX_PREFIX. 'referral_email', $referral_email );
					update_post_meta( $referral_id, YO_METABOX_PREFIX. 'referral_activate_date', $date );
					update_post_meta( $referral_id, YO_METABOX_PREFIX. 'user_id', $user_id );
					update_user_meta( $user_id, YO_METABOX_PREFIX. 'referral_rate', 0 );
					update_user_meta( $user_id, YO_METABOX_PREFIX. 'referral_awarded', 'no' );
					update_user_meta($user_id, YO_METABOX_PREFIX . 'referral_id', $referral_id);
					// do_action( 'wp_insert_post', 'wp_insert_post' );	
					// LETS RETURN THE PAYMENT PAGE
					$return_page=yo_get_permalink("my_referral");
					$return_link = add_query_arg(array('referral_id' => $referral_id), $return_page);
					// We return link
					return $return_link;
				}
			}
			
			// End of method 
		 }
		 
		 /**
         * user_referral_ajax
         */
		 public function user_referral($user_id, $referral_key){
			// HERE WE LOG THE USER REFERRALS TO KEEP TRACK OF AGENTS UNDER THE USER
			if($this->check_user($user_id) == true){
			$user_info=get_userdata($user_id);
			// Now lets set the meta datas for the user
			// update_post_meta( $referral_key, $user_info->user_login. '_email', $user_info->user_email );
			update_post_meta( $referral_key, $user_info->user_login. '_user_id', $user_id );
			update_user_meta($user_id, YO_METABOX_PREFIX . 'referred', $referral_key);
			
			// Now we have setted the user referral metas, let get the referral and rate
			// $referral_data=$this->get_referral($referral_key);
			// $referral_id=$referral_data[0]["referral_id"];
			// Now lets rate user
			$this->rate_referral($user_id);
			}
			else{
				// Lets kill execution
				wp_die(); 
			}
			// End of method 
		 }
		 
		 /**
         * referral_ajax
         */
		 private function check_user($user_id){
			global $wpdb;
			$count=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $wpdb->users WHERE ID = %d", $user_id));
			// Lets check
			if($count==1){
				return true;
			}
			else{
				return false;
			}
			// End of method
		 }
		 
		 /**
         * referral_ajax
         */
		 public function get_referral($referralkey=""){
			// HERE WE GET ALL REFERRAL AND RETURN ONLY THE REFERRAL ID AND REFERRAL KEY
			// TO USE IN COMAPRING TO FIND EXACT REFERRAL
			$users = get_users( array( 'fields' => array( 'ID' ) ) );
			$referral_info=array();
			// We check user data returned
			if(empty($users)){
				return;
			}
			
			// Now lets loop user datas
			foreach($users as $key=>$user_id){
				// Now lets get the referral id
				$referral_id=get_user_meta($user_id->ID, YO_METABOX_PREFIX . 'referral_id', true);
				$referral_key=get_post_meta($referral_id, YO_METABOX_PREFIX. 'referral_key', true);
				// Lets create two dimensional array
				if(!empty($referralkey)){
					if($referralkey==$referral_key){
						$referral_info[]=array('referral_id'=>$referral_id, 'referral_key'=>$referral_key);
						break;	
					}
				}
				else{
					$referral_info[$key]=array('referral_id'=>$referral_id, 'referral_key'=>$referral_key);
				}
    		} // End of loop
			
			// Now lets return referral datas
			return $referral_info;
			
			// End of method 
		 }
		 
		 /**
         * referral_ajax
         */
		 public function generate_link($referral_id){
			// NOW LETS GENERATE THE REFERRAL LINK
			if(metadata_exists('post', $referral_id, YO_METABOX_PREFIX. 'referral_key')){
				$link = "";
				$return_link = "";
				// Lets get the referral key
				$referral_key=get_post_meta($referral_id, YO_METABOX_PREFIX. 'referral_key', true);
				// Lets get the signup permalink
				if(function_exists(ere_get_permalink)){
					$link=ere_get_permalink("register");
					$return_link=add_query_arg(array('referral_key' => $referral_key), $link);
				}
				else{
					$link="https://www.yobek.com/my_referral/";
					$return_link=add_query_arg(array('referral_key' => $referral_key), $link);
				}
				// Lets return link
				return $return_link;
			}
			else{
				return -1;
			}
			// End of method 
		 }
		 
		 /**
         * referral_ajax
         */
		 public function rate_referral($user_id){
			// LETS CONSTRUCT THE REFERRAL RATING TO START WITH
			// Lets first get rating option
			//GRAB ALL OPTIONS
			$options = yo_get_option("referral");
			$orate=intval($options["rate"]);
			
			// Now lets get rate stored
			$rate=intval(get_user_meta( $user_id, YO_METABOX_PREFIX. 'referral_rate', true ));
			$rate_increment=$rate+$orate;
			// Lets update referral rating
			update_user_meta( $user_id, YO_METABOX_PREFIX. 'referral_rate', $rate_increment );
			// End of method 
		 }
		 
		 /**
         * promotion extend
         */
		 public function get_total_referral($post_status){
			// HERE WE CONSTRUCT THE PROMOTION FETCHER
			$args       = array(
				'post_type'   => 'falzo_referral',
				'post_status' => $post_status,
				'author'      => get_current_user_id(),
			);
			$promotions = new WP_Query( $args );
			wp_reset_postdata();
			return $promotions->found_posts;
			
			// End of method
		 }
		 
		 /**
         * referral_ajax
         */
		 public function award_referral(){
			// NOW LETS PROCESS THE REFERRAL AWARD
			// Lets get user data
			global $current_user;
            wp_get_current_user();
			$user_id = $current_user->ID;
			// Lets first get rating option
			//GRAB ALL OPTIONS
			$options = yo_get_option("referral");
			$discount=$options["discount"];
			$approval=intval($options["approval"]);
			// Lets get the user referral
			$referral_id=get_user_meta($user_id, YO_METABOX_PREFIX . 'referral_id', true);
			$referral_key=get_post_meta( $referral_id, YO_METABOX_PREFIX. 'referral_key', true );
			$awarded=get_user_meta( $user_id, YO_METABOX_PREFIX. 'referral_awarded', true );
			$extended_time=720*60*60;
			
			// LETS CHECK THE REWARD FIELD
			if($awarded=="no"){
				// Now lets get list of all the users under an agent
				$my_referrals=get_post_meta( $referral_key );
				if(is_array($my_referrals)){
					// Now lets get count
					$count_referral=count($my_referrals);
					// NOW LETS CHECK IF THE COUNT IS UP TO OPTION
					if($discount=="yes"){
						// We make sure the approval is approved
						if($count_referral>=$approval){
							// If the count referral downline is above or equal to approval
							// Here we increase user package
							$package_activate_time = strtotime(get_user_meta($user_id, 'real_estate_package_activate_date', true));
            				$package_id=get_user_meta($user_id, 'real_estate_package_id', true);
							// Lets check the meta data
							if(!empty($package_activate_date) && !empty($package_id)){
								$new_time=$package_activate_date + $extended_time;
								$new_date = date('Y-m-d H:i:s', $new_time);
								// NOW LETS SET NEW DATE
								update_user_meta($user_id, 'real_estate_package_activate_date', $new_date);
								update_user_meta( $user_id, YO_METABOX_PREFIX. 'referral_awarded', "yes" );
							}
						}
					} // check
				}
			} // end of rewarded check
			
			// NOW LETS RETURN OUTPUT OR NOTHING
			if(!empty($package_id)){
				return $package_id;
			}
			else{
				return;
			}
			// End of method 
		 }
		 
		 /**
         * referral_ajax
         */
		 public function referral_request(){
			// CONSTRUCTING THE WIZARD METHOD TO CONTROL PROCESS
			// Lets get user data
			global $current_user;
            wp_get_current_user();
			$user_id = $current_user->ID;
			$output="";
			$ajax_response = array();
			// Lets get and use the action param	
			$action=$_POST["request"];
			if($action=="create_referral"){
				$ajax_response['url'] = $this->referral();
				$ajax_response['success'] = true;
				$ajax_response['type'] = 'ca';
				
			}
			elseif($action=="get_link"){
				// Lets check if the user meta exists
				// We get the referral id and return link
				$referral_id=get_user_meta($user_id->ID, YO_METABOX_PREFIX . 'referral_id', true);
				if(!empty($referral_id)){
					// Now lets get link
					$ajax_response['url'] = $this->generate_link($referral_id);
					$ajax_response['success'] = true;
					$ajax_response['type'] = 'dm';
				}
				else{
					// We create new referral for user and return link
					$referral=$this->referral();
					// Now lets get link if referral is created
					if(!empty($referral)){
						// We get the referral id and return link
						$referral_id=get_user_meta($user_id->ID, YO_METABOX_PREFIX . 'referral_id', true);
						if(!empty($referral_id)){
							$ajax_response['url'] = $this->generate_link($referral_id);
							$ajax_response['success'] = true;
							$ajax_response['type'] = 'dm';
						}
					}
				}
			}
			// Lets echo the json data
			echo json_encode($ajax_response);
            wp_die();
			// End of method 
		 }
		 
		 // END OF CLASS
	}
}
?>