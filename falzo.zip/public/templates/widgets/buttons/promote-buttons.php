<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
// We make sure user is logged in
// Checking user login and role
if ( is_user_logged_in()):
	global $current_user, $post;
	wp_get_current_user();
	$user_id = $current_user->ID;
	$author_id = $post->post_author;
	// NOW LETS CHECK
	if($user_id === $author_id):
		$promote_link = yo_get_permalink('promote');
?>
<div class="panel-body">
    <p class="ere-message alert alert-success"
       role="alert"><?php esc_html_e('Get more people to see your items, get a promotion package and sell more. Click the button below to start', 'essential-real-estate'); ?></p>
    <a id="yo_add_promo_move" href="#" data-property_id="<?php echo $post->ID; ?>" data-promote_package="<?php echo esc_url($promote_link); ?>"
       class="btn btn-primary btn-block"><?php esc_html_e('PROMOTE PROPERTY', 'essential-real-estate'); ?></a>
</div>
<?php
endif;
endif;
 ?>