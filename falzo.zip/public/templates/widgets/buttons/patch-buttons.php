<?php
if ( ! defined( 'ABSPATH' ) ) {
	echo "ABSPATH not defined!";
    exit; // Exit if accessed directly
}
// We make sure user is logged in
// Checking user login and role
if ( is_user_logged_in()):
	$patch_link = yo_get_permalink('patch');
?>
<div class="panel-body">
    <p class="ere-message alert alert-success"
       role="alert"><?php esc_html_e('To get more traffic and sales you have to patch with an agency. Currently, you have/don\'t have a patch record. So, to add a new patch, please click the button below', 'essential-real-estate'); ?></p>
    <a href="<?php echo esc_url($patch_link); ?>"
       class="btn btn-primary btn-block"><?php esc_html_e('PATCH WITH AGENCY', 'essential-real-estate'); ?></a>
</div>
<?php
endif;
 ?>