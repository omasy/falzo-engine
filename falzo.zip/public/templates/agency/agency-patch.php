<?php
/**
 * @var $my_properties_columns
 * @var $properties
 * @var $max_num_pages
 * @var $post_status
 * @var $title
 * @var $property_identity
 * @var $property_status
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
if(!is_user_logged_in()){
    echo ere_get_template_html('global/access-denied.php',array('type'=>'not_login'));
    return;
}
$allow_submit=ere_allow_submit();
if (!$allow_submit)
{
    echo ere_get_template_html('global/access-denied.php',array('type'=>'not_permission'));
    return;
}

$width = get_option('thumbnail_size_w'); $height = get_option('thumbnail_size_h');
$no_image_src= ERE_PLUGIN_URL . 'public/assets/images/no-image.jpg';
$default_image=ere_get_option('default_property_image','');
if($default_image!='')
{
    if(is_array($default_image)&& $default_image['url']!='')
    {
        $resize = ere_image_resize_url($default_image['url'], $width, $height, true);
        if ($resize != null && is_array($resize)) {
            $no_image_src = $resize['url'];
        }
    }
}
$paid_submission_type = ere_get_option('paid_submission_type', 'no');
$ere_profile=new ERE_Profile();
global $current_user;
wp_get_current_user();
$user_id = $current_user->ID;
//GRAB ALL OPTIONS
$my_agency_columns = yo_get_option("my_agency_columns");
// NOW LETS GET THE PROPERTY DATAS FORM THE PROPERTY
$terms = get_terms( 'agency' );
if(empty( $terms ) && is_wp_error( $terms )){
	// WE RETURN ACCESS DENIED
	echo ere_get_template_html('global/access-denied.php',array('type'=>'not_permission'));
    return;	
}
?>
    
    <?php $max_num_pages = count($terms); ?>
    <!-- SEARCH FORM BEGAN HERE //-->
    
    <!-- SEARCH FORM ENDED HERE //-->
    <!-- CONTENT TITLE STARTS //-->
    <div class="ere-heading text-center mg-bottom-60 sm-mg-bottom-40">
       <span></span>
       <p><?php esc_html_e( 'OUR PROFESSIONAL AGENCIES', 'essential-real-estate'); ?></p>
       <h2><?php esc_html_e( 'CHOOSE AGENCY TO PATCH WITH', 'essential-real-estate'); ?></h2>
    </div>
    <!-- CONTENT TITLE ENDS // -->
    <div class="table-responsive">
        <table class="ere-my-properties table">
            <thead>
            <tr>
                <?php foreach ($my_agency_columns as $key => $column) : ?>
                    <th class="<?php echo esc_attr($key); ?>"><?php echo esc_html($column); ?></th>
                <?php endforeach; ?>
            </tr>
            </thead>
            <tbody>
            <?php if (!$terms) : ?>
                <tr>
                    <td colspan="6"><?php esc_html_e('You don\'t have any agency listed.', 'essential-real-estate'); ?></td>
                </tr>
            <?php else : ?>
                <?php foreach ($terms as $term) : ?>
                	<?php 
					$agency_website_url = get_term_meta( $term->term_id, 'agency_website_url', true );
					// Query Property of Agency
					$args = array(
   					 'post_type'      => 'agent',
    				 'post_status'    => 'publish',
    				 'tax_query' => array(
        				array(
            				'taxonomy' => 'agency',
            				'field'    => 'slug',
            				'terms'    => array($term->slug),
            				'operator' => 'IN'
        					)
    					)
					);
					$agent_data = new WP_Query($args);
					$total_data = $agent_data->found_posts;
					?>
                    <tr>
                        <?php foreach ($my_agency_columns as $key => $column) :?>
                            <td class="<?php echo esc_attr($key); ?>">
                                <?php if ('picture' === $key) :
                                    $logo_src = get_term_meta($term->term_id, 'agency_logo', true);
									if ($logo_src && !empty($logo_src['url'])){
   											$logo_src = $logo_src['url'];
									}
									if (!empty($logo_src)){
    								list($width, $height) = getimagesize($logo_src);
									}
									// Now lets display agency logo
                                    if (!empty($width) && !empty($height)) : ?>
                                         <img width="<?php echo esc_attr($width) ?>"
                                         height="<?php echo esc_attr($height) ?>"
                                         src="<?php echo esc_url($logo_src) ?>" onerror="this.src = '<?php echo esc_url($no_image_src) ?>';" alt="<?php echo $term->name; ?>"
                                         title="<?php echo $term->name; ?>">
                                    <?php else :?>
                                        <img width="<?php echo esc_attr($width) ?>"
                                             height="<?php echo esc_attr($height) ?>"
                                             src="<?php echo esc_url($image_src) ?>" onerror="this.src = '<?php echo esc_url($no_image_src) ?>';" alt="<?php echo $term->name; ?>"
                                             title="<?php echo $property->post_title; ?>">
                                    <?php endif;
                                elseif ('title' === $key) : ?>
                                    <?php if (!empty($term->name)) : ?>
                                        <h4>
                                            <a target="_blank" title="<?php echo $term->name; ?>" href="<?php echo $agency_website_url; ?>"><?php echo $term->name; ?></a>
                                        </h4>
                                    <?php else : ?>
                                        <h4><?php echo $term->slug; ?></h4>
                                    <?php endif; ?>
                                    <span class="btn-block fw-bold"><?php echo ere_get_option( 'empty_price_text', '' ) ?></span>
                                    <span class="btn-block"><i class="fa fa-map-marker accent-color"></i>
                                        <?php echo get_term_meta( $term->term_id, 'agency_address', true ); ?>
                                    </span>
                                    <span class="btn-block mg-bottom-10"><i class="fa fa-eye accent-color"></i>
                                    <?php printf(esc_html__('%s Agents','essential-real-estate'),$total_data); ?>
                                    </span>
                                    
                                <?php elseif ('id' === $key):
                                    echo $term->term_id;
                                ?>
                                <?php elseif ('phone' === $key) :
                                    echo get_term_meta( $term->term_id, 'agency_mobile_number', true );
									
                                elseif ('action' === $key): ?>
                                        <span data-toggle="tooltip"
                                              data-placement="bottom"
                                              title="<?php esc_html_e('Patch Process..', 'essential-real-estate') ?>"
                                              class="fa fa-star accent-color"></span>
                         <?php elseif ('patch' === $key): ?>
                                   <button id="yo_patch" class="btn btn-default yo_patch" data-agency_id="<?php echo $term->term_id; ?>" onclick="return false"><?php echo esc_html_e('Patch', 'essential-real-estate'); ?></button>'
                                <?php endif; ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<br>
<?php ere_get_template('global/pagination.php', array('max_num_pages' => $max_num_pages)); ?>