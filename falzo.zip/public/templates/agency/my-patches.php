<?php
/**
 * @var $my_properties_columns
 * @var $properties
 * @var $max_num_pages
 * @var $post_status
 * @var $title
 * @var $property_identity
 * @var $property_status
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
if(!is_user_logged_in()){
    echo ere_get_template_html('global/access-denied.php',array('type'=>'not_login'));
    return;
}
$allow_submit=yo_allow_submit();
if (!$allow_submit)
{
    echo ere_get_template_html('global/access-denied.php',array('type'=>'not_permission'));
    return;
}
// Lets get the menu template
ere_get_template('global/dashboard-menu.php', array('cur_menu' => 'my_patches'));

// NOW LETS GET PROMOTION DATAS
$my_patch_page_link = yo_get_permalink('my_patches');
$yo_agency=new YO_Agency();
$total_patch = $yo_agency->get_total_patch(array('publish', 'pending', 'expired', 'hidden'));
$post_status_approved = add_query_arg(array('post_status' => 'publish'),$my_patch_page_link);
$total_approved = $yo_agency->get_total_patch('publish');
$post_status_pending = add_query_arg(array('post_status' => 'pending'),$my_patch_page_link);
$total_pending = $yo_agency->get_total_patch('pending');
$post_status_expired = add_query_arg(array('post_status' => 'expired'),$my_patch_page_link);
$total_expired = $yo_agency->get_total_patch('expired');

$post_status_hidden = add_query_arg(array('post_status' => 'hidden'),$my_patch_page_link);
$total_hidden = $yo_agency->get_total_patch('hidden');

global $current_user;
wp_get_current_user();
$user_id = $current_user->ID;
//GRAB ALL OPTIONS
$my_patches_columns = yo_get_option("my_patches_columns");
$item_amount = 10;

// NOW LETS GET THE PROMOTION DATAS
$posts_status = array('publish', 'pending', 'hidden');
$status_send = isset($_GET['post_status']) ? $_GET['post_status'] : $posts_status;
$args = array(
		'post_type'   => 'falzo_patch',
		'posts_per_page' => ($item_amount > 0) ? $item_amount : -1,
		'post_status' => $status_send,
		'author'      => $user_id,
		);
$patches = new WP_Query( $args );
wp_reset_postdata();
// Lets check if id is setted $property_meta_data = get_post_custom($property_data->ID);
if(!$patches->found_posts){
	// WE RETURN ACCESS DENIED
	echo ere_get_template_html('global/access-denied.php',array('type'=>'not_permission'));
    return;
}

?>
	<?php $max_num_pages = $patches->max_num_pages; ?>
    <ul class="ere-my-properties-filter">
        <li class="ere-status-all<?php if (is_array($post_status)) echo ' active' ?>"><a
                href="<?php echo esc_url($my_patch_page_link); ?>"><?php printf(__('All (%s)', 'essential-real-estate'),$total_patch);?></a>
        </li>
        <li class="ere-status-publish<?php if ($post_status == 'publish') echo ' active' ?>"><a
                href="<?php echo esc_url($post_status_approved); ?>">
                <?php printf(__('Approved (%s)', 'essential-real-estate'),$total_approved);?></a>
        </li>
        <li class="ere-status-pending<?php if ($post_status == 'pending') echo ' active' ?>"><a
                href="<?php echo esc_url($post_status_pending); ?>">
                <?php printf(__('Pending (%s)', 'essential-real-estate'),$total_pending);?></a>
        </li>
        <li class="ere-status-expired<?php if ($post_status == 'expired') echo ' active' ?>"><a
                href="<?php echo esc_url($post_status_expired); ?>">
                <?php printf(__('Expired (%s)', 'essential-real-estate'),$total_expired);?></a>
        </li>
        <li class="ere-status-hidden<?php if ($post_status == 'hidden') echo ' active' ?>"><a
                href="<?php echo esc_url($post_status_hidden); ?>">
                <?php printf(__('Hidden (%s)', 'essential-real-estate'),$total_hidden);?></a>
        </li>
    </ul>
    
    <!-- SEARCH FORM BEGAN HERE //-->
    
    <!-- SEARCH FORM ENDED HERE //-->
    
    <div class="table-responsive">
    <table class="ere-my-invoices table">
        <thead>
        <tr>
            <?php foreach ($my_patches_columns as $key => $column) : ?>
                <th class="<?php echo esc_attr($key); ?>"><?php echo esc_html($column); ?></th>
            <?php endforeach; ?>
        </tr>
        </thead>
        <tbody>
        <?php if (empty($patches)) : ?>
            <tr>
                <td colspan="7"><?php esc_html_e('You don\'t have any patch listed.', 'essential-real-estate'); ?></td>
            </tr>
        <?php else : ?>
            <?php $key=0; foreach ($patches as $patch) :
                $title = get_the_title($patch->ID);
				$agency_ids = get_user_meta( $patch->ID, YO_METABOX_PREFIX. 'agency_ids', true );
				$term = get_term( $agency_ids[$key++], 'agency' );
				$agency_name = $term->name;
				$patch_rank = get_post_meta( $patch->ID, YO_METABOX_PREFIX. 'award_rank', true );
				$patch_price = get_post_meta( $patch->ID, YO_METABOX_PREFIX. 'patch_price', true );
                ?>
                <tr>
                    <?php foreach ($my_patches_columns as $key => $column) : ?>
                        <td class="<?php echo esc_attr($key); ?>">
                            <?php if ('title' === $key): ?>
                                <a href="<?php echo get_permalink($patch->ID); ?>"><?php echo $title; ?></a>
                                <?php
                            elseif ('name' === $key) :
								echo esc_html($agency_name." - ID: ".$agency_id);
                            elseif ('id' == $key):
                                echo $patch->ID;
                            elseif ('rank' === $key):
                                echo $patch_rank.' Rank added';
                            elseif ('price' === $key):
                                echo ere_get_format_money($patch_price);
                            elseif ('status' === $key):
                                echo get_post_status ( $patch->ID ); ?>
                                
                            <?php endif; ?>
                        </td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<br>
<?php ere_get_template('global/pagination.php', array('max_num_pages' => $max_num_pages)); ?>