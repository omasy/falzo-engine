<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// HERE WE GET AGENCY TAXONOMY TERMS
// If agency is empty lets get all terms
$agency_terms = get_terms( 'agency', 'orderby=count&hide_empty=0' );
$output = array();
foreach($agency_terms as $terms){
	// Lets add
	$output[] = $terms->slug;
}
// NOW WE HAVE AGENCY ID LETS GET PROPERTY
// Query Property of Agency
$args2 = array(
    'post_type'      => 'agent',
    'post_status'    => 'publish',
    'tax_query' => array(
        array(
            'taxonomy' => 'agency',
            'field'    => 'slug',
            'terms'    => $output,
            'operator' => 'IN'
        )
    )
);
$agent_data = new WP_Query($args2);
$agent_id_arr = $author_id_arr = '';
if($agent_data->have_posts()):
    while ($agent_data->have_posts()){
        $agent_data->the_post();
        $agent_id_arr .= get_the_ID() . ',';
        $author_id_arr .= get_post_meta( get_the_ID(), ERE_METABOX_PREFIX . 'agent_user_id', true ) . ',';
    }
    $agent_id_arr = substr( $agent_id_arr, 0, strlen( $agent_id_arr ) - 1 );
    $author_id_arr = substr( $author_id_arr, 0, strlen( $author_id_arr ) - 1 );
	
	// LETS SET THE PARAMETER DATAS for-sale
	$include_heading = 1;
	$heading_sub_title = 'BROWSE OUR DREAM HOME';
	$heading_title = 'PROPERTY FOR SALE';
	$property_status = 'for-sale';
	$property_layout = 'property-carousel';
	$item_amount=12;
	$columns=6;
	$columns_gap='col-gap-0';
	$view_all_link='http://yobek.com/property-status/for-sale/';
	$move_nav="true";
	
	// HERE WE DISPLAY THE AGENCY SHORT CODE
	$property_agency_shortcode = '[ere_property property_status = "' . $property_status . '"
                                include_heading = "' . $include_heading . '" heading_sub_title="' . $heading_sub_title . '" 
								heading_title="' . $heading_title . '" author_id = "' . $author_id_arr . '" agent_id = "' . $agent_id_arr . '" 
								layout_style="'.$property_layout.'" item_amount="'.$item_amount.'" columns="'.$columns.'" columns_gap="'.$columns_gap.'" 
								view_all_link="'.$view_all_link.'" move_nav="'.$move_nav.'"]';
      echo do_shortcode($property_agency_shortcode);

?>
<?php endif; // End of agent data check ?>