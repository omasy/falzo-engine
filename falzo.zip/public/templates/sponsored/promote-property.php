<?php
/**
 * @var $my_properties_columns
 * @var $properties
 * @var $max_num_pages
 * @var $post_status
 * @var $title
 * @var $property_identity
 * @var $property_status
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
if(!is_user_logged_in()){
    echo ere_get_template_html('global/access-denied.php',array('type'=>'not_login'));
    return;
}
$allow_submit=ere_allow_submit();
if (!$allow_submit)
{
    echo ere_get_template_html('global/access-denied.php',array('type'=>'not_permission'));
    return;
}

$my_promotion_page_link = yo_get_permalink('promote');
$my_promotion_package_link = yo_get_permalink('promotion_packages');
// $ere_property=new ERE_Property();
// $total_properties = $ere_property->get_total_my_properties(array('publish', 'pending', 'expired', 'hidden'));

$width = get_option('thumbnail_size_w'); $height = get_option('thumbnail_size_h');
$no_image_src= ERE_PLUGIN_URL . 'public/assets/images/no-image.jpg';
$default_image=ere_get_option('default_property_image','');
if($default_image!='')
{
    if(is_array($default_image)&& $default_image['url']!='')
    {
        $resize = ere_image_resize_url($default_image['url'], $width, $height, true);
        if ($resize != null && is_array($resize)) {
            $no_image_src = $resize['url'];
        }
    }
}
$paid_submission_type = ere_get_option('paid_submission_type', 'no');
$ere_profile=new ERE_Profile();
$ere_property=new ERE_Property();
global $current_user;
wp_get_current_user();
$user_id = $current_user->ID;
$agent_id = get_the_author_meta(ERE_METABOX_PREFIX . 'author_agent_id', $user_id);
$item_amount = 10;
//GRAB ALL OPTIONS
$my_properties_columns = yo_get_option("my_properties_columns");
// NOW LETS GET THE PROPERTY DATAS FORM THE PROPERTY
$args = array(
    'post_type' => 'property',
	'posts_per_page' => ($item_amount > 0) ? $item_amount : -1,
	'author'      => $user_id,
    'orderby' => 'date',
    'order' => 'DESC',
    'post_status' => 'publish',
);

if (!empty($agent_id)) {
    $args['meta_query'] = array(
        'relation' => 'OR',
        array(
            'key' => ERE_METABOX_PREFIX . 'property_agent',
            'value' => $agent_id,
            'compare' => 'IN'
        )
    );
}

// HERE WE ARE SELCTING PROPERTY BY AGENT AND AUTHOR OF THE PROPERTIES
$properties = new WP_Query($args);
$total_post = $properties->found_posts;
if($total_post <1 ){
	// WE RETURN ACCESS DENIED
	echo ere_get_template_html('global/access-denied.php',array('type'=>'not_permission'));
    return;	
}
?>
    
    <?php $max_num_pages = $properties->max_num_pages; ?>
    <!-- SEARCH FORM BEGAN HERE //-->
    
    <!-- SEARCH FORM ENDED HERE //-->
    <!-- CONTENT TITLE STARTS //-->
    <div class="ere-heading text-center mg-bottom-60 sm-mg-bottom-40">
       <span></span>
       <p><?php esc_html_e( 'YOUR PRODUCT LIST', 'essential-real-estate'); ?></p>
       <h2><?php esc_html_e( 'CHOOSE PRODUCT(S) TO PROMOTE', 'essential-real-estate'); ?></h2>
    </div>
    <!-- CONTENT TITLE ENDS // -->
    <div class="row">
    <div class="col-sm-6">
        <h4 class="ere-dashboard-title"><?php echo __('Add Properties before proceeding', 'essential-real-estate');?></h4>
    </div>
    <div class="col-sm-6 text-right">
            <a class="btn btn-default"
               href="<?php echo $my_promotion_package_link; ?>"><?php 
			   if(isset($_COOKIE['yobek_promote_log'])){
					if(strpos($_COOKIE['yobek_promote_log'], ",")){
							$splitter = explode(",", $_COOKIE['yobek_promote_log']);
							esc_html_e('Promote', 'essential-real-estate')."(".count($splitter).")";
					}
					else{
						echo esc_html_e('Promote', 'essential-real-estate')."(1)";
					}
				}
				else{
			    	esc_html_e('Promote', 'essential-real-estate');
				} ?></a>
    </div>
	</div>
    
    <div class="table-responsive">
        <table class="ere-my-properties table">
            <thead>
            <tr>
                <?php foreach ($my_properties_columns as $key => $column) : ?>
                    <th class="<?php echo esc_attr($key); ?>"><?php echo esc_html($column); ?></th>
                <?php endforeach; ?>
            </tr>
            </thead>
            <tbody>
            <?php if (!$properties) : ?>
                <tr>
                    <td colspan="6"><?php esc_html_e('You don\'t have any properties listed.', 'essential-real-estate'); ?></td>
                </tr>
            <?php else : ?>
                <?php foreach ($properties as $property) : ?>
                    <tr>
                        <?php foreach ($my_properties_columns as $key => $column) :?>
                            <td class="<?php echo esc_attr($key); ?>">
                                <?php if ('picture' === $key) :
                                    $property_item_status = get_the_terms( $property->ID, 'property-status' );
                                    if( $property_item_status ): ?>
                                    <div class="property-status">
                                        <?php foreach ( $property_item_status as $status ): ?>
                                            <?php $status_color = get_term_meta( $status->term_id, 'property_status_color', true ); ?>
                                            <p class="status-item">
                                                <span class="property-status-bg"
                                                      style="background-color: <?php echo esc_attr( $status_color ) ?>"><?php echo esc_attr( $status->name ) ?>
                                                </span>
                                            </p>
                                        <?php endforeach; ?>
                                    </div>
                                    <?php endif;
                                    $attach_id = get_post_thumbnail_id($property);
                                    $image_src = ere_image_resize_id($attach_id, $width, $height, true);
                                    if ($property->post_status == 'publish') : ?>
                                        <a target="_blank" title="<?php echo $property->post_title; ?>" href="<?php echo get_permalink($property->ID); ?>">
                                            <img width="<?php echo esc_attr($width) ?>"
                                                 height="<?php echo esc_attr($height) ?>"
                                                 src="<?php echo esc_url($image_src) ?>" onerror="this.src = '<?php echo esc_url($no_image_src) ?>';" alt="<?php echo $property->post_title; ?>"
                                                 title="<?php echo $property->post_title; ?>">
                                        </a>
                                    <?php else :?>
                                        <img width="<?php echo esc_attr($width) ?>"
                                             height="<?php echo esc_attr($height) ?>"
                                             src="<?php echo esc_url($image_src) ?>" onerror="this.src = '<?php echo esc_url($no_image_src) ?>';" alt="<?php echo $property->post_title; ?>"
                                             title="<?php echo $property->post_title; ?>">
                                    <?php endif;
                                elseif ('title' === $key) : ?>
                                    <?php if ($property->post_status == 'publish') : ?>
                                        <h4>
                                            <a target="_blank" title="<?php echo $property->post_title; ?>" href="<?php echo get_permalink($property->ID); ?>"><?php echo $property->post_title; ?></a>
                                        </h4>
                                    <?php else : ?>
                                        <h4><?php echo $property->post_title; ?></h4>
                                    <?php endif; ?>
                                    <?php
                                    $price = get_post_meta($property->ID, ERE_METABOX_PREFIX . 'property_price', true);
                                    $price_short = get_post_meta($property->ID, ERE_METABOX_PREFIX . 'property_price_short', true);
                                    $price_unit = get_post_meta($property->ID, ERE_METABOX_PREFIX . 'property_price_unit', true);

                                    $price_prefix=get_post_meta($property->ID, ERE_METABOX_PREFIX . 'property_price_prefix', true);
                                    $price_postfix=get_post_meta($property->ID, ERE_METABOX_PREFIX . 'property_price_postfix', true);
                                    if ( ! empty( $price ) ): ?>
                                        <span class="btn-block fw-bold">
                                            <?php if(!empty( $price_prefix )) {echo '<span class="property-price-prefix fs-12 accent-color">'.$price_prefix.' </span>';} ?>
                                            <?php echo ere_get_format_money( $price_short,$price_unit) ?>
                                            <?php if(!empty( $price_postfix )) {echo '<span class="property-price-postfix fs-12 accent-color"> / '.$price_postfix.'</span>';} ?>
                                        </span>
                                    <?php elseif (ere_get_option( 'empty_price_text', '' ) != '' ): ?>
                                        <span class="btn-block fw-bold"><?php echo ere_get_option( 'empty_price_text', '' ) ?></span>
                                    <?php endif; ?>
                                    <span class="btn-block"><i class="fa fa-map-marker accent-color"></i>
                                        <?php echo get_post_meta($property->ID, ERE_METABOX_PREFIX . 'property_address', true); ?>
                                    </span>
                                    <span class="btn-block mg-bottom-10"><i class="fa fa-eye accent-color"></i>
                                        <?php
                                        $total_views= $ere_property->get_total_views($property->ID);
                                        if($total_views<2)
                                        {
                                            printf(esc_html__('%s view','essential-real-estate'),$total_views);
                                        }
                                        else
                                        {
                                            printf(esc_html__('%s views','essential-real-estate'),$total_views);
                                        }
                                        ?>
                                    </span>
                                <?php elseif ('id' === $key):
                                    echo get_post_meta($property->ID, ERE_METABOX_PREFIX . 'property_identity', true);
                                ?>
                                <?php elseif ('date' === $key) :
                                    echo date_i18n(get_option('date_format'), strtotime($property->post_date));
                                    $listing_expire = ere_get_option('per_listing_expire_days');
                                    if ($paid_submission_type == 'per_listing' && $listing_expire == 1) :
                                        $number_expire_days = ere_get_option('number_expire_days');
                                        $property_date=$property->post_date;
                                        $timestamp = strtotime($property_date) + intval($number_expire_days) * 24 * 60 * 60;
                                        $expired_date=date('Y-m-d H:i:s',$timestamp);
                                        $expired_date = new DateTime($expired_date);

                                        $now = new DateTime();
                                        $interval = $now->diff($expired_date);
                                        $days = $interval->days;
                                        $hours = $interval->h;
                                        $invert=$interval->invert;

                                        if($invert==0)
                                        {
                                            if($days>0)
                                            {
                                                echo '<br><span class="badge">'. sprintf( __( 'Expire: %s days %s hours', 'essential-real-estate' ), $days, $hours).'</span>';
                                            }
                                            else
                                            {
                                                echo '<br><span class="badge">'. sprintf( __( 'Expire: %s hours', 'essential-real-estate' ), $hours).'</span>';
                                            }
                                        }
                                        else
                                        {
                                            $expired_date= date_i18n(get_option('date_format'), $timestamp);
                                            echo '<br><span class="badge badge-expired">'. sprintf( __( 'Expired: %s', 'essential-real-estate' ), $expired_date).'</span>';
                                        }
                                    endif;
                                elseif ('featured' === $key):
                                    $prop_featured = get_post_meta($property->ID, ERE_METABOX_PREFIX . 'property_featured', true);
                                    if ($prop_featured == 1):?>
                                        <span data-toggle="tooltip"
                                              data-placement="bottom"
                                              title="<?php esc_html_e('Featured', 'essential-real-estate') ?>"
                                              class="fa fa-star accent-color"></span>
                                    <?php else: ?>
                                        <span data-toggle="tooltip"
                                              data-placement="bottom"
                                              title="<?php esc_html_e('Not Featured', 'essential-real-estate') ?>"
                                              class="fa fa-minus"></span>
                                    <?php endif;
                                elseif ('status' === $key): ?>
                                    <button id="yo_add_promotion" class="btn btn-default yo_add_promotion" data-property_id="<?php echo $property->ID; ?>" onclick="return false"><?php echo esc_html_e('Add Promotion', 'essential-real-estate'); ?></button>
                                 <?php   
                                else:
                                    do_action('ere_my_properties_column_' . $key, $property); ?>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <br />
    
    <div class="row">
    <div class="col-sm-6">
        <h4 class="ere-dashboard-title"><?php echo __('Add Properties before proceeding', 'essential-real-estate');?></h4>
    </div>
    <div class="col-sm-6 text-right">
            <a class="btn btn-default"
               href="<?php echo $my_promotion_package_link; ?>"><?php
			   if(isset($_COOKIE['yobek_promote_log'])){
					if(strpos($_COOKIE['yobek_promote_log'], ",")){
							$splitter = explode(",", $_COOKIE['yobek_promote_log']);
							esc_html_e('Promote', 'essential-real-estate')."(".count($splitter).")";
					}
					else{
						echo esc_html_e('Promote', 'essential-real-estate')."(1)";
					}
				}
				else{
			    	esc_html_e('Promote', 'essential-real-estate');
				}?></a>
    </div>
</div>
<br>
<?php ere_get_template('global/pagination.php', array('max_num_pages' => $max_num_pages)); ?>