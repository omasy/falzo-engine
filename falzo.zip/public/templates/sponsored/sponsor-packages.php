<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
$allow_submit=yo_allow_submit();
if (!$allow_submit)
{
    echo ere_get_template_html('global/access-denied.php',array('type'=>'not_permission'));
    return;
}
elseif(empty($_COOKIE['yobek_promote_log'])){
	echo ere_get_template_html('global/access-denied.php',array('type'=>'not_permission'));
    return;
}
?>
<div class="ere-package-wrap">
    <div class="ere-heading text-center mg-bottom-60 sm-mg-bottom-40">
        <span></span>
        <h2 class="uppercase mg-bottom-0"><?php esc_html_e('Promotion Packages', 'essential-real-estate') ?></h2>
        <p><?php esc_html_e('Please select a promotion package', 'essential-real-estate') ?></p>
    </div>
    <div class="row">
        <?php
        // Here we get the sponsor option to select promotion types
		// We are going to make use of a formal code
		wp_enqueue_script('promote');
		// GRAB OPTIONS FOR SPONSORED
		$sponsored = yo_get_option('sponsored');
		$promotion=$sponsored["promotion"];
        // Cleanup
        $specification = $promotion['specification'];
		$data_count = count($specification);
		
		// Setting type array
		$sponsor_names=array("Week Traffic", "Month Traffic", "Months Traffic", "Year Traffic", "Years Traffic");
		
        // Lets check data count to know how to display
        if ($data_count >= 4) {
            $css_class = 'col-md-3 col-sm-6';
        } else if ($data_count == 3) {
            $css_class = 'col-md-4 col-sm-6';
        } else if ($data_count == 2) {
            $css_class = 'col-md-4 col-sm-6';
        } else if ($data_count == 1) {
            $css_class = 'col-md-4 col-sm-12';
        } else {
            $css_class = 'col-md-3 col-sm-6';
        }
        for($i=0; $i<count($specification); $i++):
            // Here we select the promotion datas from setting
			$specific=$specification[strtolower($sponsor_names[$i])];
			$duration_hours = $specific['duration'];
			$duration = yo_time_conversion($duration_hours);
			$amount = intval($specific['amount']);
			$traffic = $duration_hours.' traffics';
			$promotion_title = $sponsor_names[$i];
			
            // $payment_link = ere_get_permalink('payment');
            // $payment_process_link = add_query_arg('package_id', get_the_ID(), $payment_link);
            ?>
            <div class="<?php echo esc_attr($css_class); ?>">
                <div class="ere-package-item panel panel-default">
                    <div class="ere-package-title panel-heading text-center"><?php echo esc_attr($promotion_title); ?></div>
                    <ul class="list-group">
                        <li class="list-group-item text-center">
                            <h2 class="ere-package-price fs-50 fw-bold">
                                <?php
                                if($amount>0)
                                {
                                    echo ere_get_format_money($amount,'',0,true);
                                }
                                else
                                {
                                    esc_html_e('Free','falzo');
                                }
                                ?>
                            </h2>
                        </li>
                        <li class="list-group-item">
                            <span class="badge">
                                <?php echo esc_attr($duration); ?>
                            </span>
                            <?php esc_html_e('Expiration Date', 'falzo'); ?>
                        </li>
                        <li class="list-group-item"><span class="badge">
                                    <?php echo esc_attr($traffic); ?>
                                </span><?php esc_html_e('Promotion Traffic', 'falzo'); ?>
								</li>
						<li class="list-group-item">
                        	<span class="badge">
                            	<?php 
								if(isset($_COOKIE['yobek_promote_log'])){
									// Here we get the properties selected
									$property_ids = $_COOKIE['yobek_promote_log'];
									$properties = explode(',', $property_ids);
									if(count($properties) > 0){
										echo count($properties);
									}
									else{
										echo 0;
									}
								}
								else{
									echo 0;
								}	
								?>
                        	</span><?php esc_html_e('Property Selected', 'falzo'); ?>
						</li>
                        <li class="list-group-item text-center">
                            <a href="#" id="yo_promote_item" data-specific="<?php echo strtolower($sponsor_names[$i]); ?>"
                               class="btn btn-primary yo_promote_item"><?php esc_html_e('Promote', 'falzo'); ?></a>
                        </li>
                    </ul>
                </div>
            </div>
        <?php endfor; ?>
        <?php wp_reset_postdata(); ?>
    </div>
</div>