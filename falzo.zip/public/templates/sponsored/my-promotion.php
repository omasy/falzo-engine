<?php
/**
 * @var $my_properties_columns
 * @var $properties
 * @var $max_num_pages
 * @var $post_status
 * @var $title
 * @var $property_identity
 * @var $property_status
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
if(!is_user_logged_in()){
    echo ere_get_template_html('global/access-denied.php',array('type'=>'not_login'));
    return;
}
$allow_submit=yo_allow_submit();
if (!$allow_submit)
{
    echo ere_get_template_html('global/access-denied.php',array('type'=>'not_permission'));
    return;
}
// Lets get the menu template
ere_get_template('global/dashboard-menu.php', array('cur_menu' => 'my_promotion'));

// NOW LETS GET PROMOTION DATAS
$my_promotion_page_link = yo_get_permalink('my_promotion');
$yo_promotion=new YO_Promotion();
$total_promotion = $yo_promotion->get_total_promotion(array('publish', 'pending', 'expired', 'hidden'));
$post_status_approved = add_query_arg(array('post_status' => 'publish'),$my_promotion_page_link);
$total_approved = $yo_promotion->get_total_promotion('publish');
$post_status_pending = add_query_arg(array('post_status' => 'pending'),$my_promotion_page_link);
$total_pending = $yo_promotion->get_total_promotion('pending');
$post_status_expired = add_query_arg(array('post_status' => 'expired'),$my_promotion_page_link);
$total_expired = $yo_promotion->get_total_promotion('expired');

$post_status_hidden = add_query_arg(array('post_status' => 'hidden'),$my_promotion_page_link);
$total_hidden = $yo_promotion->get_total_promotion('hidden');

global $current_user;
wp_get_current_user();
$user_id = $current_user->ID;
//GRAB ALL OPTIONS
$my_promotions_columns = yo_get_option("my_promotion_columns");
$item_amount = 10;

// NOW LETS GET THE PROMOTION DATAS
$posts_status = array('publish', 'pending', 'hidden');
$status_send = isset($_GET['post_status']) ? $_GET['post_status'] : $posts_status;
$args = array(
		'post_type'   => 'falzo_promotion',
		'posts_per_page' => ($item_amount > 0) ? $item_amount : -1,
		'post_status' => $status_send,
		'author'      => $user_id,
		);
$promotions = new WP_Query( $args );
wp_reset_postdata();
// Lets check if id is setted $property_meta_data = get_post_custom($property_data->ID);
if($promotions->found_posts < 1){
	// WE RETURN ACCESS DENIED
	echo ere_get_template_html('global/access-denied.php',array('type'=>'not_permission'));
    return;
}

?>
	<?php $max_num_pages = $promotions->max_num_pages; ?>
    <ul class="ere-my-properties-filter">
        <li class="ere-status-all<?php if (is_array($post_status)) echo ' active' ?>"><a
                href="<?php echo esc_url($my_promotion_page_link); ?>"><?php printf(__('All (%s)', 'essential-real-estate'),$total_promotion);?></a>
        </li>
        <li class="ere-status-publish<?php if ($post_status == 'publish') echo ' active' ?>"><a
                href="<?php echo esc_url($post_status_approved); ?>">
                <?php printf(__('Approved (%s)', 'essential-real-estate'),$total_approved);?></a>
        </li>
        <li class="ere-status-pending<?php if ($post_status == 'pending') echo ' active' ?>"><a
                href="<?php echo esc_url($post_status_pending); ?>">
                <?php printf(__('Pending (%s)', 'essential-real-estate'),$total_pending);?></a>
        </li>
        <li class="ere-status-expired<?php if ($post_status == 'expired') echo ' active' ?>"><a
                href="<?php echo esc_url($post_status_expired); ?>">
                <?php printf(__('Expired (%s)', 'essential-real-estate'),$total_expired);?></a>
        </li>
        <li class="ere-status-hidden<?php if ($post_status == 'hidden') echo ' active' ?>"><a
                href="<?php echo esc_url($post_status_hidden); ?>">
                <?php printf(__('Hidden (%s)', 'essential-real-estate'),$total_hidden);?></a>
        </li>
    </ul>
    
    <!-- SEARCH FORM BEGAN HERE //-->
    
    <!-- SEARCH FORM ENDED HERE //-->
    
    <div class="table-responsive">
    <table class="ere-my-invoices table">
        <thead>
        <tr>
            <?php foreach ($my_promotions_columns as $key => $column) : ?>
                <th class="<?php echo esc_attr($key); ?>"><?php echo esc_html($column); ?></th>
            <?php endforeach; ?>
        </tr>
        </thead>
        <tbody>
        <?php if (empty($promotions)) : ?>
            <tr>
                <td colspan="7"><?php esc_html_e('You don\'t have any promotion listed.', 'essential-real-estate'); ?></td>
            </tr>
        <?php else : ?>
            <?php foreach ($promotions as $promotion) :
                $title = get_the_title($promotion->ID);
				$property_ids = get_post_meta( $promotion->ID, YO_METABOX_PREFIX. 'promotion_items', true );
				// Lets check if its may
				if(strpos($property_ids, ',')!==false){
					// Here we break ids into array
					$property_id_array = explode(',', $property_ids);
				}
				else{
					$property_id = intval($property_ids);
				}
                ?>
                <tr>
                    <?php foreach ($my_promotions_columns as $key => $column) : ?>
                        <td class="<?php echo esc_attr($key); ?>">
                            <?php if ('title' === $key): ?>
                                <a href="<?php echo get_permalink($promotion->ID); ?>"><?php echo $title; ?></a>
                                <?php
                            elseif ('name' === $key) :
                                if(isset($property_id_array) && count($property_id_array)>1){
									// Here we list property count and ids
									echo '<b>Total Promoted Properties: '.count($property_id_array).'</b><br><br>';
									foreach($property_id_array as $property_id){
									echo '<hr>';
									echo esc_html(get_the_title($property_id)." - ID: ".$property_id).'<br>';	
									} // End of loop
								}
								else{
									echo esc_html(get_the_title($property_id)." - ID: ".$property_id);
								}
								
                            elseif ('id' === $key):
                                echo $promotion->ID;
                            elseif ('amount' === $key):
                                $amount = get_post_meta( $promotion->ID, YO_METABOX_PREFIX. 'promotion_amount', true );
                                echo ere_get_format_money($amount)." expires on: ".$yo_promotion->promotion_expires_time($promotion->ID);
                            elseif ('duration' === $key):
                                $duration = get_post_meta( $promotion->ID, YO_METABOX_PREFIX. 'promotion_duration', true );
                                echo $duration.' hours';
                            elseif ('status' === $key):
                                echo get_post_status ( $promotion->ID ); ?>
                                
                            <?php endif; ?>
                        </td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<br>
<?php ere_get_template('global/pagination.php', array('max_num_pages' => $max_num_pages)); ?>