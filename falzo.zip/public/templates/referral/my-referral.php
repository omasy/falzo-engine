<?php
/**
 * @var $my_properties_columns
 * @var $properties
 * @var $max_num_pages
 * @var $post_status
 * @var $title
 * @var $property_identity
 * @var $property_status
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
if(!is_user_logged_in()){
    echo ere_get_template_html('global/access-denied.php',array('type'=>'not_login'));
    return;
}
$allow_submit=yo_allow_submit();
if (!$allow_submit)
{
    echo ere_get_template_html('global/access-denied.php',array('type'=>'not_permission'));
    return;
}
// Lets get the menu template
ere_get_template('global/dashboard-menu.php', array('cur_menu' => 'my_patches'));

// NOW LETS GET PROMOTION DATAS
$my_referral_page_link = ere_get_permalink('my_patches');
$yo_referral = new YO_Referral();
$total_referral = $yo_referral->get_total_referral(array('publish', 'pending', 'expired', 'hidden'));
$post_status_approved = add_query_arg(array('post_status' => 'publish'),$my_patch_page_link);
$total_approved = $yo_referral->get_total_referral('publish');
$post_status_pending = add_query_arg(array('post_status' => 'pending'),$my_patch_page_link);
$total_pending = $yo_referral->get_total_referral('pending');
$post_status_expired = add_query_arg(array('post_status' => 'expired'),$my_patch_page_link);
$total_expired = $yo_referral->get_total_referral('expired');

$post_status_hidden = add_query_arg(array('post_status' => 'hidden'),$my_patch_page_link);
$total_hidden = $yo_referral->get_total_referral('hidden');

global $current_user;
wp_get_current_user();
$user_id = $current_user->ID;
//GRAB ALL OPTIONS
$my_referral_columns = yo_get_option("my_referral_columns");
$item_amount = 10;

// NOW LETS GET THE PROMOTION DATAS
$posts_status = array('publish', 'pending', 'hidden');
$status_send = isset($_GET['post_status']) ? $_GET['post_status'] : $posts_status;
$args = array(
		'post_type'   => 'falzo_referral',
		'posts_per_page' => ($item_amount > 0) ? $item_amount : -1,
		'post_status' => $status_send,
		'author'      => $user_id,
		);
$referrals = new WP_Query( $args );
wp_reset_postdata();
/**** Lets check if id is setted $property_meta_data = get_post_custom($property_data->ID);
if($referrals->found_posts < 1){
	// WE RETURN ACCESS DENIED
	echo ere_get_template_html('global/access-denied.php',array('type'=>'not_permission'));
    return;
}
****/

?>
	<?php $max_num_pages = $referrals->max_num_pages; ?>
    <ul class="ere-my-properties-filter">
        <li class="ere-status-all<?php if (is_array($post_status)) echo ' active' ?>"><a
                href="<?php echo esc_url($my_referral_page_link); ?>"><?php printf(__('All (%s)', 'essential-real-estate'),$total_referral);?></a>
        </li>
        <li class="ere-status-publish<?php if ($post_status == 'publish') echo ' active' ?>"><a
                href="<?php echo esc_url($post_status_approved); ?>">
                <?php printf(__('Approved (%s)', 'essential-real-estate'),$total_approved);?></a>
        </li>
        <li class="ere-status-pending<?php if ($post_status == 'pending') echo ' active' ?>"><a
                href="<?php echo esc_url($post_status_pending); ?>">
                <?php printf(__('Pending (%s)', 'essential-real-estate'),$total_pending);?></a>
        </li>
        <li class="ere-status-expired<?php if ($post_status == 'expired') echo ' active' ?>"><a
                href="<?php echo esc_url($post_status_expired); ?>">
                <?php printf(__('Expired (%s)', 'essential-real-estate'),$total_expired);?></a>
        </li>
        <li class="ere-status-hidden<?php if ($post_status == 'hidden') echo ' active' ?>"><a
                href="<?php echo esc_url($post_status_hidden); ?>">
                <?php printf(__('Hidden (%s)', 'essential-real-estate'),$total_hidden);?></a>
        </li>
    </ul>
    
    <!-- SEARCH FORM BEGAN HERE //-->
    
    <!-- SEARCH FORM ENDED HERE //-->
    <!-- BUTTON TO GET REFERRAL LINK STARTS HERE //-->
    <div class="row">
    <div class="col-sm-6">
        <h4 class="ere-dashboard-title"><?php
		if(isset($_GET["referral_key"])){
			echo "Your referral link: http://www.yobek.com/register/?referral_key=".$_GET["referral_key"]; 
		}
		else{
		 	echo __('Click "Get Link" Button to get referral link', 'essential-real-estate');
		}
		 ?></h4>
    </div>
    <div class="col-sm-6 text-right">
            <a class="btn btn-default" id="get-ref-url"
               href="#"><?php esc_html_e('Get Link', 'essential-real-estate'); ?></a>
    </div>
	</div>
    <!-- BUTTON TO GET REFERRAL LINK ENDS HERE //-->
    <div class="table-responsive">
    <table class="ere-my-invoices table">
        <thead>
        <tr>
            <?php foreach ($my_referral_columns as $key => $column) : ?>
                <th class="<?php echo esc_attr($key); ?>"><?php echo esc_html($column); ?></th>
            <?php endforeach; ?>
        </tr>
        </thead>
        <tbody>
        <?php if (!$referrals) : ?>
            <tr>
                <td colspan="7"><?php esc_html_e('You don\'t have any referral Account.', 'essential-real-estate'); ?></td>
            </tr>
        <?php else : ?>
        <?php 
		// We further get and check the user referral
		$title = get_the_title($referral->ID);
		$referral_key = get_post_meta( $referral->ID, YO_METABOX_PREFIX. 'referral_key', true );
		$rate = get_user_meta( $user_id, YO_METABOX_PREFIX. 'referral_rate', true );
		$user_referrals = get_post_meta($referral_key);
		// Now lets check the user referral
		if(empty($user_referrals)):
		?>
        	<tr>
               <td colspan="7"><?php esc_html_e('You don\'t have any referral listed.', 'essential-real-estate'); ?></td>
            </tr>
          <?php else : ?>
            <?php foreach ($user_referrals as $user_id) :
                $title = get_the_title($referral->ID);
				$user = get_userdata('id', $user_id);
				$username = $user->user_login;
				$email = $user->user_email
				
                ?>
                <tr>
                    <?php foreach ($my_patches_columns as $key => $column) : ?>
                        <td class="<?php echo esc_attr($key); ?>">
                            <?php if ('title' === $key): ?>
                                <a href="<?php echo get_permalink($patches->ID); ?>"><?php echo $title; ?></a>
                                <?php
                            elseif ('name' === $key) :
								echo esc_html($username." - ID: ".$user_id);
                            elseif ('email' === $key):
                                echo $email;
                            elseif ('key' === $key):
                                echo $referral_key;
                            elseif ('rate' === $key):
                                echo $rate.' Rate added';
                            elseif ('status' === $key):
                                echo get_post_status ( $referral->ID ); ?>
                                
                            <?php endif; ?>
                        </td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<br>
<?php ere_get_template('global/pagination.php', array('max_num_pages' => $max_num_pages)); ?>