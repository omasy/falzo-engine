<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>
<div class="modal modal-login fade" id="ere_signin_modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                    aria-hidden="true">&times;</span></button>
            <div class="tab-content ">
                <div class="tab-pane active" id="login">
                    <div class="ere-login-wrap">
						<div id="ere_messages_login" class="ere_messages message"></div>
							<form id="yo-add-agency" method="post" enctype="multipart/form-data">
								<div class="form-group control-name">
									<input id="term_name" name="term[name]" class="form-control control-icon" placeholder="Agency Name" type="text" />
								</div>
								<div class="form-group control-name">
									<input id="term_slug" name="term[slug]" class="form-control control-icon" placeholder="Short Name" type="text" />
								</div>
                                <div class="form-group control-name">
                                    <textarea id="term_description" name="term[description]" class="form-control control-icon" placeholder="Agency Description"></textarea>
								</div>
                                <div class="form-group control-name">
                               	 	<label>Select Your Agency Logo</label><br/>
									<input type="file" name="logo" id="file" required />
                                </div>
                                <input type="hidden" name="term[agent_logo_id]" id="agency_logo_id" value="">
                                <input type="hidden" name="action" id="login_action" value="yo_upgrade_agent_ajax">
								<button type="submit" data-redirect-url="" class="yo-add-agency-button btn btn-primary btn-block">Create</button>
							</form>
							<hr>
                </div>
        </div>
    </div>
</div>
<?php ere_get_template('global/tmpl-template.php'); ?>