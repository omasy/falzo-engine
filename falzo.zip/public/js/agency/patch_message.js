// JavaScript Document
(function ($) {
    'use strict';
    $(document).ready(function ($) {
        if (typeof yo_alert_vars !== "undefined") {
            var ajax_url = yo_alert_vars.ajax_url;
            var processing_text = yo_alert_vars.processing_text;
            $('#yo-reader').on('click', function (e) {
					e.preventDefault();
                	var message_id = $(this).attr("data-message_id");
               	 	$.ajax({
                    	type: 'POST',
                    	url: ajax_url,
                    	data: {
                        	'action': 'yo_alert_stop_ajax',
                        	'message_id': message_id
                    	},
                    	beforeSend: function () {
                        	ERE.show_loading(processing_text);
                    	},
                    	success: function (data) {
							if(data == 1){
								ERE.show_loading('Message read');
                        		$('#yo_alert_modal').hide()
							}
                   	 	}
                	});
            	});
        }
    });
})(jQuery);