// JavaScript Document
(function ($) {
    'use strict';
    $(document).ready(function ($) {
        if (typeof yo_patch_vars !== "undefined") {
            var ajax_url = yo_patch_vars.ajax_url;
            var loading = yo_patch_vars.loading;
            $('form#yo-add-agency').submit(function (e) {
                e.preventDefault();
                var formData = new FormData(this);
                var $messages = $(this).parents('.ere-login-wrap').find('.ere_messages');
                $.ajax({
					url: ajax_url,
                    type: 'POST',
					data: formData,
                    dataType: 'json',
					cache: false,
					processData: false,
					contentType: false,
                    beforeSend: function () {
                        $messages.empty().append('<span class="success text-success"> ' + loading + '</span>');
                    },
                    success: function (response) {
                        if (response.success) {
                            $messages.empty().append('<span class="success text-success"><i class="fa fa-check"></i> ' + response.message + '</span>');
                            if(response.url=='')
                            {
                                window.location.reload();
                            }
                            else
                            {
                                window.location.href = response.url;
                            }
                        } else {
                            if (typeof ere_reset_recaptcha == 'function') {
                                ere_reset_recaptcha();
                            }
                            $messages.empty().append('<span class="error text-danger"><i class="fa fa-close"></i> ' + response.message + '</span>');
                        }
                    },
                    error: function (xhr) {
                        var err = eval("(" + xhr.responseText + ")");
                        console.log(err.Message);
                    }
                })
            });
		}
    });
})(jQuery);