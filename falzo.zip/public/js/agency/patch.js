// JavaScript Document
(function ($) {
    'use strict';
    $(document).ready(function ($) {
        if (typeof yo_patch_vars !== "undefined") {
            var ajax_url = yo_patch_vars.ajax_url;
            var processing_text = yo_patch_vars.processing_text;
            $('.yo_patch').each(function(){
				$(this).on('click', function (e) {
					e.preventDefault();
                	var agency_id = $(this).attr("data-agency_id");
               	 	$.ajax({
                    	type: 'POST',
                    	url: ajax_url,
                    	data: {
                        	'action': 'yo_patch',
                        	'agency_id': agency_id
                    	},
                    	beforeSend: function () {
                        	ERE.show_loading(processing_text);
                    	},
                    	success: function (data) {
                        	window.location.href = data;
                   	 	}
                	});
            	});
			});
        }
    });
})(jQuery);