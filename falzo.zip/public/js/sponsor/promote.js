(function ($) {
    'use strict';
    $(document).ready(function ($) {
        if (typeof yo_promotion_vars !== "undefined") {
            var ajax_url = yo_promotion_vars.ajax_url;
            var processing_text = yo_promotion_vars.processing_text;
            $('.yo_promote_item').each(function(){
				$(this).on('click', function (e) {
					e.preventDefault();
                	var promotion_specific = $(this).attr("data-specific");
               	 	$.ajax({
                    	type: 'POST',
                    	url: ajax_url,
                    	data: {
                        	'action': 'yo_promote_ajax',
                        	'promotion_specification': promotion_specific
                    	},
                    	beforeSend: function () {
                        	ERE.show_loading(processing_text);
                    	},
                    	success: function (data) {
							if(data != -1){
                        		window.location.href = data;
							}
							else{
								ERE.show_loading("Error: promotion can not be submitted");
								setTimeout(function(){
								window.location.reload(true); }, 2000);	
							}
                   	 	}
                	});
            	});
			});
        }
    });
})(jQuery);