// JavaScript Document
(function ($) {
    'use strict';
    $(document).ready(function ($) {
        if (typeof yo_add_promotion_vars !== "undefined") {
            var ajax_url = yo_add_promotion_vars.ajax_url;
            var processing_text = yo_add_promotion_vars.processing_text;
            $('.yo_add_promotion').each(function(){
				$(this).on('click', function (e) {
					e.preventDefault();
                	var property_id = $(this).attr("data-property_id");
					var add_page = "http://www.yobek.com/promote/";
               	 	$.ajax({
                    	type: 'POST',
                    	url: ajax_url,
                    	data: {
                        	'action': 'yo_add_promotion',
                        	'property_id': property_id
                    	},
                    	beforeSend: function () {
                        	ERE.show_loading(processing_text);
                    	},
                    	success: function (data) {
							if(data > 0){
								ERE.show_loading("Product Added");
								setTimeout(function(){
								window.location.href = add_page; }, 1000);
							}
							else{
								ERE.show_loading("Error has occured");
								setTimeout(function(){
								window.location.reload(); }, 1000);
							}
                   	 	}
                	});
            	});
			});
			
			// Here we add and redirect user to promote a particular property
			$('#yo_add_promo_move').on('click', function(e){
				e.preventDefault();
				var property_id = $(this).attr("data-property_id");
				var promte_package_page = $(this).attr("data-promote_package");
               	 $.ajax({
                    type: 'POST',
                    url: ajax_url,
                    data: {
                        'action': 'yo_add_promotion',
                        'property_id': property_id
                    },
                    beforeSend: function () {
                        ERE.show_loading(processing_text);
                    },
                    success: function (data) {
						if(data > 0){
							window.location.href = promte_package_page;
						}
						else{
							ERE.show_loading("Error has occured");
						}
                   	 }
                });
			});
        }
    });
})(jQuery);