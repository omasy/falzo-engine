// JavaScript Document
(function ($) {
    'use strict';
    $(document).ready(function ($) {
        if (typeof yo_referral_vars !== "undefined") {
            var ajax_url = yo_referral_vars.ajax_url;
            var processing_text = yo_referral_vars.processing_text;
            $('#get-ref-url').on('click', function (e) {
				e.preventDefault();
               	 $.ajax({
                    type: 'POST',
                    url: ajax_url,
                    data: {
                        'action': 'yo_referral_request_ajax',
                        'request': 'get_link'
                    },
                    beforeSend: function () {
                        ERE.show_loading(processing_text);
                    },
                    success: function (response) {
						if (response.success) {
							if(response.type=="dm"){
								window.location.href = response.url;
								//alert('Copy your referral Link:\n\n'+response.url);
							}
							else if(response.type=="ca"){
								if(response.url=='')
                            	{
                                	window.location.reload();
                            	}
                            	else
                            	{
                                	window.location.href = response.url;
                            	}
							}
						}
                   	 },
                    error: function (xhr) {
                        var err = eval("(" + xhr.responseText + ")");
                        console.log(err.Message);
                    }
                });
			});
        }
    });
})(jQuery);