<?php
if (!defined('ABSPATH')) {
    exit;
}
if (!class_exists('Falzo_Setup_Admin')) {
    /**
     * Class ERE_Setup_Admin
     */
    class Falzo_Setup_Admin
    {
        /**
         * admin_menu
         */
        public function admin_menu()
        {
            add_menu_page(
                esc_html__( 'Falzo Engine', 'falzo-engine' ),
                esc_html__('Falzo Engine', 'falzo-engine'),
                'manage_options',
                'yo_welcome',
                array($this, 'menu_welcome_page_callback'),
                'dashicons-admin-home',
                2
            );
            add_submenu_page(
                'yo_welcome',
                esc_html__('Welcome', 'falzo-engine'),
                esc_html__('Welcome', 'falzo-engine'),
                'manage_options',
                'yo_welcome',
                array($this, 'menu_welcome_page_callback')
            );
            add_submenu_page(
                'yo_welcome',
                esc_html__('Agency Options', 'falzo-engine'),
                esc_html__('Agency Options', 'falzo-engine'),
                'manage_options',
                'yo_agency',
				array($this, 'falzo_options_page_html')
            );
			add_submenu_page(
                'yo_welcome',
                esc_html__('Sponsored Options', 'falzo-engine'),
                esc_html__('Sponsored Options', 'falzo-engine'),
                'manage_options',
                'yo_sponsored',
				array($this, 'falzo_options_page_html')
            );
			add_submenu_page(
                'yo_welcome',
                esc_html__('Referral Options', 'falzo-engine'),
                esc_html__('Referral Options', 'falzo-engine'),
                'manage_options',
                'yo_referral',
				array($this, 'falzo_options_page_html')
            );
			add_submenu_page(
                'yo_welcome',
                esc_html__('Rank Users', 'falzo-engine'),
                esc_html__('Rank Users', 'falzo-engine'),
                'manage_options',
                'yo_user_rank',
				array($this, 'falzo_options_page_html')
            );
			add_submenu_page(
                'yo_welcome',
                esc_html__('Ninja Setup', 'falzo-engine'),
                esc_html__('Ninja Setup', 'falzo-engine'),
                'manage_options',
                'yo_ninja_setup',
                array($this, 'falzo_ninja_setup')
            );
            add_submenu_page(
                'yo_welcome',
                esc_html__('Setup Page', 'falzo-engine'),
                esc_html__('Setup Page', 'falzo-engine'),
                'manage_options',
                'yo_setup',
                array($this, 'setup_page')
            );
        }
		 
		 
		 
		 /**
         * sponsored_menu
         */
        public function sponsored_menu()
        {
			add_menu_page(
                esc_html__( 'Sponsored', 'falzo-engine' ),
                esc_html__('Sponsored', 'falzo-engine'),
                'manage_options',
                'sponsored',
                array($this, 'menu_welcome_page_callback'),
                'dashicons-admin-site',
                40
            );
            add_submenu_page(
                'sponsored',
                esc_html__('All Sponsored', 'falzo-engine'),
                esc_html__('All Sponsored', 'falzo-engine'),
                'manage_options',
                'edit.php?post_type=falzo_promotion'
            );
		}
		
		
		/**
         * agencing_menu
         */
		 
		public function agency_menu()
        {
			add_menu_page(
                esc_html__( 'Agency', 'falzo-engine' ),
                esc_html__('Agency', 'falzo-engine'),
                'manage_options',
                'Agency',
                array($this, 'menu_welcome_page_callback'),
                'dashicons-share-alt2',
                45
            );
            add_submenu_page(
                'Agency',
                esc_html__('All Patches', 'falzo-engine'),
                esc_html__('All Patches', 'falzo-engine'),
                'manage_options',
				'edit.php?post_type=falzo_patch'
            );
		}
		
		
		
		/**
         * referral_menu
         */
		 
		public function referral_menu()
        {
			add_menu_page(
                esc_html__( 'Referral', 'falzo-engine' ),
                esc_html__('Referral', 'falzo-engine'),
                'manage_options',
                'Referral',
                array($this, 'menu_welcome_page_callback'),
                'dashicons-admin-links',
                50
            );
            add_submenu_page(
                'Referral',
                esc_html__('All Referral', 'falzo-engine'),
                esc_html__('All Referral', 'falzo-engine'),
                'manage_options',
				'edit.php?post_type=falzo_referral'
            );
		}
		 
		 
		 
		 
		 
/***************************** SETTING THE CALL BACK FUNCTIONS *************************************************************************************************/
		 
public function menu_welcome_page_callback()
{
    ?>
 <div class="wrap about-wrap">
                <h1><?php echo sprintf( __( 'Welcome to Falzo Engine %s', 'falzo-engine' ), YO_PLUGIN_VER) ?></h1>
                <div class="about-text">
                    <?php esc_html_e( 'Falzo Engine is the core Functionality that powers yobek.com real estate services. It intended to be private ware designed and maintained by Chukwu Remijius, follow him at www.twitter.com/guruinfinite. Falzo Engine adds extra features to Real Estate Essential Plugin, features like Sponsored service, Referral, Agency and extra widgets addons.', 'falzo-engine' ) ?>
                </div>
                <div class="ere-badge">
                    <img src="<?php echo ERE_PLUGIN_URL.'admin/assets/images/logo.png'; ?>" title="<?php esc_html_e('Logo', 'falzo-engine' ) ?>">
                </div>
                <a href="<?php echo esc_attr( admin_url( 'admin.php?page=yo_setup' ) ) ?>"
                   class="button button-primary"><?php esc_html_e( 'Setup page', 'falzo-engine' ) ?></a>
                <a href="<?php echo esc_attr( admin_url( 'admin.php?page=yo_welcome&falzo_option=reset' ) ) ?>"
                   class="button button-primary"><?php esc_html_e( 'Reset Option', 'falzo-engine' ) ?></a>
                <a href="<?php echo esc_attr( admin_url( 'options-general.php?page=falzo' ) ) ?>"
                   class="button button-secondary"><?php esc_html_e( 'Settings', 'falzo-engine' ) ?></a>
                <div style="margin-top: 50px;">
                    <iframe width="420" height="315"
                            src="https://www.youtube.com/embed/73Cahw3I7JM">
                    </iframe>
                </div>
            </div>
            <?php
        }




/**
 * top level menu:
 * callback functions
 */
public function falzo_options_page_html() {
 // check user capabilities
 if ( ! current_user_can( 'manage_options' ) ) {
 return;
 }
 
 ?>
 <div class="wrap">
 <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
 <?php
  // output the field
 require_once('partials/falzo-option-html.php');
 ?>
 </div>
 <?php
}


/**
 * top level menu:
 * callback functions
 */
public function falzo_ninja_setup() {
 // check user capabilities
 if ( ! current_user_can( 'manage_options' ) ) {
 return;
 }
 
 ?>
 <div class="wrap">
 <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
 <form method="post" action="">
 <input type="hidden" name="ninja-ctrl" value="both" />
 <input type="submit" value="Go" />
 </form>
 <?php
  // output the field
 $ninja = new YO_Patcher();
 $setup = $ninja->wizard();
 if($setup > 0){
	 echo 'I WORKED';
 }
 else{
	 echo 'I DIDNT WORK';
 }
 ?>
 </div>
 <?php
}





/**
 * Redirect the setup page on first activation
  */
public function redirect()
{
 // Bail if no activation redirect transient is set
 if (!get_transient('_ere_activation_redirect')) {
  return;
 }

 if (!current_user_can('manage_options')) {
  return;
 }

 // Delete the redirect transient
 delete_transient('_ere_activation_redirect');

 // Bail if activating from network, or bulk, or within an iFrame
if (is_network_admin() || isset($_GET['activate-multi']) || defined('IFRAME_REQUEST')) {
    return;
 }

if ((isset($_GET['action']) && 'upgrade-plugin' == $_GET['action']) && (isset($_GET['plugin']) && strstr($_GET['plugin'], 'essential-real-estate.php'))) {
    return;
 }

wp_redirect(admin_url('admin.php?page=yo_setup'));
 exit;
 }
 
 
 
 /**
         * Create page on first activation
         * @param $title
         * @param $content
         * @param $option
         */
        private function create_page($title, $content, $option)
        {
            $page_data = array(
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_author' => 1,
                'post_name' => sanitize_title($title),
                'post_title' => $title,
                'post_content' => $content,
                'post_parent' => 0,
                'comment_status' => 'closed'
            );
            $page_id = wp_insert_post($page_data);
            if ($option) {
                $config = get_option(YO_OPTIONS_NAME);
                $config[$option] = $page_id;
                update_option(YO_OPTIONS_NAME, $config);
            }
        }

        /**
         * Output page setup
         */
        public function setup_page()
        {
            $step = !empty($_GET['step']) ? absint($_GET['step']) : 1;
            if (3 === $step && !empty($_POST)) {
                $create_pages = isset($_POST['yo-create-page']) ? $_POST['yo-create-page'] : array();
                $page_titles = isset($_POST['yo-page-title']) ? $_POST['yo-page-title'] : array();
                $pages_to_create = array(
                    'my_promotion' => '[yo_my_promotion]',
					'promotion_packages' => '[yo_sponsor_packages]',
                    'promote' => '[yo_promote_property]',
                    'my_patches' => '[yo_my_patches]',
                    'patch' => '[yo_agency_patch]',
					'upgraded' => '[yo_upgraded]',
                    'my_referral' => '[yo_my_referral]'
                );
                foreach ($pages_to_create as $page => $content) {
                    if (!isset($create_pages[$page]) || empty($page_titles[$page])) {
                        continue;
                    }
                    $this->create_page(sanitize_text_field($page_titles[$page]), $content, 'yo_' . $page . '_page_id');
                }
            }
            ?>
            <div class="ere-setup-wrap">
                <h2><?php esc_html_e('Falzo Setup', 'falzo'); ?></h2>
                <ul class="ere-setup-steps">
                    <li class="<?php if ($step === 1) echo 'ere-setup-active-step'; ?>"><?php esc_html_e('1. Introduction', 'falzo'); ?></li>
                    <li class="<?php if ($step === 2) echo 'ere-setup-active-step'; ?>"><?php esc_html_e('2. Page Setup', 'falzo'); ?></li>
                    <li class="<?php if ($step === 3) echo 'ere-setup-active-step'; ?>"><?php esc_html_e('3. Done', 'falzo'); ?></li>
                </ul>

                <?php if (1 === $step) : ?>

                    <h3><?php esc_html_e('Setup Wizard Introduction', 'falzo'); ?></h3>
                    <p><?php _e('Thanks for installing <em>Falzo-Engine</em>!', 'falzo'); ?></p>
                    <p><?php esc_html_e('This setup wizard will help you get started by creating the pages for property submission, property management, profile management, listing property, listing agent, packages, payment, login, register...', 'falzo'); ?></p>
                    <p><?php printf(__('If you want to skip the wizard and setup the pages and shortcodes yourself manually, the process is still relatively simple. Refer to the %sdocumentation%s for help.', 'falzo'), '<a href="http://document.g5plus.net/essential-real-estate">', '</a>'); ?></p>

                    <p class="submit">
                        <a href="<?php echo esc_url(add_query_arg('step', 2)); ?>"
                           class="button button-primary"><?php esc_html_e('Continue to page setup', 'falzo'); ?></a>
                        <a href="<?php echo esc_url(add_query_arg('skip-yo-setup', 1, admin_url('index.php?page=yo_setup&step=3'))); ?>"
                           class="button"><?php esc_html_e('Skip setup. I will setup the plugin manually (Not Recommended)', 'falzo'); ?></a>
                    </p>

                <?php endif; ?>
                <?php if (2 === $step) : ?>

                    <h3><?php esc_html_e('Page Setup', 'falzo'); ?></h3>

                    <p><?php printf(__('<em>falzo-engine</em> includes %1$sshortcodes%2$s which can be used within your %3$spages%2$s to output content. These can be created for you below. For more information on the falzo-engine shortcodes view the %4$sshortcode documentation%2$s.', 'essential-real-estate'), '<a href="https://codex.wordpress.org/shortcode" title="What is a shortcode?" target="_blank" class="help-page-link">', '</a>', '<a href="http://codex.wordpress.org/Pages" target="_blank" class="help-page-link">', '<a href="http://document.g5plus.net/essential-real-estate" target="_blank" class="help-page-link">'); ?></p>

                    <form action="<?php echo esc_url(add_query_arg('step', 3)); ?>" method="post">
                        <table class="ere-shortcodes widefat">
                            <thead>
                            <tr>
                                <th>&nbsp;</th>
                                <th><?php esc_html_e('Page Title', 'falzo'); ?></th>
                                <th><?php esc_html_e('Page Description', 'falzo'); ?></th>
                                <th><?php esc_html_e('Content Shortcode', 'falzo'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td><input type="checkbox" checked="checked"
                                           name="yo-create-page[my_promotion]"/></td>
                                <td><input type="text"
                                           value="<?php echo esc_attr(_x('My Promotion', 'Default page title (wizard)', 'falzo')); ?>"
                                           name="yo-page-title[my_promotion]"/></td>
                                <td>
                                    <p><?php esc_html_e('This page allows users to view and manage their promoted properties via the front-end.', 'falzo'); ?></p>
                                </td>
                                <td><code>[yo_my_promotion]</code></td>
                            </tr>
                            <tr>
                                <td><input type="checkbox" checked="checked"
                                           name="yo-create-page[promotion_packages]"/></td>
                                <td><input type="text"
                                           value="<?php echo esc_attr(_x('Select Promotion', 'Default page title (wizard)', 'falzo')); ?>"
                                           name="yo-page-title[promotion_packages]"/></td>
                                <td>
                                    <p><?php esc_html_e('This page is were you select packages.', 'falzo'); ?></p>
                                </td>
                                <td><code>[yo_sponsor_packages]</code></td>
                            </tr>
                            <tr>
                                <td><input type="checkbox" checked="checked"
                                           name="yo-create-page[promote]"/></td>
                                <td><input type="text"
                                           value="<?php echo esc_attr(_x('Promote', 'Default page title (wizard)', 'falzo')); ?>"
                                           name="yo-page-title[promote]"/></td>
                                <td>
                                    <p><?php esc_html_e('This page allows users to promote property at the frontend.', 'falzo'); ?></p>
                                </td>
                                <td><code>[yo_promote_property]</code></td>
                            </tr>
                            <tr>
                                <td><input type="checkbox" checked="checked"
                                           name="yo-create-page[my_patches]"/></td>
                                <td><input type="text"
                                           value="<?php echo esc_attr(_x('My Patch', 'Default page title (wizard)', 'falzo')); ?>"
                                           name="yo-page-title[my_patches]"/></td>
                                <td>
                                    <p><?php esc_html_e('This page allows users to view patches.', 'falzo'); ?></p>
                                </td>
                                <td><code>[yo_my_patches]</code></td>
                            </tr>
                            <tr>
                                <td><input type="checkbox" checked="checked"
                                           name="yo-create-page[patch]"/></td>
                                <td><input type="text"
                                           value="<?php echo esc_attr(_x('Patch', 'Default page title (wizard)', 'falzo')); ?>"
                                           name="yo-page-title[patch]"/></td>
                                <td>
                                    <p><?php esc_html_e('This page allows users to patch with "agency" via the front-end.', 'falzo'); ?></p>
                                </td>
                                <td><code>[yo_agency_patch]</code></td>
                            </tr>
                            <tr>
                                <td><input type="checkbox" checked="checked"
                                           name="yo-create-page[upgraded]"/></td>
                                <td><input type="text"
                                           value="<?php echo esc_attr(_x('Agent Upgraded', 'Default page title (wizard)', 'falzo')); ?>"
                                           name="yo-page-title[upgraded]"/></td>
                                <td>
                                    <p><?php esc_html_e('This is upgraded page.', 'falzo'); ?></p>
                                </td>
                                <td><code>[yo_upgraded]</code></td>
                            </tr>
                            <tr>
                                <td><input type="checkbox" checked="checked"
                                           name="yo-create-page[my_referral]"/></td>
                                <td><input type="text"
                                           value="<?php echo esc_attr(_x('My Referral', 'Default page title (wizard)', 'falzo')); ?>"
                                           name="yo-page-title[my_referral]"/></td>
                                <td>
                                    <p><?php esc_html_e('This is referral list page.', 'falzo'); ?></p>
                                </td>
                                <td><code>[yo_my_referral]</code></td>
                            </tr>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th colspan="4">
                                    <input type="submit" class="button button-primary" value="<?php esc_html_e('Create selected pages', 'essential-real-estate'); ?>"/>
                                    <a href="<?php echo esc_url(add_query_arg('step', 3)); ?>"
                                       class="button"><?php esc_html_e('Skip this step', 'falzo'); ?></a>
                                </th>
                            </tr>
                            </tfoot>
                        </table>
                    </form>

                <?php endif; ?>
                <?php if (3 === $step) : ?>

                    <h3><?php esc_html_e('All Done!', 'essential-real-estate'); ?></h3>

                    <p><?php esc_html_e('Looks like you\'re all set to start using the plugin. In case you\'re wondering where to go next:', 'essential-real-estate'); ?></p>

                    <ul class="ere-next-steps">
                        <li>
                            <a href="<?php echo admin_url('themes.php?page=ere_options'); ?>"><?php esc_html_e('Real Estate plugin settings', 'essential-real-estate'); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo admin_url('post-new.php?post_type=property'); ?>"><?php esc_html_e('Add a property the back-end', 'essential-real-estate'); ?></a>
                        </li>
                        <?php if ($permalink = yo_get_permalink('my_promotion')) : ?>
                            <li>
                                <a href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('View my promotion in profile', 'essential-real-estate'); ?></a>
                            </li>
                        <?php endif; ?>
                        <?php if ($permalink = yo_get_permalink('promotion_packages')) : ?>
                            <li>
                                <a href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('Selecting promotion packages', 'essential-real-estate'); ?></a>
                            </li>
                        <?php endif; ?>
                        <?php if ($permalink = yo_get_permalink('promote')) : ?>
                            <li>
                                <a href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('Promote your property', 'essential-real-estate'); ?></a>
                            </li>
                        <?php endif; ?>
                        <?php if ($permalink = yo_get_permalink('my_favorites')) : ?>
                            <li>
                                <a href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('View my patches', 'essential-real-estate'); ?></a>
                            </li>
                        <?php endif; ?>
                        <?php if ($permalink = yo_get_permalink('upgraded')) : ?>
                            <li>
                                <a href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('View upgraded account', 'essential-real-estate'); ?></a>
                            </li>
                        <?php endif; ?>
                        <?php if ($permalink = yo_get_permalink('my_referral')) : ?>
                            <li>
                                <a href="<?php echo esc_url($permalink); ?>"><?php esc_html_e('View my referral', 'essential-real-estate'); ?></a>
                            </li>
                        <?php endif; ?>
                    </ul>
                <?php endif; ?>
            </div>
            <?php
        }
 
 
		
	} // END CLASS
} // END OF CLASS EXIST CHECH
?>