<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://twitter.com/guruinfinite
 * @since      1.0.0
 *
 * @package    Falzo
 * @subpackage Falzo/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Falzo
 * @subpackage Falzo/admin
 * @author     Chukwu Remijius <gettrafficworld@yahoo.com>
 */
class Falzo_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Falzo_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Falzo_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/falzo-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Falzo_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Falzo_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/falzo-admin.js', array( 'jquery' ), $this->version, false );

	}
	
	
	/**
*
* admin/class-wp-cbf-admin.php - Don't add this
*
**/

/**
 * Register the administration menu for this plugin into the WordPress Dashboard menu.
 *
 * @since    1.0.0
 */

public function add_plugin_admin_menu() {

    /*
     * Add a settings page for this plugin to the Settings menu.
     *
     * NOTE:  Alternative menu locations are available via WordPress administration menu functions.
     *
     *        Administration Menus: http://codex.wordpress.org/Administration_Menus
     *
     */
    add_options_page( 'Falso Plugin Admin Interface', 'Falso Plugin', 'manage_options', $this->plugin_name, array($this, 'display_plugin_setup_page')
    );
}

 /**
 * Add settings action link to the plugins page.
 *
 * @since    1.0.0
 */

public function add_action_links( $links ) {
    /*
    *  Documentation : https://codex.wordpress.org/Plugin_API/Filter_Reference/plugin_action_links_(plugin_file_name)
    */
   $settings_link = array(
    '<a href="' . admin_url( 'options-general.php?page=' . $this->plugin_name ) . '">' . __('Settings', $this->plugin_name) . '</a>',
   );
   return array_merge(  $settings_link, $links );

}

/**
 * Render the settings page for this plugin.
 *
 * @since    1.0.0
 */

public function display_plugin_setup_page() {
    include_once( 'partials/falzo-admin-display.php' );
}


/****************** HERE MY FUNCTIONS STARTS ********************************/
public function plugin_admin_add_page() {
  //http://codex.wordpress.org/Function_Reference/add_menu_page
  add_menu_page( 'Falzo Administration Panel', 'Falzo', 'manage_options', 'falzo-admin/adminpage.php');
}



public function my_enqueue($hook) {
  //only for our special plugin admin page
  if( 'falzo-admin/adminpage.php' != $hook )
    return;
  // wp_register_style('dbexplorer', plugins_url('dbexplorer/pluginpage.css'));
  // wp_enqueue_style('dbexplorer');
  // wp_enqueue_script('pluginscript', plugins_url('pluginpage.js', __FILE__ ), array('jquery'));
}


/************************************ THERE ALWAYS LIGHT AT THE END OF THE TUNNEL HOPE IS ALL WE HAVE ***************************************************/
public function falzo_option_creator(){
	// LETS START PROCESSING THE FALZO OPTIONS
	// HERE OPTION IS WHAT CONTROLS THE FLOW OF DATA IN THE FALZO ENGINE
	$falzo_options = array(
	'sponsored' => array(
	'promotion' => array(
	'type' => array('item', 'banner'),
	'specification' => array(
	'week traffic' => array('duration' => 168, 'amount' => 30),
	'month traffic' => array('duration' => 720, 'amount' => 80),
	'months traffic' => array('duration' => 2160, 'amount' => 170),
	'year traffic' => array('duration' => 8640, 'amount' => 350),
	'years traffic' => array('duration' => 17280, 'amount' => 500)
	)
	//specification ends
	),
	//promotion ends
	'position' => 'side-bar',
	'filter' => 'related'
	),
	// End of Sponsored
	// Referral begins here
	'referral' => array(
	'rate' => 10,
	'discount' => 'yes',
	'approval' => 100
	), // Referral ends here
	// Agency begins here
	'agency' => array(
	'patching' => array(
	'price' => 25,
	'rank' => 100,
	'benefit' => array(
	'rate' => 10,
	'approval' => 'yes',
	) // end of benefit
	), // end of patching
	'ranking' => array(
	'super' => '6000-in',
	'pro' => '100-5999',
	'starter' => '1-99'
	) // end of ranking
	), // Agency ends here
	// Messaging begins here
	'messaging' => array(
	'email' => array(
	'user_mail' => array(
	'agency' => array(
	'subject' => esc_html__('Thank you for patching - A request for patch', 'falzo'),
	'message' => esc_html__('%username your request for patching with %agent has been recieved and will be approved in the immediate time factor %website_url', 'falzo')
	), // agency mail ends
	'promotion' => array(
	'subject' => esc_html__('Thank you for promotion - A request for promotion', 'falzo'),
	'message' => esc_html__('%username your promotion package has been created and your payment will be monitored, as after which we are going to approve the purchase %website_url', 'falzo'),
	'mail_new_wire_transfer_patch' => array(
	'subject' => esc_html__('Wire transfer payment notification - Patch payment', 'falzo'),
	'message' => esc_html__('%username your payment request yobek agency patch has been sent with invoice no: %invoice_no and total amount of %total_price, Thank you@%website_url', 'falzo')
	),
	'mail_new_wire_transfer_promotion' => array(
	'subject' => esc_html__('Wire transfer payment notification - Promotion payment', 'falzo'),
	'message' => esc_html__('%username your payment request yobek promotion has been sent with invoice no: %invoice_no and promotion title: %Promotion_title, Thank you@%website_url', 'falzo')
	),
	'mail_new_bank_deposit_patch' => array(
	'subject' => esc_html__('Bank deposit payment notification - Patch payment', 'falzo'),
	'message' => esc_html__('%username your payment request yobek agency patch has been sent with invoice no: %invoice_no and total amount of %total_price, Thank you@%website_url', 'falzo')
	),
	'mail_new_bank_deposit_promotion' => array(
	'subject' => esc_html__('Bank deposit payment notification - Promotion payment', 'falzo'),
	'message' => esc_html__('%username your payment request yobek promotion has been sent with invoice no: %invoice_no and promotion title: %Promotion_title, Thank you@%website_url', 'falzo')
	),
	'mail_new_paypal_patch' => array(
	'subject' => esc_html__('Paypal payment notification - Patch payment', 'falzo'),
	'message' => esc_html__('%username your payment request yobek agency patch has been sent with invoice no: %invoice_no and patch title: %patch_title, Thank you@%website_url', 'falzo')
	),
	'mail_new_paypal_promotion' => array(
	'subject' => esc_html__('Paypal payment notification - Promotion payment', 'falzo'),
	'message' => esc_html__('%username your payment request yobek promotion has been sent with invoice no: %invoice_no and promotion title: %promotion_title, Thank you@%website_url', 'falzo')
	),
	'mail_new_stripe_patch' => array(
	'subject' => esc_html__('Stripe payment notification - Patch payment', 'falzo'),
	'message' => esc_html__('%username your payment request yobek agency patch has been sent with invoice no: %invoice_no and patch title: %patch_title, Thank you@%website_url', 'falzo')
	),
	'mail_new_stripe_promotion' => array(
	'subject' => esc_html__('Stripe payment notification - Promotion payment', 'falzo'),
	'message' => esc_html__('%username your payment request yobek promotion has been sent with invoice no: %invoice_no and promotion title: %promotion_title, Thank you@%website_url', 'falzo')
	)
	// end of messages
	) // sponsored mail ends
	), // user email ends
	'admin_mail' => array(
	'agency' => array(
	'subject' => esc_html__('Agent patch request - A request for patch', 'falzo'),
	'message' => esc_html__('User %username has request to patch with your agency - please confirm message by click the button below %user_email', 'falzo')
	), // agency mail ends
	'promotion' => array(
	'subject' => esc_html__('%username promotion - A request for patch', 'falzo'),
	'message' => esc_html__('User %username has purchased a promotion package with pending approval - please confirm message by click the button below %user_email', 'falzo')
	), // sponsored mail ends
	'admin_mail_new_wire_transfer_patch' => array(
	'subject' => esc_html__('Wire transfer payment notification - Patch payment', 'falzo'),
	'message' => esc_html__('User %username has requested wire transfer payment for yobek agency patch with invoice no: %invoice_no and total amount of %total_price, Thank you@%website_url', 'falzo')
	),
	'admin_mail_new_wire_transfer_promotion' => array(
	'subject' => esc_html__('Wire transfer payment notification - Promotion payment', 'falzo'),
	'message' => esc_html__('User %username has requested wire transfer payment for yobek promotion with invoice no: %invoice_no and promotion title: %Promotion_title, Thank you@%website_url', 'falzo')
	),
	'admin_mail_new_bank_deposit_patch' => array(
	'subject' => esc_html__('Bank deposit payment notification - Patch payment', 'falzo'),
	'message' => esc_html__('User %username has requested bank deposit payment for yobek agency patch with invoice no: %invoice_no and total amount of %total_price, Thank you@%website_url', 'falzo')
	),
	'admin_mail_new_bank_deposit_promotion' => array(
	'subject' => esc_html__('Bank deposit payment notification - Promotion payment', 'falzo'),
	'message' => esc_html__('User %username has requested bank deposit payment for  yobek promotion with invoice no: %invoice_no and promotion title: %Promotion_title, Thank you@%website_url', 'falzo')
	),
	'admin_mail_new_paypal_patch' => array(
	'subject' => esc_html__('Paypal payment notification - Patch payment', 'falzo'),
	'message' => esc_html__('User %username has requested paypal payment for yobek agency patch with invoice no: %invoice_no and patch title: %patch_title, Thank you@%website_url', 'falzo')
	),
	'admin_mail_new_paypal_promotion' => array(
	'subject' => esc_html__('Paypal payment notification - Promotion payment', 'falzo'),
	'message' => esc_html__('User %username has requested paypal payment for  yobek promotion with invoice no: %invoice_no and promotion title: %promotion_title, Thank you@%website_url', 'falzo')
	),
	'admin_mail_new_stripe_patch' => array(
	'subject' => esc_html__('Stripe payment notification - Patch payment', 'falzo'),
	'message' => esc_html__('User %username has requested stripe payment for yobek agency patch with invoice no: %invoice_no and patch title: %patch_title, Thank you@%website_url', 'falzo')
	),
	'admin_mail_new_stripe_promotion' => array(
	'subject' => esc_html__('Stripe payment notification - Promotion payment', 'falzo'),
	'message' => esc_html__('User %username has requested stripe payment for  yobek promotion with invoice no: %invoice_no and promotion title: %promotion_title, Thank you@%website_url', 'falzo')
	),
	'admin_mail_patch_benefit' => array(
	'subject' => esc_html__('Patch benefit notification - Patch benefit', 'falzo'),
	'message' => esc_html__('Agent %username has been benefited for user to user agency patch program with package id: %package_id, and package price: %package_price, Thank you@%website_url', 'falzo')
	)
	// end of messages
	) // admin email ends
	), // Email ends
	// Message begins here
	'message' => array(
	'agency' => array(
	'title' => esc_html__('Agent patch request - A request for patch', 'falzo'),
	'content' => esc_html__('User %username has request to patch with your agency - please confirm message by click the button below.', 'falzo')
	),
	)
	),
	// Setting my promotion table fields header
	'my_promotion_columns' => array('title' => 'Title', 'name' => 'Property', 'id' => 'Promotion ID', 'amount' => 'amount', 'duration' => 'Duration', 'status' => 'Status'),
	'my_patches_columns' => array('title' => 'Title', 'name' => 'Agency', 'id' => 'Patch ID', 'rank' => 'Award Rank', 'price' => 'Patch Price', 'status' => 'Status'),
	'my_referral_columns' => array('title' => 'Title', 'name' => 'Username', 'email' => 'Email', 'key' => 'Referral Key', 'rate' => 'Referral', 'status' => 'Status'),
	'my_properties_columns' => array('picture' => 'Picture', 'title' => 'Title', 'id' => 'ID', 'date' => 'Date Posted', 'featured' => 'Featured', 'status' => 'Status'),
	'my_agency_columns' => array('picture' => 'Picture', 'title' => 'Title', 'id' => 'ID', 'phone' => 'Agency Phone', 'action' => 'Action', 'patch' => 'Patch With'),
	'admin_table_classes' => array('picture', 'title', 'id', 'date', 'featured', 'status'),
	// Setting the falzo ninja option
	'ninja_options' => array(
	'add' => array(
	'a' => array('from' => 'includes/falzo-ninja/src/codes/main/my-patch/', 'to' => 'public/templates/widgets/my-patch/'),
	'b' => array('from' => 'includes/falzo-ninja/src/codes/main/pay/', 'to' => 'public/templates/payment/')
	),
	'replace' => array(
	'a' => array('from' => 'includes/falzo-ninja/src/codes/hack/register/', 'to' => 'public/partials/account/'),
	'b' => array('from' => 'includes/falzo-ninja/src/codes/hack/assets/payment/', 'to' => 'public/assets/js/payment/'),
	'c' => array('from' => 'includes/falzo-ninja/src/templates/account/package/', 'to' => 'public/partials/package/'),
	'd' => array('from' => 'includes/falzo-ninja/src/templates/account/template/', 'to' => 'public/templates/account/'),
	'e' => array('from' => 'includes/falzo-ninja/src/templates/menu/login-menu/', 'to' => 'public/templates/widgets/login-menu/'),
	'f' => array('from' => 'includes/falzo-ninja/src/templates/menu/dashboard-menu/', 'to' => 'public/templates/global/'),
	'g' => array('from' => 'includes/falzo-ninja/src/templates/payment/', 'to' => 'public/templates/payment/')
	)
	),
	// Deposit and wire account detail
	'thankyou-content-bank-details' => 'You can make direct transfer or bank deposit to our account using the following account detail
	<p><b>Bank Name:</b> Guarantee Trust Bank(GTBank)<br><b>Account Name:</b> Chukwu Chinedu Remijius<br><b>Account Number:</b> 0136560901</p>
	<i><b style="color:#911">NOTE: After making payment please send us the Order ID you see on this page, with your proof of payment to info@yobek.com so we can confirm your payment</b></i>
	<p>Payment will be processed and confirmed within 24 hours of reception.</p>',
	// Setting payment approval
	'enable_bank_deposit' => 1,
	// Setting functionality option
	'enable_patching' => 1,
	'enable_sponsoring' => 1,
	'enable_referral' => 1,
	'enable_submit_promotion_via_frontend' => 1,
	'user_can_submit' => 1,
	'promotion_available' => 0,
	'has_top_ranked' => 0,
	'has_super_ranked' => 0,
	// Page id Options
	'yo_my_promotion_page_id'=>'',
	'yo_promotion_packages_page_id'=>'',
	'yo_promote_page_id'=>'',
	'yo_my_patches_page_id'=>'',
	'yo_patch_page_id'=>'',
	'yo_my_referral_page_id'=>'',
	'yo_upgraded_page_id'=>''
	);
	
	// NOW LETS CREATE OPTION IF IT DOESNT EXIST YET
	// LETS CHECK THE RESET OPTION PARAMETER
	if(isset($_GET['falzo_option'])){
		$falzo_opt = $_GET['falzo_option'];
		if($falzo_opt == 'reset'){
			// Here we delete option and add again if option exists
			if(get_option('falzo_options')){
				update_option("falzo_options", $falzo_options);
			}
		}
	}
	else{
		// Here we only add option if it doesn't exist
		if(!get_option('falzo_options')){
			// We add option
			update_option("falzo_options", $falzo_options);
		}
	}
// END OF METHOD
}


/***************************** SETTING CUSTOM POST TYPE FOR FALZO ENGINE *******************************/
public function falzo_custom_post_type(){
	// LETS START SETTING THE POST TYPES
	$promotion=array(
	'labels' => array(
              'name' => __('Promotions'),
              'singular_name' => __('Promotion'),
                     ),
                 	'public' => true,
                    'has_archive' => true,
                    'rewrite' => array('slug' => 'promotion')
		);
		
	$referral=array(
	'labels' => array(
              'name' => __('Referral'),
              'singular_name' => __('Referral'),
                     ),
                 	'public' => true,
                    'has_archive' => true,
                    'rewrite' => array('slug' => 'referral')
		);
		
	$patch=array(
	'labels' => array(
              'name' => __('Patches'),
              'singular_name' => __('Patch'),
                     ),
                 	'public' => true,
                    'has_archive' => true,
                    'rewrite' => array('slug' => 'patch')
		);
		
	$patch_message=array('labels' => array(
              'name' => __('patch_message'),
              'singular_name' => __('message'),
                     ),
                 	'public' => true,
                    'has_archive' => true,
                    'rewrite' => array('slug' => 'patch_message')
		);
	
	// Checking and logging post type for patch
	if(!post_type_exists( 'falzo_promotion' )){
	register_post_type('falzo_promotion', $promotion);
	}
	
	// Checking and logging post type for patch
	if(!post_type_exists( 'falzo_referral' )){
	register_post_type('falzo_referral', $referral);
	}
	
	// Checking and logging post type for patch
	if(!post_type_exists( 'falzo_patch' )){
	register_post_type('falzo_patch', $patch);
	}
	
	// Checking and logging post type for patch
	if(!post_type_exists( 'falzo_message' )){
	register_post_type('falzo_message', $patch_message);
	}

// End of method		
}

// END OF CLASS
}
