<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
if (!class_exists('YO_Agency_Admin')) {
    /**
     * Class ERE_Agent_Admin
     */
    class YO_Agency_Admin
    {
        /**
         * Register custom columns
         * @param $columns
         * @return array
         */
        public function register_custom_column_titles($columns)
        {
            unset($columns['tags']);
            $columns['title'] = esc_html__('Title', 'essential-real-estate');
            $columns['agency'] = esc_html__('Agency', 'essential-real-estate');
            $columns['agent'] =  esc_html__('Agent', 'essential-real-estate');
            $columns['status'] =esc_html__('Status', 'essential-real-estate');
            $new_columns = array();
            foreach ( $columns as $key => $value ) {
                $new_columns[$key] = $value;
            }
            return $new_columns;
        }

        /**
         * Display custom column for agents
         * @param $column
         */
        public function display_custom_column($column)
        {
            global $post;
			$user_id = get_post_meta( $post->ID, YO_METABOX_PREFIX. 'user_id', true );
            switch ($column) {
                case 'title':
                    $title = get_the_title($post->ID);
					if(!empty($title)){
						echo $title;
                    } else {
                        echo '&ndash;';
                    }
                    break;
                case 'agency':
					$term_id = get_post_meta( $post->ID, YO_METABOX_PREFIX. 'agency_id', true );
					$term = get_term($term_id, 'agency');
                    $allowed_html = array(
                        'a' => array(
                            'href' => array(),
                            'title' => array(),
                            'target' => array()
                        )
                    );
                    if (!empty($term)) {
                        echo wp_kses($term->name, $allowed_html);
                    } else {
                        echo '&ndash;';
                    }
                    break;
                case 'agent':
                    $agent_id = get_user_meta( $user_id, YO_METABOX_PREFIX. 'agent_id', true );
					$agent_name = get_the_title($agent_id);
                    if (!empty($agent_name)) {
                        echo esc_attr($agent_name);
                    } else {
                        echo '&ndash;';
                    }
                    break;
				case 'status':
                    $status = get_post_status($post->ID);

                    if (!empty($status)) {
                        echo esc_attr($status);
                    } else {
                        echo '&ndash;';
                    }
                    break;
            }
        }

        /**
         * @param $actions
         * @param $post
         * @return mixed
         */
        public function modify_list_row_actions( $actions, $post ) {
            // Check for your post type.
            if ( $post->post_type == 'falzo_patch' ) {
                if (in_array($post->post_status, array('pending')) && current_user_can('publish_agents', $post->ID)) {
                    $actions['patch-approve']='<a href="'.wp_nonce_url(add_query_arg('approve_patch', $post->ID), 'approve_patch').'">'.esc_html__('Approve', 'essential-real-estate').'</a>';
                }
            }
            return $actions;
        }
        

        /**
         * Approve Agent
         */
        public function approve_patch()
        {
            if (!empty($_GET['approve_patch']) && wp_verify_nonce($_REQUEST['_wpnonce'], 'approve_patch') && current_user_can('publish_post', $_GET['approve_patch'])) {
                $post_id = absint($_GET['approve_patch']);
                $listing_data = array(
                    'ID' => $post_id,
                    'post_status' => 'publish'
                );
                wp_update_post($listing_data);

                $author_id = get_post_field('post_author', $post_id);
                $user = get_user_by('id', $author_id);
                $user_email = $user->user_email;

                $args = array(
                    'patch_name' => get_the_title($post_id),
                    'patch_url' => get_permalink($post_id)
                );
                ere_send_email($user_email, 'mail_approved_agent', $args);
                wp_redirect(remove_query_arg('approve_agent', add_query_arg('approve_agent', $post_id, admin_url('edit.php?post_type=falzo_patch'))));
                exit;
            }
        }
        /**
         * filter_restrict_manage_agent
         */
        public function filter_restrict_manage_patch() {
            global $typenow;
            $post_type = 'falzo_patch';
            if ($typenow == $post_type) {
                $taxonomy='agency';
                $selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
                $info_taxonomy = get_taxonomy($taxonomy);
                wp_dropdown_categories(array(
                    'show_option_all' => __("All {$info_taxonomy->label}"),
                    'taxonomy'        => $taxonomy,
                    'name'            => $taxonomy,
                    'orderby'         => 'name',
                    'selected'        => $selected,
                    'show_count'      => true,
                    'hide_empty'      => false,
                ));
            };
        }

        /**
         * agent_filter
         * @param $query
         */
        public function patch_filter($query) {
            global $pagenow;
            $post_type = 'falzo_patch';
            $q_vars    = &$query->query_vars;
            if ($pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type)
            {
                $taxonomy='agency';
                if (isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0) {
                    $term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
                    $q_vars[$taxonomy] = $term->slug;
                }
            }
        }
    }
}