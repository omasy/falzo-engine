<?php
		// GRAB OPTIONS FOR SPONSORED
		$referral=$options["referral"];
		$rate=$referral["rate"];
		$discount=$referral["discount"];
		$approval=$referral["approval"];
		
 ?>
<form method="post" novalidate="novalidate">
<input type='hidden' name='falzo_options' value='referral' />
<table class="form-table">
<tr>
<th scope="row">Referral Specification</th>
<td>
	<fieldset><legend class="screen-reader-text"><span>Referral Specification</span></legend>
	<label><input name="rate" type="text" id="rate" aria-describedby="tagline-description" value="<?php echo $rate; ?>" class="regular-text" /> <span class="date-time-text format-i18n">Bonus Rate</span></label><br />
	<label><input name="discount" type="text" id="discount" aria-describedby="tagline-description" value="<?php echo $discount; ?>" class="regular-text" /> <span class="date-time-text format-i18n">Referral Discount</span></label><br />
    <label><input name="approval" type="text" id="approval" aria-describedby="tagline-description" value="<?php echo $approval; ?>" class="regular-text" /> <span class="date-time-text format-i18n">Discount Approval Rate</span></label><br />
	</fieldset>
</td>
</tr>
</table>
<p>Click Save Options to store option changes</p>
<?php
 // output save settings button
 submit_button( 'Save Options' );
?>

</form>