<?php
		// GRAB OPTIONS FOR SPONSORED
		$agency=$options["agency"];
		$patching=$agency["patching"];
		$ranking=$agency["ranking"];
        // Cleanup
		$price=$patching["price"];
		$rank=$patching["rank"];
		$benefit=$patching["benefit"];
		
        $rate = $benefit['rate'];
        $approval = $benefit['approval'];
		
		// Setting type array
		$rank_names=array("super", "pro", "starter");
		
 ?>
<form method="post" novalidate="novalidate">
<input type='hidden' name='falzo_options' value='agency' />
<table class="form-table">
<tr>
<th scope="row">Patching Specification</th>
<td>
	<fieldset><legend class="screen-reader-text"><span>Patching Specification</span></legend>
	<label><input name="price" type="text" id="" aria-describedby="tagline-description" value="<?php echo $price; ?>" class="regular-text" /> <span class="date-time-text format-i18n">Patch Price</span></label><br />
	<label><input name="award-rank" type="text" id="" aria-describedby="tagline-description" value="<?php echo $rank; ?>" class="regular-text" /> <span class="date-time-text format-i18n">Award Rank</span></label><br />
	</fieldset>
</td>
</tr>

<tr>
<th scope="row">Patch Benefit Specification</th>
<td>
	<fieldset><legend class="screen-reader-text"><span>Patch Profit Specification</span></legend>
	<label><input name="benefit-rate" type="text" id="" aria-describedby="tagline-description" value="<?php echo $rate; ?>" class="regular-text" /> <span class="date-time-text format-i18n">Benefit Rate</span></label><br />
	<label><input name="benefit-approval" type="text" id="" aria-describedby="tagline-description" value="<?php echo $approval; ?>" class="regular-text" /> <span class="date-time-text format-i18n">Benefit Approval</span></label><br />
	</fieldset>
</td>
</tr>

<?php for($i=0; $i<count($ranking); $i++): ?>	
<?php 
$specific=$ranking[strtolower($rank_names[$i])];
$specArray=explode("-", $specific);
$from=$specArray[0];
$to=$specArray[1];
 ?>
<tr>
<th scope="row"><?php echo ucfirst($rank_names[$i])." Agent"; ?></th>
<td>
	<fieldset><legend class="screen-reader-text"><span>Ranking Specification</span></legend>
	<label><input name="<?php echo strtolower(str_replace(" ", "-", $rank_names[$i]))."-from"; ?>" type="text" id="<?php echo strtolower(str_replace(" ", "-", $rank_names[$i]))."-from"; ?>" aria-describedby="tagline-description" value="<?php echo $from; ?>" class="regular-text" /> <span class="date-time-text format-i18n">Start Rank</span></label><br />
	<label><input name="<?php echo strtolower(str_replace(" ", "-", $rank_names[$i]))."-to"; ?>" type="text" id="<?php echo strtolower(str_replace(" ", "-", $rank_names[$i]))."-to"; ?>" aria-describedby="tagline-description" value="<?php echo $to; ?>" class="regular-text" /> <span class="date-time-text format-i18n">End Rank</span></label><br />
	</fieldset>
</td>
</tr>
<?php endfor; ?>

</table>
<p>Click Save Options to store option changes</p>
<?php
 // output save settings button
 submit_button( 'Save Options' );
?>

</form>