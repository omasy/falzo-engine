<?php
		// GRAB OPTIONS FOR SPONSORED
		$sponsored=$options["sponsored"];
		$promotion=$sponsored["promotion"];
		$position=$sponsored["position"];
		$filter=$sponsored["filter"];
        // Cleanup
        $type = $promotion['type'];
        $specification = $promotion['specification'];
		
		// Setting type array
		$sponsor_names=array("Week Traffic", "Month Traffic", "Months Traffic", "Year Traffic", "Years Traffic");
		
 ?>
<form method="post" novalidate="novalidate">
<input type='hidden' name='falzo_options' value='sponsored' />
<table class="form-table">
<tr>
<th scope="row"><label for="blogname">Sponsor Type</label></th>
<td>
<fieldset><legend class="screen-reader-text"><span>Sponsor Specification</span></legend>
<label><input name="type" type="text" id="type" value="" placeholder="Add Type" class="regular-text" /> 
<span class="date-time-text format-i18n"><?php $type_string=""; ?>
<?php foreach($type as $set): ?>
<?php
// Now lets log settings
if(strlen($type_string)>0){
	$type_string.=", <i>".$set."</i>";
}
else{
	$type_string.="<i>".$set."</i>";
}
 ?>
<?php endforeach;
// Now lets display output
$desc="<strong>Available sponsor types: </strong>";
$desc.=$type_string;
echo $desc;
 ?></span>
 </label>
 <br />
 </fieldset>
 </td>
</tr>

<?php for($i=0; $i<count($specification); $i++): ?>	
<?php $specific=$specification[strtolower($sponsor_names[$i])]; ?>
<tr>
<th scope="row"><?php echo $sponsor_names[$i]; ?></th>
<td>
	<fieldset><legend class="screen-reader-text"><span>Sponsor Specification</span></legend>
	<label><input name="<?php echo strtolower(str_replace(" ", "-", $sponsor_names[$i]))."-duration"; ?>" type="text" id="<?php echo strtolower(str_replace(" ", "-", $sponsor_names[$i]))."-duration"; ?>" aria-describedby="tagline-description" value="<?php echo $specific['duration']; ?>" class="regular-text" /> <span class="date-time-text format-i18n">Duration(in hour)</span></label><br />
	<label><input name="<?php echo strtolower(str_replace(" ", "-", $sponsor_names[$i]))."-amount"; ?>" type="text" id="<?php echo strtolower(str_replace(" ", "-", $sponsor_names[$i]))."-amount"; ?>" aria-describedby="tagline-description" value="<?php echo $specific['amount']; ?>" class="regular-text" /> <span class="date-time-text format-i18n">Amount(in Dollars - $)</span></label><br />
	</fieldset>
</td>
</tr>
<?php endfor; ?>

<tr>
<th scope="row"><label for="siteurl">Sponsored Position</label></th>
<td>
<select name="position" id="position">
	<option <?php if($position=="page-content"): ?> selected='selected' <?php endif; ?> value='page-content'>Page Content</option>
	<option <?php if($position=="body-content"): ?> selected='selected' <?php endif; ?> value='body-content'>Body Content</option>
    <option <?php if($position=="side-bar"): ?> selected='selected' <?php endif; ?> value='side-bar'>Side Bar</option>
</select>
</td>
</tr>
<tr>
<th scope="row"><label for="default_role">Sponsor Filters</label></th>
<td>
<select name="filter" id="filter">
	<option <?php if($filter=="relevance"): ?> selected='selected' <?php endif; ?> value='relevance'>By Relevance</option>
	<option <?php if($filter=="top-post"): ?> selected='selected' <?php endif; ?> value='related'>By Related</option>
	<option <?php if($filter=="featured"): ?> selected='selected' <?php endif; ?> value='featured'>By Featured</option>
	<option <?php if($filter=="any"): ?> selected='selected' <?php endif; ?> value='any'>Any</option>
</select>
</td>
</tr>
</table>
<p>Click Save Options to store option changes</p>
<?php
 // output save settings button
 submit_button( 'Save Options' );
?>

</form>