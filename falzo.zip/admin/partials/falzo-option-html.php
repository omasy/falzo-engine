<?php
	// WE CHECK IF WE ARE ON ADMIN PAGES
	if(isset($_GET["page"])){
		// YEST WE CAN START PROCESSING
		$page=$_GET["page"];
		
		//GRAB ALL OPTIONS
		$options = get_option("falzo_options");
		
		// HERE WE TRY SUBMITTING THE FORMS OPTION ON THE SAME PAGE
		// NOW LETS START PROCESSING THE FORM DATAS TO GET THE ACTUAL SETTINGS
		if ( isset( $_POST['falzo_options'] ) ) {
 			// Now lets check option update type demand
	 		$option_type=$_POST['falzo_options'];
			$Clean_Inputs=yo_clean_inputs($_POST);
			$success=0;
 
 			// NOW LETS BEGIN TO UPDATE OPTIONS OF DIFFERENT TYPES
 			if($option_type=="sponsored"){
	 			// Here we update the sponsored option
				// Initiating the validator
				$validator=yo_validate($_POST);
				// Now lets check validation
				if(yo_check_validation($validator)==true){
					// LETS PROCESS THE OPTION DATA
					// echo $options["sponsored"]["promotion"]["type"][0];
					if($Clean_Inputs["type"]!="n"){ // We make sure not to update type when not needed
						$options["sponsored"]["promotion"]["type"][]=$Clean_Inputs["type"];
					}
					// Updating Sepecification fields
					// Updating week traffic
					$options["sponsored"]["promotion"]["specification"]["week traffic"][0]=$Clean_Inputs["week-traffic-duration"];
					$options["sponsored"]["promotion"]["specification"]["week traffic"][1]=$Clean_Inputs["week-traffic-amount"];
					
					// Updating month traffic
					$options["sponsored"]["promotion"]["specification"]["month traffic"][0]=$Clean_Inputs["month-traffic-duration"];
					$options["sponsored"]["promotion"]["specification"]["month traffic"][1]=$Clean_Inputs["month-traffic-amount"];
					
					// Updating month traffic
					$options["sponsored"]["promotion"]["specification"]["months traffic"][0]=$Clean_Inputs["months-traffic-duration"];
					$options["sponsored"]["promotion"]["specification"]["months traffic"][1]=$Clean_Inputs["months-traffic-amount"];
					
					// Updating month traffic
					$options["sponsored"]["promotion"]["specification"]["year traffic"][0]=$Clean_Inputs["year-traffic-duration"];
					$options["sponsored"]["promotion"]["specification"]["year traffic"][1]=$Clean_Inputs["year-traffic-amount"];
					
					// Updating month traffic
					$options["sponsored"]["promotion"]["specification"]["years traffic"][0]=$Clean_Inputs["years-traffic-duration"];
					$options["sponsored"]["promotion"]["specification"]["years traffic"][1]=$Clean_Inputs["years-traffic-amount"];
					
					// Updating the position
					$options["sponsored"]["position"]=$Clean_Inputs["position"];
					
					// Updating the filter
					$options["sponsored"]["filter"]=$Clean_Inputs["filter"];
					
					// NOW LETS PROCEED TO UPDATIONG THE MODIFIED OPTIONS
					update_option("falzo_options", $options);
					
					// Setting success value
					$success=1;
					
				} // End of validation check
				else{
					// Setting error value
					$success=0;
				}
		 	}
		 	elseif($option_type=="referral"){
	 			// Here we update the referral option
				// Initiating the validator
				$validator=yo_validate($_POST);
				// Now lets check validation
				if(yo_check_validation($validator)==true){
					// LETS PROCESS THE OPTION DATA
					
					// Updating the position
					$options["referral"]["rate"]=$Clean_Inputs["rate"];
					
					// Updating the position
					$options["referral"]["discount"]=$Clean_Inputs["discount"];
					
					// Updating the position
					$options["referral"]["approval"]=$Clean_Inputs["approval"];
					
					// NOW LETS PROCEED TO UPDATIONG THE MODIFIED OPTIONS
					update_option("falzo_options", $options);
					
					// Setting success value
					$success=1;
					
				} // End of validation check
				else{
					// Setting error value
					$success=0;
				}
	 
 			}
 			elseif($option_type=="agency"){
	 			// Here we update the agency option
	 			// Initiating the validator
				$validator=yo_validate($_POST);
				// Now lets check validation
				if(yo_check_validation($validator)==true){
					// LETS PROCESS THE OPTION DATA
					// Setting type array
					$rank_names=array("super", "pro", "starter");
					// Updating Patching Specification
					$options["agency"]["patching"]["price"]=$Clean_Inputs["price"];
					$options["agency"]["patching"]["rank"]=$Clean_Inputs["award-rank"];
					
					// Updating Benefit Specification
					$options["agency"]["patching"]["benefit"]["rate"]=$Clean_Inputs["benefit-rate"];
					$options["agency"]["patching"]["benefit"]["approval"]=$Clean_Inputs["benefit-approval"];
					
					// Updating the rank specification
					// Now lets loop rank names array
					foreach($rank_names as $key=>$value){
						// Now lets update ranks
						$options["agency"]["ranking"][$value]=$Clean_Inputs[$value."-from"]."-".$Clean_Inputs[$value."-to"];
					} // End of loop
					
					// NOW LETS PROCEED TO UPDATIONG THE MODIFIED OPTIONS
					update_option("falzo_options", $options);
					
					// Setting success value
					$success=1;
					
				} // End of validation check
				else{
					// Setting error value
					$success=0;
				}
 			}
			elseif($option_type=="rankuser"){
				// HERE WE SET THE USER RANK UPDATER
				// Initiating the validator
				$validator=yo_validate($_POST);
				// Now lets check validation
				if(yo_check_validation($validator)==true){
					$rank = intval(get_user_meta( intval($Clean_Inputs["userid"]), YO_METABOX_PREFIX. 'user_rank', true ));
			 		$user_rank=0;
			 		// Lets check rank
			 		if(empty($rank)){
				 		$rank=0;
			 		}
			 		// Now lets set rank and add up
			 		$user_rank = intval($Clean_Inputs["rank_num"]) + $rank;
			 		// NOW LETS STORE THE NEW RANK
			 		update_user_meta( intval($Clean_Inputs["userid"]), YO_METABOX_PREFIX. 'user_rank', $user_rank );
					// Setting success value
					$success=1;
				} // End of validation check
				else{
					// Setting error value
					$success=0;
				}
			}
 	
			// NOW LETS PRINT SUCCESS MESSAGE
			if($success==true){
				// echo "<p class='notice-info is-dismissible'>Option Saved Successfully!</p>";
				// add settings saved message with the class of "updated"
 				add_settings_error( 'falzo_messages', 'falzo_message', __( 'Options Saved', 'falzo_options' ), 'updated' );
				// show error/update messages
 				settings_errors( 'falzo_messages' );
			}
			else{
				// echo "<p class='notice-info is-dismissible'>Option Saved Successfully!</p>";
				// add settings saved message with the class of "updated"
				echo '<div class="notice notice-error"><p><b>'.esc_attr__( 'Options missing please try again!', 'falzo_options' ).'</b></p></div>';
			}
			
		}
		
		// yo_get_template_part('table_dump.php');
		// echo yo_get_template_html('global/agency-modal.php',array('type'=>'not_login'));
		
		// HERE WE INCLUDE THE SPECIFIC OPTION PAGE THAT WE NEED TO PROCESS WITH
		switch($page){
		case "yo_agency":
		// We include the option form html here
		require_once("agency-option-html.php");
		break;
		case "yo_sponsored":
		// We include the option form html here
		require_once("sponsored-option-html.php");
		break;
		case "yo_referral":
		// We include the option form html here
		require_once("referral-option-html.php");
		break;
		case "yo_user_rank":
		// We include the option form html here
		require_once("rankuser-option-html.php");
		}
	}
	else{
		// IF WE ARE NOT IN PAGE LETS RETURN ERROR
		return;
	}
		
 ?>