<?php
		// GRAB OPTIONS FOR SPONSORED
		$blogusers = get_users();	
 ?>
<form method="post" novalidate="novalidate">
<input type='hidden' name='falzo_options' value='rankuser' />
<table class="form-table">
<tr>
<th scope="row"><label for="siteurl">Select User</label></th>
<td>
<?php if(!empty($blogusers)): ?>
<select name="userid" id="userid">
<?php foreach($blogusers as $user): ?>
	<option value="<?php echo $user->ID; ?>"><?php echo ucfirst($user->user_login)." -- ".get_user_meta( $user->ID, YO_METABOX_PREFIX. 'user_rank', true ); ?></option>
<?php endforeach; ?>
<?php endif; ?>
</select>
</td>
</tr>
<tr>
<th scope="row"><label for="default_role">Specify Rank Amount</label></th>
<td>
<input name="rank_num" type="text" id="rank_num" aria-describedby="tagline-description" value="100" class="regular-text" />
</td>
</tr>
</table>
<p>Click to give user a rank</p>
<?php
 // output save settings button
 submit_button( 'Rank User' );
?>

</form>